import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Rocket, Lock, Mail } from "lucide-react";
import { toast } from "react-toastify";
import authService from "../../api/authService";
import GlassCard from "../../components/common/GlassCard";
import Button from "../../components/common/Button";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const data = await authService.login({ email, password });
      localStorage.setItem("token", data.token);
      localStorage.setItem("admin", JSON.stringify(data.admin));
      toast.success("Welcome back, Admin!");
      navigate("/admin");
    } catch (error) {
      toast.error(error.response?.data?.error || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-gradient-premium">
      <div className="max-w-md w-full">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-gradient-to-tr from-primary-600 to-secondary-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-2xl animate-glow">
            <Rocket className="text-white w-10 h-10" />
          </div>
          <h1 className="text-3xl font-bold font-sora tracking-tight">
            Admin Login
          </h1>
          <p className="text-gray-400 mt-2">
            Manage the IT Tech digital ecosystem
          </p>
        </div>

        <GlassCard>
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 w-5 h-5" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-12 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none"
                  placeholder="admin@ittech.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 w-5 h-5" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-12 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <Button type="submit" className="w-full h-12" disabled={loading}>
              {loading ? "Authenticating..." : "Sign In"}
            </Button>
            <div>
              <p>Email: admin@ittech.com</p>
              <p>Password: password123</p>
            </div>
          </form>
        </GlassCard>

        <p className="text-center mt-8 text-gray-500 text-sm">
          &copy; {new Date().getFullYear()} IT Tech Solutions
        </p>
      </div>
    </div>
  );
};

export default Login;
