import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import {
  LayoutDashboard,
  Briefcase,
  Projector,
  MessageSquare,
  Settings,
  LogOut,
  FileText,
  Image as ImageIcon,
  Bell,
  Search,
  Menu,
  Monitor,
  X,
  User,
  Shield,
} from "lucide-react";
import { motion as Motion, AnimatePresence } from "framer-motion";

import Overview from "../../components/admin/managers/Overview";
import ServicesManager from "../../components/admin/managers/ServicesManager";
import ProjectsManager from "../../components/admin/managers/ProjectsManager";
import TestimonialsManager from "../../components/admin/managers/TestimonialsManager";
import ProfileSettings from "../../components/admin/managers/ProfileSettings";
import BannerManager from "../../components/admin/managers/BannerManager";
import BlogManager from "../../components/admin/managers/BlogManager";
import InboxManager from "../../components/admin/managers/InboxManager";
import PageSettingsManager from "../../components/admin/managers/PageSettingsManager";

import useFetch from "../../hooks/useFetch";
import getImageUrl from "../../utils/getImageUrl";

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");
  const { data: adminData, refetch: refetchAdmin } = useFetch("/auth/me");
  const { data: settingsData } = useFetch("/settings");
  const admin = adminData?.data || {};

  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth > 1024);
  const navigate = useNavigate();

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1024) {
        setIsSidebarOpen(false);
      } else {
        // Only auto-open if NOT in compact mode
        if (settingsData?.data?.compact_sidebar !== "true") {
          setIsSidebarOpen(true);
        }
      }
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [settingsData]);

  // Initial compact state
  useEffect(() => {
    if (settingsData?.data?.compact_sidebar === "true") {
      setIsSidebarOpen(false);
    }
  }, [settingsData]);

  useEffect(() => {
    const adminStored = localStorage.getItem("admin");
    if (!adminStored) {
      navigate("/login");
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("admin");
    toast.info("Securely logged out");
    navigate("/login");
  };

  const menuGroups = [
    {
      title: "Analytics",
      items: [
        {
          id: "overview",
          label: "Dashboard",
          icon: <LayoutDashboard size={20} />,
        },
        {
          id: "inbox",
          label: "Inbox & Leads",
          icon: <MessageSquare size={20} />,
        },
      ],
    },
    {
      title: "Content Management",
      items: [
        { id: "banners", label: "Hero Banners", icon: <ImageIcon size={20} /> },
        { id: "services", label: "Services", icon: <Briefcase size={20} /> },
        { id: "projects", label: "Portfolio", icon: <Projector size={20} /> },
        { id: "blog", label: "Blog Posts", icon: <FileText size={20} /> },
        {
          id: "testimonials",
          label: "Testimonials",
          icon: <MessageSquare size={20} />,
        },
        { id: "content", label: "Page Content", icon: <Monitor size={20} /> },
      ],
    },
    {
      title: "System",
      items: [
        { id: "settings", label: "Settings", icon: <Settings size={20} /> },
      ],
    },
  ];

  const { data: notificationsData, refetch: refetchNotifications } =
    useFetch("/notifications");
  const notifications = notificationsData?.data || [];
  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleMarkAllRead = async () => {
    try {
      const apiClient = (await import("../../api/client")).default;
      await apiClient.delete("/notifications"); // Physically remove them
      refetchNotifications();
      toast.success("System clear: All alerts purged");
    } catch (err) {
      toast.error("Failed to purge notifications");
    }
  };

  const handleClearNotif = async (id, e) => {
    e?.stopPropagation(); // Prevent navigation on delete
    try {
      const apiClient = (await import("../../api/client")).default;
      await apiClient.delete(`/notifications/${id}`);
      refetchNotifications();
    } catch (err) {
      console.error(err);
    }
  };

  const handleNotifClick = async (notif) => {
    try {
      const apiClient = (await import("../../api/client")).default;
      if (!notif.isRead) {
        await apiClient.put(`/notifications/${notif._id}/read`);
      }

      // Navigate to related page if exists
      if (notif.link) {
        // Find tab ID from link (e.g. /admin/inbox -> inbox)
        const tabId = notif.link.split("/").pop();
        setActiveTab(tabId);
      }

      setIsNotificationsOpen(false);
      refetchNotifications();
    } catch (err) {
      console.error(notif);
    }
  };

  const getIcon = (type) => {
    switch (type) {
      case "lead":
        return <MessageSquare size={14} />;
      case "info":
        return <FileText size={14} />;
      case "system":
        return <Settings size={14} />;
      case "security":
        return <Shield size={14} />;
      default:
        return <Bell size={14} />;
    }
  };

  const getColorClass = (type) => {
    switch (type) {
      case "lead":
        return { color: "text-primary-400", bg: "bg-primary-500/10" };
      case "info":
        return { color: "text-blue-400", bg: "bg-blue-500/10" };
      case "system":
        return { color: "text-amber-400", bg: "bg-amber-500/10" };
      case "security":
        return { color: "text-emerald-400", bg: "bg-emerald-500/10" };
      default:
        return { color: "text-gray-400", bg: "bg-white/10" };
    }
  };

  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const notificationRef = React.useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        notificationRef.current &&
        !notificationRef.current.contains(event.target)
      ) {
        setIsNotificationsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="min-h-screen bg-[var(--background)] flex w-full relative z-[100] font-sans overflow-hidden transition-colors duration-500">
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && window.innerWidth < 1024 && (
          <Motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[110] lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* SaaS Sidebar Responsive */}
      <AnimatePresence mode="wait">
        {isSidebarOpen && (
          <Motion.aside
            initial={{ x: -280, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -280, opacity: 0 }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed lg:static inset-y-0 left-0 w-[280px]  backdrop-blur-xl border-r border-white/5 flex flex-col z-[120] lg:z-auto overflow-y-auto no-scrollbar shadow-2xl lg:shadow-none"
          >
            <div className="p-6 shrink-0 flex items-center justify-between sticky top-0 bg-[var(--background)] z-10 border-b border-white/5">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-tr from-primary-600 to-primary-400 rounded-lg flex items-center justify-center shadow-lg shadow-primary-500/30">
                  <span className="text-white font-bold font-sora">IT</span>
                </div>
                <span className="font-bold text-lg text-white tracking-wide">
                  Workspace
                </span>
              </div>
              <button
                onClick={() => setIsSidebarOpen(false)}
                className="lg:hidden p-2 text-gray-400 hover:text-white transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            <div className="flex-1 px-4 py-6 space-y-8">
              {menuGroups.map((group, gIdx) => (
                <div key={gIdx}>
                  <p className="px-4 text-xs font-semibold text-gray-500 uppercase tracking-widest mb-3">
                    {group.title}
                  </p>
                  <nav className="space-y-1">
                    {group.items.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActiveTab(item.id);
                          if (window.innerWidth < 1024) setIsSidebarOpen(false);
                        }}
                        className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-300 relative group ${
                          activeTab === item.id
                            ? "bg-primary-600/10 text-white font-bold"
                            : "text-gray-400 hover:bg-white/5 hover:text-white"
                        }`}
                      >
                        {activeTab === item.id && (
                          <Motion.div
                            layoutId="sidebar-active"
                            className="absolute left-0 w-1 h-6 bg-primary-500 rounded-r-full"
                          />
                        )}
                        <div
                          className={`transition-colors duration-300 ${activeTab === item.id ? "text-primary-500" : "group-hover:text-gray-200"}`}
                        >
                          {React.cloneElement(item.icon, { size: 18 })}
                        </div>
                        <span className="text-sm tracking-wide">
                          {item.label}
                        </span>
                      </button>
                    ))}
                  </nav>
                </div>
              ))}
            </div>

            <div className="p-4 border-t border-white/5 bg-gradient-to-t from-[var(--background)] to-transparent sticky bottom-0">
              <button
                onClick={handleLogout}
                className="flex items-center space-x-3 text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-all w-full px-4 py-3 rounded-xl"
              >
                <LogOut size={20} />
                <span className="font-medium text-sm">Sign Out</span>
              </button>
            </div>
          </Motion.aside>
        )}
      </AnimatePresence>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden bg-transparent relative w-full">
        {/* Contextual Topbar */}
        <header className="h-16 md:h-20 border-b border-white/5 bg-white/[0.02] backdrop-blur-md flex items-center justify-between px-4 md:px-8 shrink-0 relative z-50">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="w-10 h-10 flex items-center justify-center rounded-xl bg-white/5 border border-white/10 text-gray-400 hover:text-white hover:bg-white/10 transition-all active:scale-95"
            >
              <Menu size={20} />
            </button>

            <div className="hidden md:flex items-center bg-white/5 border border-white/10 rounded-full px-4 py-2 w-64 focus-within:ring-1 focus-within:ring-primary-500 transition-all">
              <Search size={18} className="text-gray-500 mr-2" />
              <input
                type="text"
                placeholder="Search resources..."
                className="bg-transparent border-none outline-none text-sm text-gray-300 w-full placeholder:text-gray-600"
              />
            </div>
          </div>

          <div className="flex items-center space-x-6">
            <div className="relative" ref={notificationRef}>
              <button
                onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                className={`relative w-10 h-10 flex items-center justify-center rounded-xl border transition-all active:scale-95 ${isNotificationsOpen ? "bg-primary-500 border-primary-400 text-white shadow-lg shadow-primary-500/30" : "bg-white/5 border-white/10 text-gray-400 hover:text-white hover:bg-white/10"}`}
              >
                <Bell size={20} />
                {unreadCount > 0 && (
                  <span className="absolute top-2 right-2.5 w-2 h-2 bg-primary-500 rounded-full border-2 border-[#0f172a] animate-pulse"></span>
                )}
              </button>

              {/* Notification Dropdown (Glassmorphism) */}
              <AnimatePresence>
                {isNotificationsOpen && (
                  <Motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 mt-2 w-80 bg-[#0f172a]/95 backdrop-blur-xl border border-white/10 rounded-[2rem] shadow-2xl z-[200] overflow-hidden origin-top-right"
                  >
                    <div className="p-6 border-b border-white/5 flex items-center justify-between">
                      <h4 className="text-white font-bold font-sora text-sm">
                        System Intelligence
                      </h4>
                      {unreadCount > 0 && (
                        <span className="text-[10px] font-black text-primary-400 uppercase tracking-widest">
                          {unreadCount} New Alerts
                        </span>
                      )}
                    </div>

                    <div className="max-h-[350px] overflow-y-auto no-scrollbar py-2">
                      {notifications.length > 0 ? (
                        notifications.map((notif) => {
                          const styles = getColorClass(notif.type);
                          return (
                            <div
                              key={notif._id}
                              onClick={() => handleNotifClick(notif)}
                              className={`px-6 py-4 hover:bg-white/5 transition-colors cursor-pointer border-b border-white/[0.03] last:border-none group/item ${!notif.isRead ? "bg-white/[0.02]" : "opacity-60"}`}
                            >
                              <div className="flex items-start justify-between">
                                <div className="flex items-start space-x-4">
                                  <div
                                    className={`w-8 h-8 rounded-lg ${styles.bg} ${styles.color} flex items-center justify-center shrink-0`}
                                  >
                                    {getIcon(notif.type)}
                                  </div>
                                  <div className="space-y-1">
                                    <p className="text-[13px] font-bold text-white group-hover/item:text-primary-400 transition-colors">
                                      {notif.title}
                                    </p>
                                    <p className="text-[11px] text-gray-500 leading-relaxed">
                                      {notif.message}
                                    </p>
                                    <div className="flex items-center space-x-2 pt-1">
                                      <p className="text-[9px] font-black text-gray-600 uppercase tracking-widest">
                                        {new Date(
                                          notif.createdAt,
                                        ).toLocaleTimeString([], {
                                          hour: "2-digit",
                                          minute: "2-digit",
                                        })}
                                      </p>
                                      {!notif.isRead && (
                                        <div className="w-1 h-1 rounded-full bg-primary-500" />
                                      )}
                                    </div>
                                  </div>
                                </div>

                                <button
                                  onClick={(e) =>
                                    handleClearNotif(notif._id, e)
                                  }
                                  className="p-1 text-gray-700 hover:text-red-400 opacity-0 group-hover/item:opacity-100 transition-all"
                                >
                                  <X size={14} />
                                </button>
                              </div>
                            </div>
                          );
                        })
                      ) : (
                        <div className="p-12 text-center space-y-3">
                          <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center mx-auto text-gray-600">
                            <Bell size={20} />
                          </div>
                          <p className="text-xs text-gray-500">
                            System architecture clear.
                          </p>
                        </div>
                      )}
                    </div>

                    {notifications.length > 0 && (
                      <div className="p-4 bg-white/[0.02] border-t border-white/5">
                        <button
                          onClick={handleMarkAllRead}
                          className="w-full py-3 text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] hover:text-white transition-colors"
                        >
                          Acknowledge All Protocols
                        </button>
                      </div>
                    )}
                  </Motion.div>
                )}
              </AnimatePresence>
            </div>

            <div
              onClick={() => setActiveTab("settings")}
              className="flex items-center space-x-3 pl-6 border-l border-white/10 cursor-pointer group"
            >
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-gray-700 to-gray-500 border border-white/10 overflow-hidden ring-offset-2 ring-offset-[#020617] group-hover:ring-2 ring-primary-500 transition-all">
                {admin.avatar ? (
                  <img
                    src={getImageUrl(admin.avatar)}
                    alt="Admin"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-400">
                    <User size={18} />
                  </div>
                )}
              </div>
              <div className="hidden md:block text-left">
                <p className="text-sm font-bold text-white leading-tight group-hover:text-primary-400 transition-colors">
                  {admin.name || "Admin User"}
                </p>
                <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">
                  {admin.role || "Superadmin"}
                </p>
              </div>
            </div>
          </div>
        </header>

        {/* Dynamic Content Renderer */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 no-scrollbar scroll-smooth">
          <Motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="max-w-[1600px] mx-auto"
          >
            {activeTab === "overview" && <Overview />}
            {activeTab === "services" && <ServicesManager />}
            {activeTab === "projects" && <ProjectsManager />}
            {activeTab === "testimonials" && <TestimonialsManager />}
            {activeTab === "settings" && (
              <ProfileSettings onUpdate={refetchAdmin} />
            )}
            {activeTab === "banners" && <BannerManager />}
            {activeTab === "blog" && <BlogManager />}
            {activeTab === "inbox" && <InboxManager />}
            {activeTab === "content" && <PageSettingsManager />}

            {/* Placeholders for upcoming managers */}
            {![
              "overview",
              "services",
              "projects",
              "testimonials",
              "settings",
              "banners",
              "blog",
              "inbox",
              "content",
            ].includes(activeTab) && (
              <div className="h-64 flex flex-col items-center justify-center text-center bg-white/5 rounded-3xl border border-white/5 backdrop-blur-sm">
                <Settings
                  size={48}
                  className="text-gray-600 animate-spin-slow mb-4"
                />
                <h3 className="text-white font-sora font-semibold text-lg mb-1">
                  Module Syncing
                </h3>
                <p className="text-gray-500 text-sm">
                  The {activeTab} manager is currently being compiled...
                </p>
              </div>
            )}
          </Motion.div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
