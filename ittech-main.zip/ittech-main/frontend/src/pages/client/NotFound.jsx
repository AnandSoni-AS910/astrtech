import { ArrowLeft, Home, Search, ShieldAlert } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

const NotFound = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-[100svh] relative overflow-hidden bg-[#020617] text-white flex items-center">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-[28rem] h-[28rem] bg-primary-600/10 rounded-full blur-[140px]" />
        <div className="absolute bottom-0 left-0 w-[24rem] h-[24rem] bg-secondary-600/10 rounded-full blur-[140px]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(99,102,241,0.12),transparent_45%),radial-gradient(circle_at_bottom_left,rgba(236,72,153,0.08),transparent_35%)]" />
      </div>

      <div className="max-w-5xl mx-auto px-6 py-24 relative z-10 w-full">
        <div className="text-center space-y-8">
          <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-xl">
            <ShieldAlert size={14} className="text-primary-400" />
            <span className="text-[10px] font-black uppercase tracking-[0.35em] text-primary-300">
              Endpoint Missing
            </span>
          </div>

          <div className="space-y-4">
            <p className="text-[10px] font-black uppercase tracking-[0.5em] text-white/30">
              Error 404
            </p>
            <h1 className="text-fluid-display font-black font-sora tracking-tighter text-white">
              Page Not Found
            </h1>
            <p className="text-fluid-body-lg text-gray-400 max-w-2xl mx-auto leading-relaxed">
              The route you tried to open does not exist or has been moved.
              Use the navigation below to get back to a live section of the
              site.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl mx-auto pt-4">
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="px-6 py-4 rounded-2xl border border-white/10 bg-white/5 hover:bg-white/10 transition-all font-bold text-sm flex items-center justify-center gap-2"
            >
              <ArrowLeft size={16} />
              Go Back
            </button>
            <Link
              to="/"
              className="px-6 py-4 rounded-2xl bg-primary-600 hover:bg-primary-500 transition-all font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-primary-500/20"
            >
              <Home size={16} />
              Home
            </Link>
            <Link
              to="/services"
              className="px-6 py-4 rounded-2xl border border-white/10 bg-white/5 hover:bg-white/10 transition-all font-bold text-sm flex items-center justify-center gap-2"
            >
              <Search size={16} />
              Services
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
