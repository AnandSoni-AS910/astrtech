import React, { useMemo, Suspense, lazy } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import {
  CheckCircle,
  ArrowRight,
  Zap,
  Globe,
  Server,
  Database,
} from "lucide-react";
import useFetch from "../../hooks/useFetch";
import Button from "../../components/common/Button";
import getImageUrl from "../../utils/getImageUrl";
import SEO from "../../components/common/SEO";


const DEFAULT_TICKER_CITIES = [
  "JODHPUR", "LONDON", "NEW YORK", "JAIPUR", "SINGAPORE", "MUMBAI", "SYDNEY", "DUBAI"
];

const Services = () => {
  const { data: servicesData, loading: servicesLoading } = useFetch(
    "/services?sort=-createdAt",
  );
  const { data: settingsData, loading: settingsLoading } = useFetch(
    "/settings?group=services",
  );

  const services = servicesData?.data || [];
  const settings = settingsData?.data || {};
  const { scrollYProgress } = useScroll();

  const heroScale = useTransform(scrollYProgress, [0, 0.2], [1, 0.95]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);

  // Dynamic Content Defaults
  const heroTitle = settings.services_hero_title || "Worldwide Elite Ecosystems";
  const heroSubtitle =
    settings.services_hero_subtitle ||
    "Deploying mission-critical technical infrastructure for the world's most ambitious global corporations.";
  const tickerCities = settings.services_ticker_cities || DEFAULT_TICKER_CITIES;
  const competenciesTitle =
    settings.services_list_header || "Advanced Solutions for Global Challenges";
  
  const heroWords = useMemo(() => heroTitle.trim().split(/\s+/), [heroTitle]);
  
  const cityStats = useMemo(
    () =>
      tickerCities.map((city, idx) => ({
        city,
        code: `0x${idx.toString(16).toUpperCase()}`,
        stream: `${(city.charCodeAt(0) * 37 + idx * 91) % 900 + 100}GB/S`,
      })),
    [tickerCities],
  );

  const loading = servicesLoading || settingsLoading;

  return (
    <div className="min-h-screen bg-[var(--background)] text-white selection:bg-primary-500/30 overflow-x-hidden">
      <SEO 
        title="Our Services" 
        description="Worldwide elite ecosystems and mission-critical technical infrastructure for ambitious global corporations. Deploying high-end IT solutions." 
        keywords="IT services, technical infrastructure, cloud solutions, global software engineering"
      />
      {/* 1. CINEMATIC HERO SECTION */}
      <section className="relative min-h-[100svh] flex items-center justify-center overflow-hidden border-b border-white/5 py-24 md:py-0">
        <motion.div
          style={{ scale: heroScale, opacity: heroOpacity }}
          className="absolute inset-0 z-0"
        >
          
          <div className="absolute inset-0 bg-gradient-to-b from-[var(--background)]/20 via-[var(--background)]/80 to-[var(--background)]" />
        </motion.div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 w-full">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-4xl"
          >
            <div className="inline-flex items-center space-x-2 px-4 py-2 rounded-full bg-primary-500/10 border border-primary-500/20 mb-8 backdrop-blur-md">
              <Zap size={14} className="text-primary-400 animate-pulse" />
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-primary-300">
                Network Operational
              </span>
            </div>

            <h1 className="text-5xl md:text-7xl font-black font-sora leading-[1.02] tracking-tighter mb-10 text-white max-w-4xl">
              {heroWords.map((word, i) => (
                <span
                  key={i}
                  className={i === heroWords.length - 1 ? "text-gradient" : ""}
                >
                  {word}{" "}
                </span>
              ))}
            </h1>

            <div className="flex flex-col md:flex-row items-center gap-8 max-w-2xl">
              <p className="text-gray-400 text-base md:text-lg font-medium leading-relaxed text-left flex-1 border-l border-primary-500/30 pl-6">
                {heroSubtitle}
              </p>
            </div>
          </motion.div>
        </div>

        {/* Dynamic Telemetry HUD */}
       

        {/* Global Futuristic Ticker Dashboard */}
        <div className="absolute bottom-0 left-0 w-full h-14 bg-[#0a0f1e]/80 backdrop-blur-3xl border-t border-white/10 flex items-center overflow-hidden">
          <div className="flex items-center animate-marquee whitespace-nowrap">
            {cityStats.map((stat, idx) => (
              <div key={idx} className="flex items-center space-x-4 px-12 border-r border-white/5">
                <span className="text-[10px] font-black text-primary-500 font-mono tracking-tighter">{stat.code}</span>
                <span className="text-[10px] font-black text-white uppercase tracking-widest">{stat.city}</span>
                <div className="flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                  <span className="text-[9px] font-bold text-gray-500 font-mono">{stat.stream}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="flex items-center animate-marquee whitespace-nowrap" aria-hidden="true">
            {cityStats.map((stat, idx) => (
              <div key={idx} className="flex items-center space-x-4 px-12 border-r border-white/5">
                <span className="text-[10px] font-black text-primary-500 font-mono tracking-tighter">{stat.code}</span>
                <span className="text-[10px] font-black text-white uppercase tracking-widest">{stat.city}</span>
                <div className="flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                  <span className="text-[9px] font-bold text-gray-500 font-mono">{stat.stream}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 2. SERVICES LIST SECTION */}
      <section className="relative z-10 py-24 md:py-32 bg-[var(--background)]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-end gap-8 mb-24">
            <div className="max-w-xl">
              <span className="text-primary-500 font-black tracking-[.5em] uppercase text-[9px] mb-4 block">
                Core Competencies
              </span>
              <h2 className="text-fluid-section-title font-black font-sora tracking-tighter text-white leading-tight">
                {competenciesTitle}
              </h2>
            </div>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
              {[1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="aspect-[4/3] bg-white/5 rounded-3xl border border-white/10 animate-pulse"
                />
              ))}
            </div>
          ) : services.length > 0 ? (
            <div className="space-y-32">
              {services.map((service, idx) => (
                <motion.div
                  key={service._id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  className={`flex flex-col lg:flex-row gap-12 lg:gap-24 items-center ${idx % 2 !== 0 ? "lg:flex-row-reverse" : ""}`}
                >
                  {/* Image Block */}
                  <div className="w-full lg:w-1/2 group relative">
                    <div className="absolute -inset-2 bg-primary-500/20 rounded-[2.5rem] blur-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
                    <div className="relative aspect-[16/10] rounded-[2rem] overflow-hidden border border-white/10 bg-[#0f172a] shadow-xl">
                      {service.image && service.image !== "no-photo.jpg" ? (
                        <img
                          src={getImageUrl(service.image)}
                          alt={service.title}
                          loading="lazy"
                          decoding="async"
                          className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Server size={80} className="text-white/5" />
                        </div>
                      )}
                      <div className="absolute top-6 left-6 z-20 flex gap-2">
                        <div className="w-2 h-2 rounded-full bg-red-400" />
                        <div className="w-2 h-2 rounded-full bg-amber-400" />
                        <div className="w-2 h-2 rounded-full bg-emerald-400" />
                      </div>
                    </div>
                  </div>

                  {/* Text Block */}
                  <div className="w-full lg:w-1/2 space-y-8">
                    <div className="inline-flex items-center space-x-3">
                      <span className="text-primary-500 font-bold uppercase tracking-widest text-[10px]">
                        {service.category || "Strategic Unit"}
                      </span>
                      <div className="h-[1px] w-10 bg-white/10" />
                      <span className="text-white/20 font-black text-xl">
                        0{idx + 1}
                      </span>
                    </div>

                    <h3 className="text-2xl md:text-3xl lg:text-4xl font-bold font-sora text-white leading-[1.2] tracking-tighter">
                      {service.title}
                    </h3>

                    <p className="text-gray-400 text-base md:text-lg leading-relaxed font-medium opacity-80">
                      {service.description}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                      {(service.features && service.features.length > 0
                        ? service.features
                        : [
                            "Military Grade Encryption",
                            "Zero-Latency Grid",
                            "Autonomous Response",
                            "Worldwide Deployment",
                          ]
                      ).map((feat, i) => (
                        <div
                          key={i}
                          className="flex items-center space-x-3 group/feat cursor-default"
                        >
                          <div className="w-4 h-4 rounded bg-primary-500/10 border border-primary-500/20 flex items-center justify-center group-hover/feat:bg-primary-500 transition-colors">
                            <CheckCircle
                              size={10}
                              className="text-primary-400 group-hover/feat:text-white"
                            />
                          </div>
                          <span className="text-[10px] font-bold uppercase text-white/50 tracking-wider font-sora active:text-white">
                            {feat}
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className="pt-6 flex flex-wrap items-center gap-6">
                      <Button className="h-14 px-10 text-xs font-black uppercase tracking-widest shadow-lg shadow-primary-500/10">
                        <span>Initiate Project</span>
                        <ArrowRight
                          size={16}
                          className="ml-2 group-hover:translate-x-1 transition-transform"
                        />
                      </Button>
                      <button className="flex items-center space-x-2 text-white/30 hover:text-white transition-all text-[9px] font-black uppercase tracking-[0.3em] group">
                        <span>Technical Specification</span>
                        <div className="w-6 h-[1px] bg-white/10 group-hover:w-10 group-hover:bg-primary-500 transition-all" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-32 bg-white/[0.01] border border-white/5 rounded-[3rem]">
              <Database
                size={48}
                className="text-primary-500/20 mx-auto mb-6"
              />
              <h3 className="text-2xl font-black font-sora text-white/30 uppercase tracking-widest">
                Cache Synchronizing
              </h3>
            </div>
          )}
        </div>
      </section>

      {/* 3. FINAL FOOTER SECTION (The "End") */}
      <section className="py-32 px-6 border-t border-white/5 bg-[#020617] relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 bg-primary-600/5 blur-[120px] -z-10 rounded-full" />
        <div className="max-w-4xl mx-auto text-center space-y-12">
          <h2 className="text-fluid-section-title font-bold font-sora tracking-tighter text-white">
            Ready to Build the{" "}
            <span className="text-gradient">Future of Your Enterprise?</span>
          </h2>
          <p className="text-gray-400 text-xl font-medium max-w-2xl mx-auto leading-relaxed">
            Empower your organization with secure, highly optimized infrastructures. 
            Partner with us to engineer the next phase of your digital transformation.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-8">
            <Button className="h-16 px-12 group">
              <Globe
                size={18}
                className="mr-3 group-hover:rotate-45 transition-transform"
              />
              <span>Start Global Deployment</span>
            </Button>
            <button className="text-white font-black uppercase tracking-[0.2em] text-[10px] hover:text-primary-400 transition-colors">
              Contact Technical Operations
            </button>
          </div>
        </div>
      </section>

      {/* Visual Accents */}
      <div
        className="fixed top-0 left-0 w-full h-1 bg-primary-500 origin-left z-50 opacity-20"
        style={{ transform: `scaleX(${scrollYProgress})` }}
      />
    </div>
  );
};

export default Services;
