import React, { useState } from 'react';
import { toast } from 'react-toastify';
import { motion, AnimatePresence } from 'framer-motion';
import { MailOpen, Calendar, User, Search, Tag, ArrowRight, BookOpen, Clock, Hash, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import useFetch from '../../hooks/useFetch';
import subscriptionService from '../../api/subscriptionService';
import getImageUrl from '../../utils/getImageUrl';
import SEO from '../../components/common/SEO';

const Blogs = () => {
  const { data, loading } = useFetch('/blogs?status=published&sort=-createdAt');
  const [searchTerm, setSearchTerm] = useState('');
  const [email, setEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  
  const allBlogs = data?.data || [];
  
  const filteredBlogs = allBlogs.filter(blog => 
    blog.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    blog.category?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="pt-32 pb-24 min-h-screen relative overflow-hidden bg-[#020617] text-white">
      <SEO 
        title="Blog & Insights" 
        description="Deep dives into global software architecture, cybersecurity protocols, and the future of autonomous digital ecosystems." 
        keywords="tech blog, software engineering, cybersecurity, digital ecosystems, AI insights"
      />
      {/* 0. TACTICAL OVERLAYS */}
      <div className="fixed inset-0 pointer-events-none z-0">
         <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-primary-600/5 rounded-full blur-[150px]" />
         <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-purple-500/5 rounded-full blur-[150px]" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        
        {/* 1. CINEMATIC HEADER */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-24 gap-12 border-b border-white/5 pb-16">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            className="max-w-3xl space-y-8"
          >
            <div className="flex items-center space-x-4">
               <div className="px-3 py-1 rounded bg-primary-500/10 border border-primary-500/20 text-[10px] font-black uppercase tracking-[0.3em] text-primary-400">
                  Neural Archive
               </div>
               <div className="w-12 h-px bg-white/10" />
               <div className="text-[10px] font-black uppercase tracking-widest text-white/30 italic">
                  Last Update: {new Date().toLocaleDateString()}
               </div>
            </div>
            
            <h1 className="text-fluid-display font-black font-sora tracking-tighter leading-[0.95]">
              Engineering <br /> <span className="text-gradient">Insights & Intel</span>
            </h1>
            
            <p className="text-xl text-gray-400 font-medium max-w-xl leading-relaxed border-l-2 border-primary-500/30 pl-8">
              Deep dives into global software architecture, cybersecurity protocols, and the future of autonomous digital ecosystems.
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full lg:w-[450px] space-y-6"
          >
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-6 flex items-center pointer-events-none">
                <Search size={20} className="text-primary-500 group-hover:scale-110 transition-transform" />
              </div>
              <input 
                type="text" 
                placeholder="Search the Neural Archives..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-6 pl-16 pr-6 text-white text-lg focus:border-primary-500 focus:ring-1 focus:ring-primary-500/50 transition-all outline-none backdrop-blur-xl"
              />
            </div>
            
            <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-white/30 px-2">
               <span>Directory Status: <span className="text-emerald-500">Live</span></span>
               <span>Available Files: {filteredBlogs.length}</span>
            </div>
          </motion.div>
        </div>

        {/* 2. ARTICLE GRID */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="h-[500px] bg-white/5 rounded-[2.5rem] border border-white/5 animate-pulse" />
            ))}
          </div>
        ) : filteredBlogs.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            <AnimatePresence>
              {filteredBlogs.map((blog, idx) => (
                <motion.div 
                  key={blog._id}
                  layout
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: idx * 0.05 }}
                  className="group relative bg-white/[0.02] border border-white/5 rounded-[2.5rem] overflow-hidden hover:border-primary-500/30 transition-all duration-500 flex flex-col shadow-2xl"
                >
                  {/* Image Container */}
                  <div className="h-64 relative overflow-hidden bg-[#020617]">
                    <img 
                     src={blog.coverImage !== 'no-photo.jpg' ? getImageUrl(blog.coverImage) : 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80'} 
                     alt={blog.title} 
                     loading="lazy"
                     decoding="async"
                     className="w-full h-full object-cover transition-all duration-1000 group-hover:scale-110 opacity-60 group-hover:opacity-100"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#020617] to-transparent opacity-80" />
                    
                    {blog.category && (
                      <div className="absolute top-6 left-6 p-2 bg-primary-600/80 backdrop-blur-md rounded-xl text-white font-black uppercase text-[8px] tracking-[0.3em] border border-white/10 shadow-xl">
                        {blog.category}
                      </div>
                    )}
                    
                    <div className="absolute bottom-6 left-6 flex items-center space-x-4 text-[10px] font-black uppercase tracking-widest text-white/70">
                       <div className="flex items-center space-x-1">
                          <Clock size={12} className="text-primary-500" />
                          <span>8 MIN READ</span>
                       </div>
                    </div>
                  </div>
                  
                  {/* Content */}
                  <div className="p-10 flex-1 flex flex-col space-y-6">
                    <div className="flex items-center space-x-4 text-[10px] font-black uppercase tracking-widest text-white/30">
                      <div className="flex items-center space-x-2">
                        <Calendar size={14} className="text-primary-500" />
                        <span>{new Date(blog.createdAt).toLocaleDateString()}</span>
                      </div>
                      <div className="w-1 h-1 rounded-full bg-white/20" />
                      <div className="flex items-center space-x-2">
                        <User size={14} className="text-primary-500" />
                        <span>{blog.author || 'Senior Architect'}</span>
                      </div>
                    </div>
                    
                    <h3 className="text-2xl font-bold font-sora text-white leading-tight group-hover:text-primary-400 transition-colors">
                      {blog.title}
                    </h3>
                    
                    <p className="text-gray-500 text-sm font-medium leading-relaxed flex-1">
                      {blog.excerpt}
                    </p>
                    
                    <div className="pt-8 border-t border-white/5 flex items-center justify-between">
                       <div className="flex space-x-3">
                          {(blog.tags || []).slice(0, 2).map((tag, i) => (
                             <div key={i} className="flex items-center text-[10px] font-bold text-white/20">
                                <Hash size={10} className="mr-1" />
                                {tag}
                             </div>
                          ))}
                       </div>
                       <Link to={`#`} className="p-3 rounded-xl bg-white/5 border border-white/10 group-hover:bg-primary-600 group-hover:border-primary-500 transition-all group-hover:-rotate-12">
                          <ArrowRight size={18} className="text-white" />
                       </Link>
                    </div>
                  </div>
                  
                  {/* Hover Scanline Effect */}
                  <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-primary-500/0 via-primary-500/[0.02] to-primary-500/0 translate-y-[-100%] group-hover:translate-y-[100%] transition-transform duration-[2000ms] ease-in-out" />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <div className="text-center py-48 bg-white/[0.01] border border-white/5 rounded-[3.5rem] mt-12 backdrop-blur-3xl">
             <div className="w-24 h-24 rounded-full bg-primary-500/10 flex items-center justify-center mx-auto mb-10 text-primary-400 border border-primary-500/20">
                <MailOpen size={40} />
             </div>
             <h3 className="text-4xl font-sora font-black text-white mb-4 tracking-tighter">Directory Empty</h3>
             <p className="text-gray-500 max-w-md mx-auto text-lg font-medium">No intelligence reports currently match your search parameters. Please expand your query grid.</p>
          </div>
        )}
      </div>

      {/* 3. NEWSLETTER / BRIEFING ACCESS */}
      <div className="max-w-7xl mx-auto px-6 mt-32">
         <div className="p-12 md:p-20 rounded-[3.5rem] bg-gradient-to-r from-purple-900/20 to-primary-900/20 border border-white/10 flex flex-col lg:flex-row items-center justify-between gap-12 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary-500/10 rounded-full blur-[80px]" />
            <div className="relative z-10 max-w-xl space-y-6">
               <h2 className="text-fluid-section-title font-black font-sora tracking-tighter capitalize">Subscribe to the <span className="text-gradient">Daily Intel Brief</span></h2>
               <p className="text-gray-400 font-medium">Join 5,000+ elite engineers getting our weekly analysis on global technical logistics.</p>
            </div>
            <div className="relative z-10 w-full lg:w-[500px] flex flex-col sm:flex-row gap-4">
                <input
                  type="email"
                  placeholder="Enter operative email..."
                  className="flex-1 bg-white/5 border border-white/10 rounded-2xl px-6 py-5 focus:border-primary-500 outline-none"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  disabled={submitting}
                />
                <button
                  className="px-8 py-5 bg-primary-600 rounded-2xl font-black uppercase text-[10px] tracking-widest hover:bg-primary-500 transition-all shadow-xl shadow-primary-500/20 disabled:opacity-50"
                  disabled={submitting}
                  onClick={async () => {
                    if (!email) {
                      toast.error('Please enter a valid email');
                      return;
                    }
                    try {
                      setSubmitting(true);
                      await subscriptionService.subscribe({ email });
                      toast.success('Subscription successful!');
                      setEmail('');
                    } catch (err) {
                      toast.error(err.response?.data?.error || 'Subscription failed');
                    } finally {
                      setSubmitting(false);
                    }
                  }}
                >
                  {submitting ? 'Submitting...' : 'Join List'}
                </button>
            </div>
         </div>
      </div>
    </div>
  );
};

export default Blogs;
