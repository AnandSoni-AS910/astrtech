import { Suspense, lazy, useEffect, useState } from "react";
// eslint-disable-next-line no-unused-vars
import { motion } from "framer-motion";
import { ArrowRight, Code, Activity, BookOpen, Layers, MessageSquare, Quote, Terminal, Shield, Workflow, Users, Cpu, Search, User } from "lucide-react";
import { Link } from "react-router-dom";
import GlassCard from "../../components/common/GlassCard";
import Button from "../../components/common/Button";
import useFetch from "../../hooks/useFetch";

import getImageUrl from "../../utils/getImageUrl";
const GlobalNetwork3D = lazy(() => import("../../components/home/GlobalNetwork3D"));

import SEO from "../../components/common/SEO";

const Home = () => {
  const { data: servicesData, loading: serviceLoading } = useFetch("/services?limit=6&sort=-createdAt");
  const { data: bannerData } = useFetch("/banners");
  const { data: blogData } = useFetch("/blogs?limit=3&sort=-createdAt");
  const { data: testimonialsData } = useFetch("/testimonials?limit=3&sort=-createdAt");
  const { data: homeSettingsData } = useFetch("/settings?group=home");

  const services = servicesData?.data || [];
  const blogs = blogData?.data || [];
  const testimonials = testimonialsData?.data || [];
  const homeSettings = homeSettingsData?.data || {};
  const activeBanners = bannerData?.data ? bannerData.data.filter((b) => b.isActive) : [];
  const [showGlobe, setShowGlobe] = useState(false);
  const processSteps = [
    {
      id: "01",
      title: "Intelligence",
      desc: "Deep analysis of the tactical landscape and business bottlenecks.",
      icon: <Search size={20} />,
      classes: "bg-blue-500/10 text-blue-400 border-blue-500/20",
    },
    {
      id: "02",
      title: "Engineering",
      desc: "Constructing the primary architecture using resilient cloud stacks.",
      icon: <Cpu size={20} />,
      classes: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    },
    {
      id: "03",
      title: "Integration",
      desc: "Seamless cross-platform synchronization and neural stress testing.",
      icon: <Workflow size={20} />,
      classes: "bg-purple-500/10 text-purple-400 border-purple-500/20",
    },
    {
      id: "04",
      title: "Optimized",
      desc: "Continuous monitoring and high-frequency performance upgrades.",
      icon: <Activity size={20} />,
      classes: "bg-pink-500/10 text-pink-400 border-pink-500/20",
    },
  ];

  const heroContent = activeBanners.length > 0 ? activeBanners[0] : {
    title: "The Architects of Digital Resilience",
    subtitle: "Empowering global conglomerates with high-end technical superiority and autonomous digital ecosystems since 2018.",
    ctaText: "Begin Deployment",
    ctaLink: "/contact",
  };

  useEffect(() => {
    const idleCallback =
      window.requestIdleCallback ||
      ((cb) => window.setTimeout(cb, 300));
    const cancelIdleCallback =
      window.cancelIdleCallback ||
      ((id) => window.clearTimeout(id));

    const handle = idleCallback(() => setShowGlobe(true));
    return () => cancelIdleCallback(handle);
  }, []);
  return (
    <div className="relative overflow-hidden bg-[var(--background)] text-white selection:bg-primary-500/30">
      <SEO 
        title="Home" 
        description="Welcome to ITTech - The Architects of Digital Resilience. We provide high-end technical superiority and autonomous digital ecosystems." 
        keywords="IT solutions, digital resilience, cloud infrastructure, enterprise software"
      />
      <div className="fixed inset-0 pointer-events-none z-0">
         <div className="absolute top-[10%] right-[10%] w-[40%] h-[40%] bg-primary-600/5 rounded-full blur-[120px] animate-pulse" />
         <div className="absolute bottom-[20%] left-[-10%] w-[30%] h-[30%] bg-secondary-500/5 rounded-full blur-[100px]" />
      </div>

      {/* 1. CINEMATIC HERO */}
      <section className="relative min-h-[100svh] flex items-center justify-center overflow-hidden border-b border-white/5 py-28 md:py-0">
        <div className="absolute inset-0 z-0">
          <Suspense fallback={<div className="w-full h-full" />}>
            {showGlobe ? <GlobalNetwork3D /> : <div className="w-full h-full" />}
          </Suspense>
          <div className="absolute inset-0 bg-gradient-to-b from-[var(--background)]/50 via-transparent to-[var(--background)] z-[1]" />
          <div className="absolute inset-0 backdrop-blur-[2px] z-[2]" />
        </div>

        <div className="max-w-7xl mx-auto w-full px-6 relative z-10">
          <div className="max-w-4xl space-y-10">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              <div className="inline-flex items-center space-x-3 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-xl">
                 <div className="w-2 h-2 rounded-full bg-primary-500 animate-ping" />
                 <span className="text-[10px] font-black uppercase tracking-[0.4em] text-primary-400">Global Network Active</span>
              </div>
              
              <h1 className="text-fluid-display font-bold font-sora tracking-tighter text-white max-w-5xl">
                {heroContent.title}
              </h1>
              
              <p className="text-fluid-body-lg text-gray-400 max-w-2xl leading-relaxed font-medium border-l-2 border-primary-500/30 pl-6 sm:pl-8 italic">
                {heroContent.subtitle}
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="flex flex-col sm:flex-row items-center gap-8"
            >
              <Link to={heroContent.ctaLink || "/contact"} className="w-full sm:w-auto">
                <Button className="h-16 px-12 group w-full shadow-[0_0_40px_rgba(59,130,246,0.3)]">
                  <span>{heroContent.ctaText || "Request Access"}</span>
                  <ArrowRight size={20} className="ml-3 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Link to="/portfolio" className="flex items-center space-x-3 group py-2">
                <span className="font-black uppercase tracking-widest text-[10px] text-white/50 group-hover:text-white transition-colors">View Portfolio</span>
                <div className="w-8 h-[1px] bg-white/20 group-hover:w-16 group-hover:bg-primary-500 transition-all duration-500" />
              </Link>
            </motion.div>
          </div>
        </div>

        {/* Dynamic Telemetry HUD */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="absolute bottom-8 md:bottom-12 right-6 md:right-12 flex items-center space-x-5 md:space-x-8 px-5 md:px-6 py-3.5 md:py-4 rounded-xl md:rounded-2xl bg-white/[0.05] border border-white/10 backdrop-blur-xl z-20 shadow-2xl"
        >
           <div className="flex flex-col space-y-1 md:space-y-1.5">
              <span className="text-[8px] md:text-[9px] font-black uppercase tracking-[0.2em] text-primary-400">Response_Time</span>
              <span className="text-[11px] md:text-xs font-mono font-bold text-white">0.0042<span className="text-[9px] md:text-[10px] opacity-40">ms</span></span>
           </div>
           <div className="w-px h-8 md:h-10 bg-gradient-to-b from-transparent via-white/20 to-transparent" />
           <div className="flex flex-col space-y-1 md:space-y-1.5">
              <span className="text-[8px] md:text-[9px] font-black uppercase tracking-[0.2em] text-emerald-400">Platform_Uptime</span>
              <span className="text-[11px] md:text-xs font-mono font-bold text-white">99.99<span className="text-[9px] md:text-[10px] opacity-40">%</span></span>
           </div>
           <div className="hidden xs:block w-px h-8 md:h-10 bg-gradient-to-b from-transparent via-white/20 to-transparent" />
           <div className="hidden xs:flex flex-col space-y-1 md:space-y-1.5">
              <span className="text-[8px] md:text-[9px] font-black uppercase tracking-[0.2em] text-amber-400">System_Health</span>
              <span className="text-[9px] md:text-[10px] font-mono font-bold text-emerald-400 uppercase">Healthy</span>
           </div>
        </motion.div>
      </section>

      {/* 2. CORE INTELLIGENCE GRID (Stats) */}
      <section className="py-24 border-b border-white/5 relative z-10">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 lg:grid-cols-4 gap-12">
            {[
              { label: homeSettings.home_stat1_label || "Enterprise Solutions", value: homeSettings.home_stat1_value || "500+", icon: <Activity size={24} /> },
              { label: homeSettings.home_stat2_label || "Global Data Centers", value: homeSettings.home_stat2_value || "24", icon: <Layers size={24} /> },
              { label: homeSettings.home_stat3_label || "Industry Experts", value: homeSettings.home_stat3_value || "150+", icon: <Users size={24} /> },
              { label: homeSettings.home_stat4_label || "Secure Transactions", value: homeSettings.home_stat4_value || "99.9%", icon: <Shield size={24} /> },
            ].map((stat, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="text-center space-y-4 group"
            >
              <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-white/5 mx-auto flex items-center justify-center text-primary-400 border border-white/5 group-hover:scale-110 transition-transform">
                {stat.icon}
              </div>
              <div className="space-y-1">
                <h3 className="text-2xl md:text-4xl font-extrabold font-sora text-white">
                  {stat.value}
                </h3>
                <p className="text-[9px] md:text-[10px] font-black uppercase tracking-widest text-gray-500">
                  {stat.label}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* 3. NEURAL CAPABILITIES (Services) */}
      <section className="py-32 relative z-10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col lg:flex-row justify-between items-center gap-12 mb-20">
            <div className="max-w-3xl space-y-6">
               <span className="text-primary-500 font-black tracking-[0.5em] uppercase text-[10px]">Capabilities</span>
              <h2 className="text-fluid-section-title font-bold font-sora tracking-tighter leading-tight">
                 Tactical Excellence <br /> <span className="text-gradient">Engineered to Scale</span>
              </h2>
            </div>
            <Link to="/services" className="px-8 py-4 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 transition-all font-black uppercase tracking-widest text-[10px]">
              Explore Services
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {serviceLoading ? (
              [1,2,3].map(i => <div key={i} className="h-64 bg-white/5 rounded-3xl animate-pulse" />)
            ) : services.map((service, i) => (
              <GlassCard key={service._id} delay={i * 0.1} className="group p-10 h-full flex flex-col">
                <div className="w-16 h-16 rounded-2xl bg-primary-600/10 flex items-center justify-center text-primary-400 mb-8 border border-white/5 overflow-hidden">
                  {service.image && service.image !== 'no-photo.jpg' ? (
                    <img src={getImageUrl(service.image)} className="w-full h-full object-cover" />
                  ) : <Terminal size={24} />}
                </div>
                <h3 className="text-2xl font-bold font-sora text-white mb-4 group-hover:text-primary-400 transition-colors">{service.title}</h3>
                <p className="text-gray-400 leading-relaxed font-medium mb-8 flex-1">{service.description}</p>
                <Link to="/contact" className="flex items-center space-x-2 text-[10px] font-black uppercase tracking-widest text-primary-500">
                  <span>Learn More</span>
                  <ArrowRight size={12} />
                </Link>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      {/* 4. THE NEURAL PROCESS (WORKFLOW) */}
      <section className="py-32 bg-white/[0.01] border-y border-white/5 relative z-10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center space-y-6 mb-24">
             <span className="text-emerald-500 font-black tracking-[0.5em] uppercase text-[10px]">Our Approach</span>
             <h2 className="text-fluid-section-title font-bold font-sora tracking-tighter">Strategic Deployment</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step) => (
              <div key={step.id} className="relative group p-8 rounded-3xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.05] transition-all">
                <div className="absolute top-0 right-0 p-6 text-4xl font-black text-white/5 font-sora">{step.id}</div>
                <div className={`w-12 h-12 rounded-xl mb-8 flex items-center justify-center ${step.classes}`}>
                  {step.icon}
                </div>
                <h3 className="text-xl font-bold text-white mb-3 font-sora uppercase tracking-tight">{step.title}</h3>
                <p className="text-sm text-gray-500 font-medium leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. RECENT INTEL (BLOGS) */}
      <section className="py-32 relative z-10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center mb-20 gap-8">
             <div className="space-y-4">
                <span className="text-purple-500 font-black tracking-[0.5em] uppercase text-[10px]">Insights</span>
                <h2 className="text-fluid-section-title font-bold font-sora tracking-tighter">Latest Thinking</h2>
             </div>
             <Link to="/blog" className="flex items-center space-x-3 group">
                <span className="text-[10px] font-black uppercase tracking-widest text-white/50 group-hover:text-white">View All Insights</span>
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
             </Link>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {blogs.map((blog, i) => (
              <motion.div 
                key={blog._id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="group rounded-3xl border border-white/5 bg-white/[0.02] overflow-hidden flex flex-col h-full"
              >
                <div className="h-56 relative overflow-hidden bg-black/50">
                <img 
                  src={blog.coverImage !== 'no-photo.jpg' ? getImageUrl(blog.coverImage) : 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80'} 
                  alt={blog.title}
                  loading="lazy"
                  decoding="async"
                  className="w-full h-full object-cover transition-all duration-1000 group-hover:scale-110 opacity-60 group-hover:opacity-100"
                />
                  <div className="absolute top-4 left-4 p-2 bg-primary-600/80 backdrop-blur-md rounded-lg text-white font-black uppercase text-[8px] tracking-widest">
                    {blog.category || 'Tech'}
                  </div>
                </div>
                <div className="p-8 flex-1 flex flex-col">
                   <span className="text-[10px] font-black uppercase tracking-widest text-white/30 mb-4">{new Date(blog.createdAt).toDateString()}</span>
                   <h3 className="text-xl font-bold font-sora mb-4 group-hover:text-primary-400 transition-colors leading-tight">{blog.title}</h3>
                   <p className="text-sm text-gray-500 leading-relaxed mb-8 flex-1">{blog.excerpt}</p>
                   <Link to="/blog" className="flex items-center space-x-2 text-[10px] font-black uppercase tracking-widest text-white hover:text-primary-400 transition-colors pt-6 border-t border-white/5">
                      <span>Read Article</span>
                      <ArrowRight size={12} />
                   </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 5.5 TESTIMONIALS (SOCIAL PROOF) */}
      {testimonials.length > 0 && (
        <section className="py-32 bg-white/[0.01] border-t border-white/5 relative z-10">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center space-y-6 mb-24">
              <span className="text-primary-500 font-black tracking-[0.5em] uppercase text-[10px]">Client Feedback</span>
              <h2 className="text-fluid-section-title font-bold font-sora tracking-tighter">Trusted Intelligence</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {testimonials.map((testimonial, i) => (
                <GlassCard key={testimonial._id || i} delay={i * 0.1} className="p-10 flex flex-col h-full group">
                  <div className="mb-8">
                    <Quote size={40} className="text-primary-500/20 group-hover:text-primary-500/40 transition-colors" />
                  </div>
                  <p className="text-gray-300 italic leading-relaxed text-lg mb-10 flex-1">
                    "{testimonial.text}"
                  </p>
                  <div className="flex items-center space-x-4 border-t border-white/5 pt-8">
                    <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-primary-500/20 bg-white/5 flex-shrink-0">
                      {testimonial.image && testimonial.image !== 'no-photo.jpg' ? (
                        <img src={getImageUrl(testimonial.image)} alt={testimonial.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-600">
                          <User size={32} />
                        </div>
                      )}
                    </div>
                    <div>
                      <h4 className="text-white font-bold font-sora">{testimonial.name}</h4>
                      <p className="text-primary-400 text-xs font-black uppercase tracking-widest mt-1">
                        {testimonial.role} <span className="text-gray-600 px-1">/</span> {testimonial.company}
                      </p>
                    </div>
                  </div>
                </GlassCard>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* 6. CALL TO ACTION */}
      <section className="py-32 px-6 relative z-10">
        <div className="max-w-6xl mx-auto rounded-[3.5rem] bg-gradient-to-br from-primary-600 to-indigo-800 p-12 md:p-32 text-center relative overflow-hidden shadow-[0_0_80px_rgba(59,130,246,0.4)]">
           <div className="absolute top-0 right-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 pointer-events-none" />
           <div className="relative z-10 space-y-12">
              <h2 className="text-fluid-display font-bold font-sora tracking-tighter leading-none">
                Transform Your <br /> <span className="opacity-50">Digital Future</span>
              </h2>
              <p className="text-xl md:text-2xl text-white/70 max-w-2xl mx-auto leading-relaxed font-medium">
                Partner with elite engineering teams to build scalable, secure, high-performance infrastructures. Let's discuss your project today.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-8">
                 <Link to="/contact" className="w-full sm:w-auto flex justify-center">
                   <Button variant="white" className="h-16 px-12 shadow-2xl w-full sm:w-auto">
                      <span>Get Started Today</span>
                   </Button>
                 </Link>
                 <Link to="/contact" className="text-white font-black uppercase tracking-widest text-[10px] hover:underline">Connect with an Expert</Link>
              </div>
           </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
