import React from "react";
import { Shield, Lock, Eye, FileText, Globe, Bell } from "lucide-react";
import { motion } from "framer-motion";
import SEO from "../../components/common/SEO";

const PrivacyPolicy = () => {
  const sections = [
    {
      icon: <Shield className="text-primary-400" />,
      title: "Data Protection Commitment",
      content: "At IT Tech, we prioritize the security of your digital assets. Our infrastructure is engineered to protect your personal information through advanced encryption and tactical security protocols. We do not sell or trade your data to third-party entities.",
    },
    {
      icon: <Lock className="text-emerald-400" />,
      title: "Tactical Security Measures",
      content: "We implement military-grade SSL encryption for all data transmissions. Our neural monitoring systems continuously scan for unauthorized access attempts, ensuring your global identity remains secure across our ecosystem.",
    },
    {
      icon: <Eye className="text-purple-400" />,
      title: "Information Collection",
      content: "We collect only essential telemetry data required to optimize your user experience. This includes session logs, browser configurations, and interaction patterns within our platform's neural nodes.",
    },
    {
      icon: <Globe className="text-blue-400" />,
      title: "Global Compliance",
      content: "Our privacy practices are synchronized with global data protection regulations, including GDPR and CCPA. We maintain transparency in how your information is processed across international jurisdictions.",
    },
    {
      icon: <Bell className="text-pink-400" />,
      title: "Policy Updates",
      content: "As our technology evolves, we may update this protocol. All significant changes will be broadcasted via our neural alert system or through direct communication channels.",
    },
  ];

  return (
    <div className="min-h-screen bg-[#020617] text-white pt-32 pb-24 px-6 relative overflow-hidden">
      <SEO 
        title="Privacy Policy" 
        description="Review ITTech's privacy protocols and how we protect your digital resilience across our technical ecosystem." 
        keywords="privacy policy, data protection, global compliance, security protocols"
      />
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary-600/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-indigo-600/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-4xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-6 mb-20"
        >
          <div className="inline-flex items-center space-x-3 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-xl">
            <div className="w-2 h-2 rounded-full bg-primary-500 animate-pulse" />
            <span className="text-[10px] font-black uppercase tracking-[0.4em] text-primary-400">Security Protocol v2.4</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold font-sora tracking-tighter">Privacy <span className="text-gradient">Policy</span></h1>
          <p className="text-gray-400 max-w-2xl mx-auto font-medium">
            Review our global data management protocols and discover how we protect your digital resilience across our technical ecosystem.
          </p>
        </motion.div>

        <div className="space-y-12">
          {sections.map((section, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white/[0.02] border border-white/5 rounded-3xl p-8 md:p-12 backdrop-blur-sm group hover:border-white/10 transition-all"
            >
              <div className="flex flex-col md:flex-row gap-8 items-start">
                <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center shrink-0 border border-white/10 group-hover:scale-110 transition-transform">
                  {section.icon}
                </div>
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold font-sora text-white">{section.title}</h3>
                  <p className="text-gray-400 leading-relaxed font-medium">
                    {section.content}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-20 p-10 rounded-3xl bg-gradient-to-br from-primary-600/20 to-transparent border border-primary-500/10 text-center"
        >
          <p className="text-sm text-gray-400 font-medium italic">
            "We believe that privacy is not just a policy, but a foundational pillar of digital resilience."
          </p>
          <div className="mt-6 text-[10px] font-black uppercase tracking-widest text-primary-500">
            Last Updated: May 16, 2026
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
