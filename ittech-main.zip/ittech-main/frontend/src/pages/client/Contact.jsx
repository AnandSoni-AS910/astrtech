import React, { useState } from "react";
// eslint-disable-next-line no-unused-vars
import { motion } from "framer-motion";
import { MapPin, Phone, Mail, Clock, Send } from "lucide-react";
import { toast } from "react-toastify";
import GlassCard from "../../components/common/GlassCard";
import Button from "../../components/common/Button";
import contactService from "../../api/contactService";
import useFetch from "../../hooks/useFetch";
import SEO from "../../components/common/SEO";

const Contact = () => {
  const { data: settingsData } = useFetch("/settings");
  const settings = settingsData?.data || {
    email: "contact@ittech.com",
    phone: "+1 (234) 567-890",
    address: "123 Tech Avenue, Silicon Valley, CA 94043",
  };

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });
  const [status, setStatus] = useState("idle");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("loading");

    try {
      await contactService.submitInquiry(formData);
      setStatus("success");
      toast.success("Message sent successfully! We will get back to you soon.");
      setFormData({ name: "", email: "", phone: "", subject: "", message: "" });
      setTimeout(() => setStatus("idle"), 3000);
    } catch (error) {
      setStatus("error");
      toast.error(
        error.response?.data?.error ||
          "Failed to send message. Please try again.",
      );
      setTimeout(() => setStatus("idle"), 3000);
    }
  };

  return (
    <div className="pt-32 pb-24 px-4 min-h-screen relative overflow-hidden">
      <SEO 
        title="Contact Us" 
        description="Get in touch with our global team of tech experts. Have a project in mind? Let's transform your vision into reality." 
        keywords="contact ITTech, project inquiry, tech support, business consultation"
      />
      {/* Background */}
      <div className="absolute top-0 left-0 w-full h-full -z-10 bg-[#020617]" />
      <div className="absolute top-1/3 right-1/4 w-[500px] h-[500px] bg-primary-600/10 rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-secondary-600/10 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-4xl mx-auto mb-20"
        >
          <span className="text-primary-500 font-bold tracking-[0.2em] uppercase text-xs mb-4 block">
            Get In Touch
          </span>
          <h1 className="text-fluid-display font-bold font-sora mb-8 leading-tight">
            Let's Build Something{" "}
            <span className="text-gradient">Extraordinary</span>
          </h1>
          <p className="text-gray-400 text-lg md:text-xl leading-relaxed max-w-3xl mx-auto">
            Have a project in mind? Our global team of tech experts is ready to
            transform your vision into reality.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Contact Information */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={{
              visible: { transition: { staggerChildren: 0.15 } }
            }}
            className="lg:col-span-5 space-y-6"
          >
            {[
              { icon: <MapPin size={24} />, title: "Global Headquarters", content: settings.address, type: 'text' },
              { icon: <Mail size={24} />, title: "Email Us", content: settings.email, type: 'link', href: `mailto:${settings.email}` },
            ].map((item, idx) => (
              <motion.div
                key={idx}
                variants={{
                  hidden: { opacity: 0, x: -20 },
                  visible: { opacity: 1, x: 0 }
                }}
              >
                <GlassCard className="p-8 group hover:border-primary-500/50 transition-all duration-500">
                  <div className="w-12 h-12 rounded-full bg-primary-500/10 flex items-center justify-center text-primary-500 mb-6 group-hover:scale-110 group-hover:bg-primary-500 group-hover:text-white transition-all duration-500">
                    {item.icon}
                  </div>
                  <h3 className="text-xl font-bold font-sora text-white mb-2">
                    {item.title}
                  </h3>
                  {item.type === 'link' ? (
                    <a href={item.href} className="text-gray-400 hover:text-white transition-colors">
                      {item.content}
                    </a>
                  ) : (
                    <p className="text-gray-400">{item.content}</p>
                  )}
                </GlassCard>
              </motion.div>
            ))}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {[
                { icon: <Phone size={24} />, title: "Call Us", content: settings.phone },
                { icon: <Clock size={24} />, title: "Hours", content: "Mon-Fri: 9am-6pm" },
              ].map((item, idx) => (
                <motion.div
                  key={idx}
                  variants={{
                    hidden: { opacity: 0, scale: 0.9 },
                    visible: { opacity: 1, scale: 1 }
                  }}
                >
                  <GlassCard className="p-8 group hover:border-primary-500/50 transition-all h-full">
                    <div className="w-12 h-12 rounded-full bg-primary-500/10 flex items-center justify-center text-primary-500 mb-6 group-hover:scale-110 transition-transform">
                      {item.icon}
                    </div>
                    <h3 className="text-lg font-bold font-sora text-white mb-2">
                      {item.title}
                    </h3>
                    <p className="text-sm text-gray-400">{item.content}</p>
                  </GlassCard>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-7"
          >
            <div className="glass-card rounded-[3rem] p-8 md:p-16 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary-500/10 rounded-full blur-3xl -z-10 group-hover:bg-primary-500/20 transition-colors duration-700" />
              
              <h3 className="text-fluid-section-title font-bold font-sora text-white mb-10">
                Send a Message
              </h3>
 
              <motion.form 
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={{
                  visible: { transition: { staggerChildren: 0.1 } }
                }}
                onSubmit={handleSubmit} 
                className="space-y-6"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <motion.div variants={{ hidden: { opacity: 0, y: 10 }, visible: { opacity: 1, y: 0 } }}>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Full Name</label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white"
                      placeholder="John Doe"
                    />
                  </motion.div>
                  <motion.div variants={{ hidden: { opacity: 0, y: 10 }, visible: { opacity: 1, y: 0 } }}>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Email Address</label>
                    <input
                      type="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white"
                      placeholder="john@example.com"
                    />
                  </motion.div>
                </div>
 
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <motion.div variants={{ hidden: { opacity: 0, y: 10 }, visible: { opacity: 1, y: 0 } }}>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Phone Number</label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white"
                      placeholder="+1 (555) 000-0000"
                    />
                  </motion.div>
                  <motion.div variants={{ hidden: { opacity: 0, y: 10 }, visible: { opacity: 1, y: 0 } }}>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Subject</label>
                    <input
                      type="text"
                      name="subject"
                      required
                      value={formData.subject}
                      onChange={handleChange}
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white"
                      placeholder="Project Inquiry"
                    />
                  </motion.div>
                </div>
 
                <motion.div variants={{ hidden: { opacity: 0, y: 10 }, visible: { opacity: 1, y: 0 } }}>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Message</label>
                  <textarea
                    name="message"
                    required
                    rows="5"
                    value={formData.message}
                    onChange={handleChange}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white resize-none"
                    placeholder="Tell us about your project..."
                  />
                </motion.div>
 
                <motion.div variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }}>
                  <Button
                    type="submit"
                    disabled={status === "loading" || status === "success"}
                    className="w-full h-14 flex justify-center items-center space-x-2"
                  >
                    {status === "loading" ? (
                      <span className="flex items-center space-x-2">
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Sending Request...</span>
                      </span>
                    ) : status === "success" ? (
                      <span>Message Sent Successfully!</span>
                    ) : (
                      <>
                        <span>Submit Inquiry</span>
                        <Send size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                      </>
                    )}
                  </Button>
                </motion.div>
              </motion.form>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
