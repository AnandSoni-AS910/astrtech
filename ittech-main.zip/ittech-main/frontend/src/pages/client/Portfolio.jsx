import React, { useState, useMemo } from "react";
// eslint-disable-next-line no-unused-vars
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowRight,
  ExternalLink,
  Filter,
  Layers,
  Globe,
  Zap,
  Cpu,
  ShieldCheck,
} from "lucide-react";
import useFetch from "../../hooks/useFetch";
import { Link } from "react-router-dom";
import getImageUrl from "../../utils/getImageUrl";
import Button from "../../components/common/Button";
import SEO from "../../components/common/SEO";

const Portfolio = () => {
  const { data: projectsData, loading: projectsLoading } =
    useFetch("/projects");
  const { data: settingsData } = useFetch("/settings?group=portfolio");
  const { data: catData } = useFetch("/projects/categories");
  const [activeCategory, setActiveCategory] = useState("All");

  const settings = settingsData?.data || {};
  const categories = useMemo(
    () => ["All", ...(catData?.data || [])],
    [catData],
  );

  const filteredProjects = useMemo(() => {
    const allProjects = projectsData?.data || [];
    return activeCategory === "All"
      ? allProjects
      : allProjects.filter((p) => p.category === activeCategory);
  }, [projectsData, activeCategory]);

  return (
    <div className="min-h-screen bg-[var(--background)] text-white selection:bg-primary-500/30 overflow-x-hidden">
      <SEO 
        title="Portfolio" 
        description="Explore our archive of strategic digital products and case studies engineered for operational superiority and market dominance." 
        keywords="portfolio, case studies, digital products, software engineering projects"
      />
      {/* 1. CINEMATIC HERO */}
      <section className="relative min-h-[70svh] flex items-center overflow-hidden border-b border-white/5 pt-32 pb-20">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(var(--primary-500)/0.1),_transparent_70%)]" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 w-full">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8 max-w-4xl"
          >
            <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-primary-500/5 border border-primary-500/10 mb-2">
              <Layers size={14} className="text-primary-400" />
              <span className="text-primary-400 font-black tracking-[0.4em] uppercase text-[9px]">
                Case Studies
              </span>
            </div>

            <h1 className="text-5xl md:text-7xl font-black font-sora leading-[1.02] tracking-tighter mb-10 text-white max-w-4xl">
              {(settings.portfolio_hero_title || "Portfolio Archive")
                .split(" ")
                .map((word, i, arr) => (
                  <span
                    key={i}
                    className={
                      i >= arr.length - 1
                        ? "text-gradient inline-block"
                        : "text-white"
                    }
                  >
                    {word}{" "}
                  </span>
                ))}
            </h1>
            <p className="max-w-2xl text-gray-400 text-base md:text-lg font-medium leading-relaxed border-l-2 border-primary-500/30 pl-6">
              {settings.portfolio_hero_subtitle ||
                "Strategic digital products engineered for operational superiority and market dominance."}
            </p>
          </motion.div>
        </div>
      </section>

      {/* 2. DYNAMIC FILTER NAVIGATION */}
      <section className="sticky top-16 md:top-20 z-40 py-4 md:py-6 bg-[var(--background)]/80 backdrop-blur-3xl border-y border-white/5">
        <div className="max-w-7xl mx-auto px-6 overflow-x-auto no-scrollbar">
          <div className="flex items-center md:justify-center space-x-3 md:space-x-4 min-w-max">
            <Filter size={12} className="text-gray-600 mr-2 hidden md:block" />
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`relative px-4 md:px-6 py-2 md:py-2.5 rounded-full text-[8px] md:text-[10px] font-black uppercase tracking-widest transition-all duration-300 ${
                  activeCategory === cat
                    ? "text-white"
                    : "text-gray-500 hover:text-white"
                }`}
              >
                {activeCategory === cat && (
                  <motion.div
                    layoutId="portfolioActive"
                    className="absolute inset-0 bg-primary-600 rounded-full -z-10 shadow-lg shadow-primary-500/40"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 3. PROJECT GRID */}
      <section className="py-16 md:py-24 px-6 max-w-7xl mx-auto">
        {projectsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-10 animate-pulse">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div
                key={i}
                className="aspect-[16/10] bg-white/5 rounded-3xl border border-white/10"
              />
            ))}
          </div>
        ) : filteredProjects.length > 0 ? (
          <motion.div
            layout
            className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12"
          >
            <AnimatePresence mode="popLayout">
              {filteredProjects.map((project, idx) => (
                <motion.div
                  key={project._id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="group"
                >
                  <div className="relative aspect-[16/11] md:aspect-[16/10] rounded-[1.5rem] md:rounded-[2.5rem] overflow-hidden border border-white/10 bg-[#0f172a] shadow-2xl transition-all duration-700 md:group-hover:border-primary-500/30">
                    {/* Media Component */}
                    <div className="absolute inset-0 overflow-hidden">
                      {project.images && project.images.length > 0 ? (
                        <img
                          src={getImageUrl(project.images[0])}
                          alt={project.title}
                          loading="lazy"
                          decoding="async"
                          className="w-full h-full object-cover transition-transform duration-1000 md:group-hover:scale-110"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-white/5 font-black text-2xl md:text-4xl">
                          ARCHIVE
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-[#020617]/50 to-transparent opacity-90" />
                    </div>

                    {/* Content Overlay */}
                    <div className="absolute inset-0 p-6 md:p-10 flex flex-col justify-end">
                      <div className="space-y-3 md:space-y-4">
                        <div className="flex items-center space-x-3">
                          <div className="h-0.5 w-4 md:w-6 bg-primary-500" />
                          <span className="text-primary-400 font-black uppercase text-[7px] md:text-[9px] tracking-[0.4em]">
                            CASE STUDY 0{idx + 1}
                          </span>
                        </div>

                        <h3 className="text-xl md:text-2xl font-extrabold font-sora text-white leading-tight break-words">
                          {project.title}
                        </h3>

                        <div className="flex flex-wrap gap-2 md:gap-4 pt-1 md:pt-2">
                          <div className="flex items-center space-x-2 px-2.5 md:px-3 py-1 md:py-1.5 rounded-lg bg-white/5 border border-white/10 min-w-0">
                            <Globe
                              size={10}
                              className="text-gray-400 shrink-0"
                            />
                            <span className="text-[8px] md:text-[10px] font-bold text-gray-300 uppercase tracking-wider truncate">
                              {project.client || "Secret Client"}
                            </span>
                          </div>
                          <div className="flex items-center space-x-2 px-2.5 md:px-3 py-1 md:py-1.5 rounded-lg bg-white/5 border border-white/10 min-w-0">
                            <Cpu size={10} className="text-gray-400 shrink-0" />
                            <span className="text-[8px] md:text-[10px] font-bold text-gray-300 uppercase tracking-wider truncate">
                              {project.category}
                            </span>
                          </div>
                        </div>

                        <div className="pt-5 md:pt-8 md:opacity-0 md:group-hover:opacity-100 md:translate-y-4 md:group-hover:translate-y-0 transition-all duration-500">
                          <Button className="h-10 md:h-14 px-6 md:px-8 text-[8px] md:text-[10px] font-black uppercase tracking-widest shadow-xl shadow-primary-500/20">
                            <span>View Case Study</span>
                            <ArrowRight size={14} className="ml-2 md:ml-3" />
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Floating Info */}
                    <div className="absolute top-4 md:top-8 right-4 md:right-8">
                      <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl glass-card flex items-center justify-center md:opacity-0 md:group-hover:opacity-100 transition-opacity">
                        <ExternalLink
                          size={16}
                          md:size={18}
                          className="text-white"
                        />
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        ) : (
          <div className="text-center py-24 md:py-32 bg-white/[0.01] border border-white/5 rounded-[2.5rem] md:rounded-[4rem] backdrop-blur-3xl px-6">
            <ShieldCheck
              size={48}
              md:size={64}
              className="text-primary-500/20 mx-auto mb-6 md:mb-8"
            />
            <h3 className="text-xl md:text-3xl font-black font-sora text-white/30 uppercase tracking-widest leading-tight">
              Repository Locked
            </h3>
            <p className="text-gray-500 max-w-sm mx-auto mt-4 font-medium uppercase text-[8px] md:text-[10px] tracking-[0.4em] leading-relaxed">
              Retrieving latest digital insights...
            </p>
          </div>
        )}
      </section>

      {/* 4. CTA FOOTER */}
      <section className="py-20 md:py-24 border-t border-white/5 mt-10 md:mt-20">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-fluid-section-title font-bold font-sora mb-8 md:mb-10 tracking-tighter leading-tight">
            Ready to Start Your{" "}
            <span className="text-gradient">Transformation?</span>
          </h2>
          <div className="flex justify-center">
            <Link to="/contact" className="w-full sm:w-auto">
              <Button
                variant="primary"
                className="h-14 md:h-16 px-10 md:px-12 text-xs md:text-sm font-black uppercase tracking-[0.3em] w-full"
              >
                <span>Get In Touch</span>
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Portfolio;
