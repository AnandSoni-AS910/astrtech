import React from "react";
import { Scale, ShieldCheck, Zap, Globe, AlertCircle, FileCheck } from "lucide-react";
import { motion } from "framer-motion";
import SEO from "../../components/common/SEO";

const TermsOfService = () => {
  const sections = [
    {
      icon: <Scale className="text-primary-400" />,
      title: "Agreement to Terms",
      content: "By accessing our global technical ecosystem, you agree to be bound by these strategic terms of service. These protocols govern your use of IT Tech's platforms, neural networks, and engineering services.",
    },
    {
      icon: <ShieldCheck className="text-emerald-400" />,
      title: "Intellectual Property Rights",
      content: "All source code, tactical architectures, neural designs, and digital assets within our platform are the exclusive intellectual property of IT Tech. Unauthorized reproduction or reverse engineering is strictly prohibited.",
    },
    {
      icon: <Zap className="text-amber-400" />,
      title: "Service Deployment Limits",
      content: "Users must adhere to acceptable use protocols. Any attempts to disrupt our infrastructure, bypass neural security layers, or deploy adversarial scripts will result in immediate termination of access.",
    },
    {
      icon: <Globe className="text-blue-400" />,
      title: "Limitation of Liability",
      content: "While we strive for 100% operational resilience, IT Tech shall not be liable for any indirect, consequential, or tactical damages arising from system optimizations or global network synchronization.",
    },
    {
      icon: <AlertCircle className="text-red-400" />,
      title: "Dispute Resolution",
      content: "Any disagreements regarding service deployment shall be resolved through strategic negotiation or within the jurisdiction of our global headquarters, governed by international commercial laws.",
    },
  ];

  return (
    <div className="min-h-screen bg-[#020617] text-white pt-32 pb-24 px-6 relative overflow-hidden">
      <SEO 
        title="Terms of Service" 
        description="Understand the strategic frameworks and operational boundaries that govern your interaction with ITTech's high-end technical services." 
        keywords="terms of service, legal protocols, service agreement, global governance"
      />
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-indigo-600/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-primary-600/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-4xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-6 mb-20"
        >
          <div className="inline-flex items-center space-x-3 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-xl">
            <FileCheck className="text-primary-500" size={14} />
            <span className="text-[10px] font-black uppercase tracking-[0.4em] text-primary-400">Legal Protocol v1.9</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold font-sora tracking-tighter">Terms of <span className="text-gradient">Service</span></h1>
          <p className="text-gray-400 max-w-2xl mx-auto font-medium">
            Understand the strategic frameworks and operational boundaries that govern your interaction with our high-end technical services.
          </p>
        </motion.div>

        <div className="space-y-12">
          {sections.map((section, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group p-1 bg-gradient-to-br from-white/10 to-transparent rounded-[2rem] hover:from-primary-500/30 transition-all duration-500"
            >
              <div className="bg-[#020617] rounded-[1.95rem] p-8 md:p-12 space-y-6">
                <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10 group-hover:bg-primary-500/10 group-hover:border-primary-500/30 transition-all">
                  {section.icon}
                </div>
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold font-sora text-white">{section.title}</h3>
                  <p className="text-gray-400 leading-relaxed font-medium">
                    {section.content}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-20 text-center space-y-6"
        >
          <p className="text-sm text-gray-500 font-medium">
            Continued use of our infrastructure constitutes acceptance of these operational protocols.
          </p>
          <div className="flex items-center justify-center space-x-4">
            <div className="h-px w-12 bg-white/10" />
            <span className="text-[10px] font-black uppercase tracking-widest text-primary-500">Global Governance 2026</span>
            <div className="h-px w-12 bg-white/10" />
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default TermsOfService;
