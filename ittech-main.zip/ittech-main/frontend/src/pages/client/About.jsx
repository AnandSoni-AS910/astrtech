import React from "react";
// eslint-disable-next-line no-unused-vars
import { motion } from "framer-motion";
import {
  Users,
  Rocket,
  ShieldCheck,
  Globe,
  Zap,
  Cpu,
  ArrowRight,
  MessageSquare,
  Activity,
  BarChart3,
  Database,
  Quote,
} from "lucide-react";
import useFetch from "../../hooks/useFetch";
import Button from "../../components/common/Button";
import GlassCard from "../../components/common/GlassCard";
import SEO from "../../components/common/SEO";
import getImageUrl from "../../utils/getImageUrl";

const About = () => {
  const { data: aboutSettingsData } = useFetch("/settings?group=about");
  const { data: homeSettingsData } = useFetch("/settings?group=home");
  const { data: testimonialsData } = useFetch(
    "/testimonials?limit=3&sort=-createdAt",
  );

  const settings = aboutSettingsData?.data || {};
  const homeSettings = homeSettingsData?.data || {};
  const testimonials = testimonialsData?.data || [];

  const stats = [
    {
      label: homeSettings.home_stat1_label || "Enterprise Solutions",
      value: homeSettings.home_stat1_value || "500+",
      icon: <Rocket className="text-blue-400" />,
    },
    {
      label: homeSettings.home_stat2_label || "Global Data Centers",
      value: homeSettings.home_stat2_value || "24",
      icon: <Database className="text-emerald-400" />,
    },
    {
      label: homeSettings.home_stat3_label || "Expert Consultants",
      value: homeSettings.home_stat3_value || "150+",
      icon: <Users className="text-purple-400" />,
    },
    {
      label: homeSettings.home_stat4_label || "Secure Transactions",
      value: homeSettings.home_stat4_value || "99.9%",
      icon: <ShieldCheck className="text-pink-400" />,
    },
  ];

  const coreValues = [
    {
      title: settings.about_value1_title || "Resilient Architecture",
      desc:
        settings.about_value1_desc ||
        "We build systems that withstand extreme load and adversarial conditions, ensuring 100% operational continuity.",
      icon: <Cpu size={24} />,
      color: "from-blue-600/20 to-blue-400/20",
    },
    {
      title: settings.about_value2_title || "Tactical Innovation",
      desc:
        settings.about_value2_desc ||
        "Our R&D division focuses on immediate utility, deploying AI and cloud solutions that solve real-world bottlenecks.",
      icon: <Zap size={24} />,
      color: "from-emerald-600/20 to-emerald-400/20",
    },
    {
      title: settings.about_value3_title || "Global Sovereignty",
      desc:
        settings.about_value3_desc ||
        "Managing data across 50+ jurisdictions with military-grade privacy and localized compliance synchronization.",
      icon: <Globe size={24} />,
      color: "from-purple-600/20 to-purple-400/20",
    },
  ];

  const heroTitle =
    settings.about_hero_title || "The Architects of Digital Resilience";
  const heroSubtitle =
    settings.about_hero_subtitle ||
    "Empowering global conglomerates with high-end technical superiority and autonomous digital ecosystems since 2018.";
  const nodeLevels = [72, 58, 81, 66];
  return (
    <div className="min-h-screen bg-[var(--background)] text-white selection:bg-primary-500/30 overflow-x-hidden">
      <SEO 
        title="About Us" 
        description="Learn more about ITTech - our mission, vision, and the architects behind our digital resilience and tactical innovation." 
        keywords="about ITTech, company mission, technical expertise, software architects"
      />
      {/* 1. CINEMATIC HERO SECTION */}
      <section className="relative min-h-[100svh] flex items-center justify-center overflow-hidden border-b border-white/5 pt-28 pb-16 md:pt-36 md:pb-24 px-4 md:px-0">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-0 left-0 w-full h-[500px] bg-primary-600/5 blur-[120px] rounded-full -translate-y-1/2" />
          <div className="absolute inset-0 bg-gradient-to-b from-[var(--background)] via-transparent to-[var(--background)]" />
        </div>

        <div className="max-w-7xl mx-auto px-6 relative z-10 w-full">
          <div className="flex flex-col lg:flex-row items-center gap-16 lg:gap-24">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="w-full lg:w-[65%] text-center lg:text-left space-y-8"
            >
              <div className="inline-flex items-center space-x-3 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 mb-2 backdrop-blur-md">
                <div className="w-1.5 h-1.5 rounded-full bg-primary-500 animate-pulse" />
                <span className="text-primary-400 font-black tracking-[0.3em] uppercase text-[8px]">
                  Operational Protocol v5.0
                </span>
              </div>

              <h1 className="text-5xl md:text-7xl font-black font-sora leading-[1.02] tracking-tighter mb-10 text-white max-w-4xl">
                {heroTitle.split(" ").map((word, i, arr) => (
                  <span
                    key={i}
                    className={i >= arr.length - 2 ? "text-gradient" : ""}
                  >
                    {word}{" "}
                  </span>
                ))}
              </h1>

              <p className="text-gray-400 text-base md:text-xl font-medium leading-relaxed max-w-2xl mx-auto lg:mx-0 border-l-2 border-primary-500/30 pl-5 md:pl-6">
                {heroSubtitle}
              </p>

              <div className="flex flex-col sm:flex-row items-center gap-6 pt-4 justify-center lg:justify-start">
                <Button className="w-full sm:w-auto h-14 px-10 group shadow-xl">
                  <span>Explore Mission</span>
                  <ArrowRight
                    size={18}
                    className="ml-3 group-hover:translate-x-1 transition-transform"
                  />
                </Button>
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-[1px] bg-white/20" />
                  <span className="text-[9px] uppercase font-black tracking-[0.2em] text-white/30 whitespace-nowrap">
                    Est. Deployment 2018
                  </span>
                </div>
              </div>
            </motion.div>

            {/* Tactical System Grid */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="w-full lg:w-[35%] grid grid-cols-1 xs:grid-cols-2 gap-4 relative"
            >
              {[1, 2, 3, 4].map((i) => (
                <div
                  key={i}
                  className="rounded-2xl border border-white/5 bg-white/[0.03] backdrop-blur-xl p-5 space-y-4 group hover:border-primary-500/20 transition-all duration-500"
                >
                  <div className="flex items-center justify-between">
                    <div className="w-8 h-8 rounded-lg bg-primary-500/10 flex items-center justify-center text-primary-400">
                      {i === 1 && <Cpu size={16} />}
                      {i === 2 && <ShieldCheck size={16} />}
                      {i === 3 && <Activity size={16} />}
                      {i === 4 && <BarChart3 size={16} />}
                    </div>
                    <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">
                      0{i}
                    </span>
                  </div>

                  <div className="space-y-2">
                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${nodeLevels[i - 1]}%` }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          repeatType: "reverse",
                        }}
                        className="h-full bg-primary-500/40"
                      />
                    </div>
                    <div className="flex justify-between items-center bg-black/20 rounded p-1.5">
                      <span className="text-[7px] font-black uppercase text-gray-500">
                        Node Status
                      </span>
                      <span className="text-[7px] font-black text-emerald-400 uppercase">
                        Active
                      </span>
                    </div>
                  </div>
                </div>
              ))}

              {/* Decorative Accent */}
              <div className="absolute -inset-4 bg-primary-500/5 blur-[40px] -z-10 rounded-full" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* 2. CORE INTELLIGENCE STATS */}
      <section className="py-20 relative overflow-hidden border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-12 md:gap-8">
            {stats.map((stat, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="text-center space-y-4"
              >
                <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-white/5 mx-auto flex items-center justify-center text-xl md:text-2xl shadow-inner border border-white/5">
                  {stat.icon}
                </div>
                <div className="space-y-1">
                  <h3 className="text-2xl md:text-4xl font-extrabold font-sora text-white">
                    {stat.value}
                  </h3>
                  <p className="text-[9px] md:text-[10px] font-black uppercase tracking-widest text-gray-500">
                    {stat.label}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. OPERATIONS & MISSION (BENTO) */}
      <section className="py-24 md:py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 md:mb-20 space-y-4 md:space-y-6">
            <span className="text-primary-500 font-black tracking-[.5em] uppercase text-[10px]">
              Strategic Framework
            </span>
            <h2 className="text-fluid-section-title font-bold font-sora tracking-tighter text-white leading-tight">
              How We Re-Engineer <br />
              <span className="text-gradient underline decoration-primary-500/30">
                Digital Enterprise
              </span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {coreValues.map((value, idx) => (
              <motion.div
                key={idx}
                whileHover={{ y: -10 }}
                className={`relative p-8 md:p-10 rounded-[2.5rem] border border-white/5 flex flex-col h-full bg-gradient-to-br ${value.color} backdrop-blur-3xl group transition-all duration-500`}
              >
                <div className="mb-8 w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-white/5 flex items-center justify-center text-primary-400 border border-white/10 group-hover:rotate-[10deg] transition-transform">
                  {value.icon}
                </div>
                <h3 className="text-xl md:text-2xl font-bold font-sora text-white mb-4 tracking-tight">
                  {value.title}
                </h3>
                <p className="text-sm md:text-base text-gray-400 font-medium leading-relaxed opacity-80">
                  {value.desc}
                </p>

                <div className="mt-8 pt-8 border-t border-white/5 mt-auto">
                  <div className="flex items-center space-x-2 text-[10px] font-black text-primary-400 uppercase tracking-[0.2em]">
                    <span>Read Whitepaper</span>
                    <ArrowRight size={12} />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. THE NERVE CENTER (COMPANY STORY) */}
      <section className="py-24 md:py-32 bg-white/[0.01] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-12 md:gap-20 items-center">
            <div className="w-full lg:w-1/2 relative">
              <div className="relative z-10 rounded-[2.5rem] md:rounded-[3rem] overflow-hidden border border-white/10 shadow-2xl">
                <img
                  src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=1000"
                  alt="Operation Room"
                  loading="lazy"
                  decoding="async"
                  className="w-full aspect-[4/3] object-cover grayscale hover:grayscale-0 transition-all duration-1000"
                />
                <div className="absolute inset-0 bg-primary-600/10 mix-blend-overlay" />
              </div>
              {/* Floating Data Point */}
              <GlassCard className="absolute -bottom-6 -right-6 md:-bottom-10 md:-right-10 p-4 md:p-6 z-20 scale-90 md:scale-100">
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-emerald-500 rounded-xl">
                    <Activity className="text-white" size={20} />
                  </div>
                  <div>
                    <p className="text-[10px] text-gray-400 font-bold uppercase">
                      System Uptime
                    </p>
                    <p className="text-lg md:text-xl font-black text-white leading-none">
                      {settings.about_uptime_value || "99.999%"}
                    </p>
                  </div>
                </div>
              </GlassCard>
            </div>

            <div className="w-full lg:w-1/2 space-y-8 md:space-y-10">
              <div className="space-y-4">
                <span className="text-primary-500 font-black tracking-[.5em] uppercase text-[9px]">
                  Our Foundation
                </span>
                <h2 className="text-fluid-section-title font-bold font-sora tracking-tighter text-white leading-tight">
                  {settings.about_mission_title ||
                    "Innovation Built on Expert Foundations."}
                </h2>
              </div>

              <div className="space-y-6 text-gray-400 font-medium leading-relaxed text-base md:text-lg">
                <p>
                  {settings.about_mission_p1 ||
                    "Founded at the intersection of high-frequency trading and automotive automation, we recognized a critical gap in enterprise infrastructure: Resilience."}
                </p>
                <p>
                  {settings.about_mission_p2 ||
                    "In an era where a 10-millisecond delay costs millions, our mission shifted to building the world's most robust digital nervous systems."}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 md:gap-8 pt-4">
                <div className="space-y-1">
                  <h4 className="text-xs md:text-sm font-bold text-white uppercase tracking-widest text-primary-400">
                    {settings.about_hq_label || "Headquarters"}
                  </h4>
                  <p className="text-sm text-gray-500 leading-relaxed">
                    {settings.about_hq_value ||
                      "Global Tactical Node 01 Singapore Financial District"}
                  </p>
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs md:text-sm font-bold text-white uppercase tracking-widest text-primary-400">
                    {settings.about_collab_label || "Collaborations"}
                  </h4>
                  <p className="text-sm text-gray-500 leading-relaxed">
                    {settings.about_collab_value ||
                      "Fortune 100 Leaders Gov-Tech Agencies"}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4.5 TESTIMONIALS (PARTNER INTEL) */}
      {testimonials.length > 0 && (
        <section className="py-32 relative z-10 border-b border-white/5">
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex flex-col md:flex-row justify-between items-end gap-8 mb-20">
              <div className="space-y-6">
                <span className="text-primary-500 font-black tracking-[0.5em] uppercase text-[10px]">
                  Strategic Reviews
                </span>
                <h2 className="text-fluid-section-title font-bold font-sora tracking-tighter">
                  Voices of Resilience
                </h2>
              </div>
              <p className="text-gray-500 text-sm max-w-sm font-medium">
                Verifiable feedback from our most critical global integrations
                and strategic partnerships.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {testimonials.map((testimonial, i) => (
                <GlassCard
                  key={testimonial._id || i}
                  delay={i * 0.1}
                  className="p-10 flex flex-col h-full group"
                >
                  <div className="mb-8">
                    <Quote
                      size={40}
                      className="text-primary-500/20 group-hover:text-primary-500/40 transition-colors"
                    />
                  </div>
                  <p className="text-gray-400 font-medium leading-relaxed mb-10 flex-1">
                    "{testimonial.text}"
                  </p>
                  <div className="flex items-center space-x-4 border-t border-white/5 pt-8">
                    <div className="w-20 h-20 rounded-xl overflow-hidden border border-white/10 bg-white/5 flex-shrink-0">
                      {testimonial.image &&
                      testimonial.image !== "no-photo.jpg" ? (
                        <img
                          src={getImageUrl(testimonial.image)}
                          alt={testimonial.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-700">
                          <Users size={32} />
                        </div>
                      )}
                    </div>
                    <div>
                      <h4 className="text-white font-bold text-sm font-sora">
                        {testimonial.name}
                      </h4>
                      <p className="text-primary-400 text-[10px] font-black uppercase tracking-widest mt-1">
                        {testimonial.role}{" "}
                        <span className="text-gray-600">/</span>{" "}
                        {testimonial.company}
                      </p>
                    </div>
                  </div>
                </GlassCard>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* 5. CALL TO ACTION - JOIN THE ECOSYSTEM */}
      <section className="py-24 md:py-32 relative text-center overflow-hidden px-6">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-primary-600/5 blur-[120px] -z-10 rounded-full" />

        <div className="max-w-4xl mx-auto space-y-10 md:space-y-12">
          <h2 className="text-fluid-section-title font-bold font-sora tracking-tighter text-white leading-tight">
            {settings.about_cta_title || "Transform Your Enterprise Future"}
          </h2>
          <p className="text-gray-400 text-lg md:text-xl font-medium max-w-2xl mx-auto leading-relaxed">
            {settings.about_cta_subtitle ||
              "Ready to transition from generic digital presence to strategic high-end infrastructure?"}
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 md:gap-8">
            <Button className="w-full sm:w-auto h-16 px-12 group">
              <MessageSquare size={18} className="mr-3" />
              <span>Initiate Briefing</span>
            </Button>
            <button className="text-white font-black uppercase tracking-[0.2em] text-[10px] hover:text-primary-400 transition-colors py-4">
              View Technical Capabilities
            </button>
          </div>
        </div>
      </section>

      {/* Scroll Progress Bar */}
    </div>
  );
};

export default About;
