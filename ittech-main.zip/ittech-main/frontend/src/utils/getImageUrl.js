const getImageUrl = (path) => {
  if (!path) return null;
  if (path.startsWith('http')) return path;
  
  // Normalize path if it uses backslashes (Windows)
  const normalizedPath = path.replace(/\\/g, '/');
  
  // Use VITE_API_URL and remove '/api' suffix to get server root
  const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
  const serverRoot = apiUrl.replace('/api', '');
  
  return `${serverRoot}/${normalizedPath}`;
};

export default getImageUrl;
