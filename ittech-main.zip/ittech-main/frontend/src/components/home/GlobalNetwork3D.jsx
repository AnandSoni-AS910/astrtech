import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import worldData from '../../assets/world.json';

const GlobalNetwork3D = () => {
  const containerRef = useRef();

  useEffect(() => {
    if (!containerRef.current) return;

    // Track resources for clean disposal
    const geometries = [];
    const materials = [];
    const addGeometry = (g) => { geometries.push(g); return g; };
    const addMaterial = (m) => { materials.push(m); return m; };

    // --- Scene Setup ---
    const scene = new THREE.Scene();
    const container = containerRef.current;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;
    const isMobile = width < 768;
    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Camera - wider for "background" feel
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 2000);
    
    const updateCameraPosition = (w, h) => {
      const aspect = w / h;
      camera.aspect = aspect;
      if (aspect < 1) {
        // Scale camera distance dynamically for narrow mobile screens
        camera.position.z = Math.min(280 / aspect, 550);
      } else {
        camera.position.z = 280;
      }
      camera.updateProjectionMatrix();
    };
    
    updateCameraPosition(width, height);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isMobile,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, isMobile ? 1 : 2));
    container.appendChild(renderer.domElement);

    // --- Globe Group ---
    const globeGroup = new THREE.Group();
    scene.add(globeGroup);

    // India Lat/Lon
    const indiaLat = 20.5937;
    const indiaLon = 78.9629;
    const globeRadius = 100;

    // --- Latitude/Longitude to 3D Cartesian ---
    const latLonToVec3 = (lat, lon, radius) => {
      const phi = (90 - lat) * (Math.PI / 180);
      const theta = (lon + 180) * (Math.PI / 180);
      const x = -radius * Math.sin(phi) * Math.cos(theta);
      const y = radius * Math.cos(phi);
      const z = radius * Math.sin(phi) * Math.sin(theta);
      return new THREE.Vector3(x, y, z);
    };

    // Rotate globe initially so India faces camera
    globeGroup.rotation.y = - (indiaLon + 90) * (Math.PI / 180);
    globeGroup.rotation.x = (indiaLat) * (Math.PI / 180);

    // --- Dotted World Map ---
    const dotsGeometry = addGeometry(new THREE.BufferGeometry());
    const dotsPositions = [];

    if (worldData && worldData.features) {
      worldData.features.forEach(feature => {
        if (!feature.geometry) return;
        const type = feature.geometry.type;
        const coordinates = feature.geometry.coordinates;

        const processPolygon = (polygon) => {
          polygon.forEach(ring => {
            for (let i = 0; i < ring.length; i += 2) {
              const [lon, lat] = ring[i];
              const vec = latLonToVec3(lat, lon, globeRadius);
              dotsPositions.push(vec.x, vec.y, vec.z);
            }
          });
        };

        if (type === 'Polygon') {
          processPolygon(coordinates);
        } else if (type === 'MultiPolygon') {
          coordinates.forEach(polygon => processPolygon(polygon));
        }
      });
    }

    dotsGeometry.setAttribute('position', new THREE.Float32BufferAttribute(dotsPositions, 3));
    const dotsMaterial = addMaterial(new THREE.PointsMaterial({
      color: 0x6366f1, // primary-500
      size: isMobile ? 0.9 : 1.2,
      transparent: true,
      opacity: 0.7, // Increased opacity
      blending: THREE.AdditiveBlending
    }));
    const dots = new THREE.Points(dotsGeometry, dotsMaterial);
    globeGroup.add(dots);

    // --- Stars Background ---
    const starsGeometry = addGeometry(new THREE.BufferGeometry());
    const starsCount = isMobile ? 260 : 600;
    const starsPos = new Float32Array(starsCount * 3);
    for (let i = 0; i < starsCount * 3; i++) {
        starsPos[i] = (Math.random() - 0.5) * 1000;
    }
    starsGeometry.setAttribute('position', new THREE.BufferAttribute(starsPos, 3));
    const starsMaterial = addMaterial(new THREE.PointsMaterial({ color: 0x818cf8, size: 0.8, transparent: true, opacity: 0.5 }));
    const stars = new THREE.Points(starsGeometry, starsMaterial);
    scene.add(stars);

    // --- Global Hubs ---
    const hubs = [
      { name: 'India', lat: 20.59, lon: 78.96, isMain: true },
      { name: 'New York', lat: 40.71, lon: -74.00 },
      { name: 'London', lat: 51.50, lon: -0.12 },
      { name: 'Tokyo', lat: 35.67, lon: 139.65 },
      { name: 'Sydney', lat: -33.86, lon: 151.20 },
      { name: 'Singapore', lat: 1.35, lon: 103.81 },
    ];

    const indiaVec = latLonToVec3(hubs[0].lat, hubs[0].lon, globeRadius);
    const hubsData = [];

    // Shared Hub Geometries and Materials for massive draw call / memory savings
    const mainMarkerGeom = addGeometry(new THREE.SphereGeometry(1.5, 12, 12));
    const regularMarkerGeom = addGeometry(new THREE.SphereGeometry(0.8, 12, 12));
    
    const mainMarkerMat = addMaterial(new THREE.MeshBasicMaterial({ 
      color: 0xffd700,
      transparent: true,
      opacity: 0.9
    }));
    const regularMarkerMat = addMaterial(new THREE.MeshBasicMaterial({ 
      color: 0xec4899,
      transparent: true,
      opacity: 0.9
    }));

    const glowGeom = addGeometry(new THREE.SphereGeometry(3, 16, 16));
    const glowMat = addMaterial(new THREE.MeshBasicMaterial({ color: 0xffd700, transparent: true, opacity: 0.2 }));
    
    const curveMat = addMaterial(new THREE.LineBasicMaterial({ color: 0x818cf8, transparent: true, opacity: 0.3 }));
    
    const pMatEven = addMaterial(new THREE.PointsMaterial({ 
      color: 0x10b981, 
      size: 2.5, 
      transparent: true, 
      opacity: 0.9,
      blending: THREE.AdditiveBlending 
    }));
    
    const pMatOdd = addMaterial(new THREE.PointsMaterial({ 
      color: 0xfacc15, 
      size: 2.5, 
      transparent: true, 
      opacity: 0.9,
      blending: THREE.AdditiveBlending 
    }));

    hubs.forEach((hub, idx) => {
      const vec = latLonToVec3(hub.lat, hub.lon, globeRadius);
      
      // Marker
      const marker = new THREE.Mesh(
        hub.isMain ? mainMarkerGeom : regularMarkerGeom, 
        hub.isMain ? mainMarkerMat : regularMarkerMat
      );
      marker.position.copy(vec);
      globeGroup.add(marker);

      if (hub.isMain) {
        // Pulse Glow
        const glow = new THREE.Mesh(glowGeom, glowMat);
        glow.position.copy(vec);
        globeGroup.add(glow);
        hub.glow = glow;
      }

      if (!hub.isMain) {
        // Curve
        const midPoint = new THREE.Vector3().addVectors(indiaVec, vec).multiplyScalar(0.5).normalize().multiplyScalar(globeRadius + indiaVec.distanceTo(vec) * 0.3);
        const curve = new THREE.QuadraticBezierCurve3(indiaVec, midPoint, vec);
        const curvePoints = curve.getPoints(50);
        const curveGeom = addGeometry(new THREE.BufferGeometry().setFromPoints(curvePoints));
        const line = new THREE.Line(curveGeom, curveMat);
        globeGroup.add(line);

        // Particles
        const pCount = 12;
        const pGeom = addGeometry(new THREE.BufferGeometry());
        pGeom.setAttribute('position', new THREE.BufferAttribute(new Float32Array(pCount * 3), 3));
        const pPoints = new THREE.Points(pGeom, idx % 2 === 0 ? pMatEven : pMatOdd);
        globeGroup.add(pPoints);
        
        // Precompute points along the curve to eliminate expensive math in the animation loop
        const cachedPoints = curve.getPoints(200);
        
        hubsData.push({
          cachedPoints,
          pPoints,
          particles: Array.from({ length: pCount }, () => ({ t: Math.random() }))
        });
      }
    });

    // --- Lights ---
    const ambientLight = new THREE.AmbientLight(0xffffff, isMobile ? 1.0 : 0.8);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0xffd700, isMobile ? 3 : 2, 400);
    pointLight.position.copy(indiaVec);
    globeGroup.add(pointLight);

    // --- Animation Logic ---
    let frame = 0;
    let mouseX = 0, mouseY = 0;
    
    const onMouseMove = (e) => {
      mouseX = (e.clientX - window.innerWidth / 2) / 200;
      mouseY = (e.clientY - window.innerHeight / 2) / 200;
    };
    window.addEventListener('mousemove', onMouseMove);

    let isVisible = true;
    const visibilityObserver = new IntersectionObserver(
      ([entry]) => {
        isVisible = entry?.isIntersecting ?? true;
      },
      { threshold: 0.05 },
    );
    visibilityObserver.observe(container);

    const animate = () => {
      frameId = requestAnimationFrame(animate);

      // Critical Optimization: Do not waste CPU/GPU resources when invisible
      if (!isVisible || document.hidden || prefersReducedMotion) {
        return;
      }

      frame += 0.01;

      // Auto rotation
      globeGroup.rotation.y += isMobile ? 0.001 : 0.0015;

      // Interaction Parallax
      scene.rotation.y += (mouseX - scene.rotation.y) * 0.05;
      scene.rotation.x += (mouseY - scene.rotation.x) * 0.05;

      // Pulse main hub
      if (hubs[0].glow) {
        const s = 1 + Math.sin(frame * 4) * 0.4;
        hubs[0].glow.scale.set(s, s, s);
        hubs[0].glow.material.opacity = 0.25 - (s - 1) * 0.5;
      }

      // Animate particles (Hyper-optimized path tracking)
      hubsData.forEach((hd) => {
        const posAttr = hd.pPoints.geometry.attributes.position;
        const cacheCount = hd.cachedPoints.length;
        hd.particles.forEach((p, i) => {
          p.t += isMobile ? 0.003 : 0.004;
          if (p.t > 1) p.t = 0;
          
          // Use precomputed path index to eliminate object allocation and complex math
          const cacheIdx = Math.floor(p.t * (cacheCount - 1));
          const pos = hd.cachedPoints[cacheIdx];
          
          posAttr.array[i * 3] = pos.x;
          posAttr.array[i * 3 + 1] = pos.y;
          posAttr.array[i * 3 + 2] = pos.z;
        });
        posAttr.needsUpdate = true;
      });

      renderer.render(scene, camera);
    };

    let frameId = requestAnimationFrame(animate);

    // Clean & responsive container sizing with ResizeObserver
    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const { width: w, height: h } = entries[0].contentRect;
      if (w === 0 || h === 0) return;
      
      updateCameraPosition(w, h);
      renderer.setSize(w, h, false);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, w < 768 ? 1 : 2));
    });
    resizeObserver.observe(container);

    const handleVisibilityChange = () => {
      if (!document.hidden && isVisible && !prefersReducedMotion) {
        renderer.render(scene, camera);
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      
      visibilityObserver.disconnect();
      resizeObserver.disconnect();
      
      if (container && renderer.domElement) {
        container.removeChild(renderer.domElement);
      }
      
      // Memory Leak Fix: Explicitly dispose of all geometries and materials to free GPU memory
      geometries.forEach(geom => geom.dispose());
      materials.forEach(mat => mat.dispose());
      
      renderer.dispose();
    };
  }, []);

  return (
    <div ref={containerRef} className="w-full h-full min-h-[400px] relative pointer-events-none overflow-hidden">
      {/* Glow Effect */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 bg-primary-500/10 blur-[80px] rounded-full pointer-events-none -z-10" />
    </div>
  );
};

export default GlobalNetwork3D;
