import React from 'react';
import { X } from 'lucide-react';
import { motion as Motion, AnimatePresence } from 'framer-motion';
import Button from '../common/Button';

const FormModal = ({ isOpen, onClose, title, onSubmit, children, loading }) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[200] flex items-center justify-center px-4">
        <Motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-black/60 backdrop-blur-sm" 
          onClick={onClose} 
        />
        <Motion.div 
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className="relative bg-[#0f172a] border border-white/10 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col"
        >
          <div className="flex justify-between items-center p-6 border-b border-white/10">
            <h3 className="text-xl font-bold font-sora text-white">{title}</h3>
            <button 
              onClick={onClose} 
              className="w-10 h-10 flex items-center justify-center rounded-xl bg-white/5 border border-white/10 text-gray-400 hover:text-white hover:bg-white/10 transition-all active:scale-95"
            >
              <X size={20} />
            </button>
          </div>
          
          <div className="p-6 overflow-y-auto flex-1">
            <form id="modal-form" onSubmit={onSubmit} className="space-y-6">
              {children}
            </form>
          </div>

          <div className="p-6 border-t border-white/10 flex justify-end space-x-4 bg-white/5 rounded-b-2xl">
            <Button variant="secondary" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" form="modal-form" disabled={loading}>
              {loading ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </Motion.div>
      </div>
    </AnimatePresence>
  );
};

export default FormModal;
