import { Edit2, Trash2, Eye, Image as ImageIcon } from 'lucide-react';
import getImageUrl from '../../utils/getImageUrl';

const DataTable = ({ columns, data, onEdit, onDelete, onView, onToggleStatus }) => {
  if (!data || data.length === 0) {
    return (
      <div className="bg-white/5 border border-white/10 rounded-2xl p-12 text-center text-gray-500">
        No records found.
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-xl border border-white/10 bg-white/5">
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="bg-white/5 border-b border-white/10 text-gray-400 text-sm uppercase tracking-wider">
            {columns.map((col, idx) => (
              <th key={idx} className="p-4 font-semibold">{col.label}</th>
            ))}
            {onToggleStatus && <th className="p-4 font-semibold">Visibility</th>}
            <th className="p-4 font-semibold text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-white/5">
          {data.map((row, rowIndex) => (
            <tr key={row._id || rowIndex} className="hover:bg-white/[0.02] transition-colors group">
              {columns.map((col, colIndex) => {
                const isFirstDataColumn = colIndex === (columns[0].key === 'image' ? 1 : 0);
                
                return (
                  <td key={colIndex} className="p-4 align-middle">
                    {col.key === 'image' || col.key === 'coverImage' || col.key === 'mediaUrl' || col.key === 'images' ? (
                      (row[col.key] && (Array.isArray(row[col.key]) ? row[col.key].length > 0 : row[col.key] !== 'no-photo.jpg')) ? (
                        <img 
                          src={getImageUrl(Array.isArray(row[col.key]) ? row[col.key][0] : row[col.key])} 
                          alt="thumbnail" 
                          className="w-12 h-12 object-cover rounded-lg border border-white/10" 
                        />
                      ) : (
                        <div className="w-12 h-12 rounded-lg bg-white/10 flex items-center justify-center text-gray-500">
                          <ImageIcon size={20} />
                        </div>
                      )
                    ) : (
                      <span 
                        className={`text-gray-300 ${onView && isFirstDataColumn ? 'cursor-pointer hover:text-primary-400 font-bold underline decoration-primary-500/30 underline-offset-4 transition-all' : ''}`}
                        onClick={() => onView && isFirstDataColumn ? onView(row) : null}
                      >
                        {col.render ? col.render(row[col.key], row) : row[col.key]}
                      </span>
                    )}
                  </td>
                );
              })}
              
              {onToggleStatus && (
                <td className="p-4 align-middle">
                   <button 
                    onClick={() => onToggleStatus(row)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                      (row.isActive !== false && row.status !== 'draft') ? 'bg-primary-600' : 'bg-gray-700'
                    }`}
                   >
                     <span
                       className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                         (row.isActive !== false && row.status !== 'draft') ? 'translate-x-6' : 'translate-x-1'
                       }`}
                     />
                   </button>
                </td>
              )}

              <td className="p-3 md:p-4 text-right align-middle">
                <div className="flex justify-end space-x-2 md:space-x-3 lg:opacity-0 lg:group-hover:opacity-100 transition-all duration-300 transform lg:translate-x-4 lg:group-hover:translate-x-0">
                  {onView && (
                    <button 
                      onClick={() => onView(row)}
                      className="w-10 h-10 flex items-center justify-center bg-white/5 text-emerald-400 hover:bg-emerald-500 hover:text-white rounded-xl transition-all duration-300 border border-white/10 hover:border-emerald-500 shadow-xl active:scale-90"
                      title="View Details"
                    >
                      <Eye size={16} />
                    </button>
                  )}
                  <button 
                    onClick={() => onEdit(row)}
                    className="w-10 h-10 flex items-center justify-center bg-white/5 text-blue-400 hover:bg-blue-500 hover:text-white rounded-xl transition-all duration-300 border border-white/10 hover:border-blue-500 shadow-xl active:scale-90"
                    title="Edit Record"
                  >
                    <Edit2 size={16} />
                  </button>
                  <button 
                    onClick={() => onDelete(row._id)}
                    className="w-10 h-10 flex items-center justify-center bg-white/5 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition-all duration-300 border border-white/10 hover:border-red-500 shadow-xl active:scale-90"
                    title="Delete Record"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DataTable;
