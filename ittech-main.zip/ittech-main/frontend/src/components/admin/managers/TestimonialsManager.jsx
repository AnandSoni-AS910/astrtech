import React, { useState } from 'react';
import { toast } from 'react-toastify';
import useFetch from '../../../hooks/useFetch';
import cmsService from '../../../api/cmsService';
import DataTable from '../DataTable';
import FormModal from '../FormModal';
import ViewModal from '../modals/ViewModal';
import Button from '../../common/Button';
import ConfirmModal from '../../common/ConfirmModal';
import { Upload } from 'lucide-react';

const TestimonialsManager = () => {
  const { data, loading, refetch } = useFetch('/testimonials?sort=-createdAt');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [viewingItem, setViewingItem] = useState(null);

  // Modal State
  const [modalConfig, setModalConfig] = useState({ isOpen: false, id: null });

  const handleView = (item) => {
    setViewingItem(item);
    setIsViewModalOpen(true);
  };

  const [formData, setFormData] = useState({
    name: '',
    role: '',
    company: '',
    text: '',
    isActive: true,
    image: null
  });
  const [previewImage, setPreviewImage] = useState(null);

  const handleToggleStatus = async (item) => {
    try {
      const newStatus = !item.isActive;
      await cmsService.updateTestimonial(item._id, { isActive: newStatus });
      toast.success(`Testimonial ${newStatus ? 'activated' : 'deactivated'}`);
      refetch();
    } catch {
      toast.error('Failed to update status');
    }
  };

  const columns = [
    { key: 'image', label: 'Avatar' },
    { key: 'name', label: 'Client Name' },
    { key: 'company', label: 'Company' },
    { key: 'role', label: 'Role' },
    { key: 'createdAt', label: 'Date Added', render: (val) => new Date(val).toLocaleDateString() }
  ];

  const handleOpenModal = (item = null) => {
    if (item) {
      setEditingItem(item);
      setFormData({
        name: item.name,
        role: item.role,
        company: item.company,
        text: item.text,
        isActive: item.isActive !== false,
        image: null
      });
      setPreviewImage(item.image !== 'no-photo.jpg' ? item.image : null);
    } else {
      setEditingItem(null);
      setFormData({ name: '', role: '', company: '', text: '', isActive: true, image: null });
      setPreviewImage(null);
    }
    setIsModalOpen(true);
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, image: file });
      setPreviewImage(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    try {
      const submitData = new FormData();
      submitData.append('name', formData.name);
      submitData.append('role', formData.role);
      submitData.append('company', formData.company);
      submitData.append('text', formData.text);
      submitData.append('isActive', formData.isActive);
      
      if (formData.image) {
        submitData.append('image', formData.image);
      }

      if (editingItem) {
        await cmsService.updateTestimonial(editingItem._id, submitData);
        toast.success('Testimonial updated successfully');
      } else {
        await cmsService.createTestimonial(submitData);
        toast.success('Testimonial created successfully');
      }

      setIsModalOpen(false);
      refetch();
    } catch {
      toast.error('Operation failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await cmsService.deleteTestimonial(id);
      toast.success('Testimonial removed');
      refetch();
    } catch {
      toast.error('Failed to delete testimonial');
    }
  };

  const openConfirm = (id) => {
    setModalConfig({ isOpen: true, id });
  };

  const executeConfirm = () => {
    if (modalConfig.id) handleDelete(modalConfig.id);
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white font-sora">Testimonials Management</h2>
          <p className="text-gray-400 text-sm">Manage client reviews and feedback.</p>
        </div>
        <Button 
          onClick={() => handleOpenModal()} 
          className="w-full sm:w-auto"
        >
          Add New Testimonial
        </Button>
      </div>

      {loading ? (
        <div className="text-center text-gray-500 py-12">Loading testimonials...</div>
      ) : (
        <DataTable 
          columns={columns} 
          data={data?.data || []} 
          onEdit={handleOpenModal}
          onDelete={openConfirm}
          onView={handleView}
          onToggleStatus={handleToggleStatus}
        />
      )}

      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={() => setModalConfig({ ...modalConfig, isOpen: false })}
        onConfirm={executeConfirm}
        title="Remove Commendation"
        message="Are you sure you want to delete this testimonial? This action is permanent and will remove the operative's feedback from the grid."
        confirmText="Confirm Removal"
        variant="danger"
      />

      <ViewModal 
        isOpen={isViewModalOpen} 
        onClose={() => setIsViewModalOpen(false)}
        title="Testimonial Details"
        data={viewingItem}
      />

      <FormModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)}
        title={editingItem ? 'Edit Testimonial' : 'Add New Testimonial'}
        onSubmit={handleSubmit}
        loading={saving}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Client Name</label>
            <input 
              type="text" 
              required
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Company Name</label>
            <input 
              type="text" 
              required
              value={formData.company}
              onChange={(e) => setFormData({...formData, company: e.target.value})}
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white"
            />
          </div>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">Role/Position</label>
          <input 
            type="text" 
            required
            value={formData.role}
            onChange={(e) => setFormData({...formData, role: e.target.value})}
            className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white"
            placeholder="e.g. Chief Executive Officer"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">Review / Testimonial text</label>
          <textarea 
            required
            rows="4"
            value={formData.text}
            onChange={(e) => setFormData({...formData, text: e.target.value})}
            className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white"
          />
        </div>

        <div className="flex items-center space-x-3 p-4 rounded-2xl bg-white/5 border border-white/10">
          <input 
            type="checkbox" 
            id="isActive"
            checked={formData.isActive}
            onChange={(e) => setFormData({...formData, isActive: e.target.checked})}
            className="w-5 h-5 accent-primary-500 cursor-pointer"
          />
          <label htmlFor="isActive" className="text-sm font-bold text-white cursor-pointer select-none">
            Active & Published
          </label>
        </div>

        <div>
           <label className="block text-sm font-medium text-gray-400 mb-2">Client Avatar (Image)</label>
           <div className="flex items-center space-x-6">
              <div className="shrink-0 w-20 h-20 bg-white/5 border border-white/10 rounded-full overflow-hidden flex items-center justify-center">
                 {previewImage ? (
                   <img src={previewImage} alt="preview" className="w-full h-full object-cover" />
                 ) : (
                   <Upload className="text-gray-500" />
                 )}
              </div>
              <input 
                type="file" 
                accept="image/*"
                onChange={handleImageChange}
                className="file:mr-4 file:py-2.5 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary-500 file:text-white hover:file:bg-primary-600 text-gray-400"
              />
           </div>
        </div>
      </FormModal>
    </div>
  );
};

export default TestimonialsManager;
