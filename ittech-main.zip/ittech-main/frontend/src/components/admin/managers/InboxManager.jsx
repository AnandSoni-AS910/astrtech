import React, { useState } from "react";
import { toast } from "react-toastify";
import useFetch from "../../../hooks/useFetch";
import cmsService from "../../../api/cmsService";
import {
  Mail,
  Clock,
  Trash2,
  CheckCircle,
  MailOpen,
  User,
  Archive,
  ArrowLeft,
  X,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import Button from "../../common/Button";
import ConfirmModal from "../../common/ConfirmModal";

const InboxManager = () => {
  const [activeTab, setActiveTab] = useState("messages");
  const {
    data,
    loading: messagesLoading,
    refetch: refetchMessages,
  } = useFetch("/contact?sort=-createdAt");
  const {
    data: subsData,
    loading: subsLoading,
    refetch: refetchSubs,
  } = useFetch("/subscriptions");
  const [activeMessage, setActiveMessage] = useState(null);
  const [replyText, setReplyText] = useState("");

  // Modal State
  const [modalConfig, setModalConfig] = useState({
    isOpen: false,
    type: "",
    id: "",
  });

  const messages = data?.data || [];
  const subscriptions = subsData?.data || [];

  const handleStatusChange = async (id, payload) => {
    try {
      await cmsService.updateMessage(id, payload);
      refetchMessages();
      if (activeMessage && activeMessage._id === id) {
        setActiveMessage({ ...activeMessage, ...payload });
      }
    } catch {
      toast.error("Failed to update status");
    }
  };

  const handleSelectMessage = (msg) => {
    setActiveMessage(msg);
    if (!msg.isRead) {
      handleStatusChange(msg._id, { isRead: true });
    }
  };

  const handleDeleteMessage = async (id) => {
    try {
      await cmsService.deleteMessage(id);
      toast.success("Message deleted permanently");
      if (activeMessage && activeMessage._id === id) setActiveMessage(null);
      refetchMessages();
    } catch {
      toast.error("Failed to delete message");
    }
  };

  const handleDeleteSub = async (id) => {
    try {
      const apiClient = (await import("../../../api/client")).default;
      await apiClient.delete(`/subscriptions/${id}`);
      toast.success("Operative removed");
      refetchSubs();
    } catch {
      toast.error("Failed to remove operative");
    }
  };

  const openConfirm = (type, id) => {
    setModalConfig({ isOpen: true, type, id });
  };

  const executeConfirm = () => {
    if (modalConfig.type === "message") handleDeleteMessage(modalConfig.id);
    if (modalConfig.type === "subscription") handleDeleteSub(modalConfig.id);
  };

  const handleReplySubmit = async (e) => {
    e.preventDefault();
    try {
      const newReplies = [
        ...(activeMessage.replies || []),
        { message: replyText },
      ];
      await cmsService.updateMessage(activeMessage._id, {
        replies: newReplies,
      });
      toast.success("Reply appended to thread log");
      setReplyText("");
      setActiveMessage({ ...activeMessage, replies: newReplies });
      refetchMessages();
    } catch {
      toast.error("Failed to save reply");
    }
  };

  if (messagesLoading || subsLoading) {
    return (
      <div className="animate-pulse space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-20 bg-white/5 rounded-xl block w-full" />
        ))}
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-160px)] space-y-6">
      {/* Tabs */}
      <div className="flex space-x-1 p-1 bg-white/5 border border-white/10 rounded-2xl w-fit shrink-0">
        <button
          onClick={() => {
            setActiveTab("messages");
            setActiveMessage(null);
          }}
          className={`px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === "messages" ? "bg-primary-500 text-white shadow-lg shadow-primary-500/20" : "text-gray-500 hover:text-white"}`}
        >
          Contact Message
        </button>
        <button
          onClick={() => {
            setActiveTab("newsletters");
            setActiveMessage(null);
          }}
          className={`px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === "newsletters" ? "bg-primary-500 text-white shadow-lg shadow-primary-500/20" : "text-gray-500 hover:text-white"}`}
        >
          Subscribe Email
        </button>
      </div>

      <div className="flex-1 flex flex-col md:flex-row gap-6 overflow-hidden">
        {activeTab === "messages" ? (
          <>
            {/* Inbox List */}
            <div
              className={`w-full md:w-1/3 flex flex-col bg-[#0f172a] border border-white/5 rounded-2xl overflow-hidden shadow-2xl shrink-0 ${activeMessage ? "hidden md:flex" : "flex"}`}
            >
              <div className="p-4 border-b border-white/10 bg-[#020617]/50 backdrop-blur-md sticky top-0 flex justify-between items-center z-10">
                <h3 className="text-lg font-bold font-sora text-white flex items-center space-x-2">
                  <Mail size={18} className="text-primary-400" />
                  <span>
                    Inbox ({messages.filter((m) => !m.isRead).length})
                  </span>
                </h3>
              </div>

              <div className="overflow-y-auto flex-1 no-scrollbar">
                {messages.length === 0 ? (
                  <div className="p-8 text-center text-gray-500 text-sm">
                    No messages found.
                  </div>
                ) : (
                  <AnimatePresence>
                    {messages.map((msg) => (
                      <motion.div
                        key={msg._id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0, x: -20 }}
                        onClick={() => handleSelectMessage(msg)}
                        className={`p-4 border-b border-white/5 cursor-pointer transition-all border-l-2 ${
                          activeMessage?._id === msg._id
                            ? "bg-primary-600/10 border-l-primary-500"
                            : !msg.isRead
                              ? "bg-white/5 hover:bg-white/10 border-l-blue-400"
                              : "hover:bg-white/5 border-l-transparent"
                        }`}
                      >
                        <div className="flex justify-between items-start mb-1">
                          <span
                            className={`text-sm ${!msg.isRead ? "font-bold text-white" : "font-medium text-gray-300"}`}
                          >
                            {msg.name}
                          </span>
                          <span className="text-xs text-gray-500 whitespace-nowrap ml-2">
                            {new Date(msg.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        <p
                          className={`text-xs mb-2 truncate ${!msg.isRead ? "font-semibold text-gray-300" : "text-gray-400"}`}
                        >
                          {msg.subject}
                        </p>
                        <div className="flex items-center space-x-2">
                          {msg.status === "archived" && (
                            <Archive size={12} className="text-yellow-500" />
                          )}
                          {msg.replies && msg.replies.length > 0 && (
                            <CheckCircle
                              size={12}
                              className="text-emerald-500"
                            />
                          )}
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                )}
              </div>
            </div>

            {/* Message Reader */}
            <div
              className={`flex-1 bg-[#0f172a] border border-white/5 rounded-2xl shadow-2xl flex flex-col overflow-hidden relative ${!activeMessage ? "hidden md:flex" : "flex"}`}
            >
              {activeMessage ? (
                <>
                  <div className="p-4 md:p-6 border-b border-white/10 shrink-0 flex flex-col sm:flex-row justify-between items-start gap-4 bg-[#020617]/30">
                    <div className="flex items-start space-x-4">
                      <button
                        onClick={() => setActiveMessage(null)}
                        className="md:hidden p-2 -ml-2 text-gray-400 hover:text-white"
                      >
                        <ArrowLeft size={20} />
                      </button>
                      <div className="hidden sm:flex w-12 h-12 rounded-full bg-gradient-to-tr from-gray-700 to-gray-600 items-center justify-center shrink-0">
                        <User size={24} className="text-gray-300" />
                      </div>
                      <div>
                        <h2 className="text-lg md:text-xl font-bold font-sora text-white leading-tight mb-1">
                          {activeMessage.subject}
                        </h2>
                        <p className="text-xs md:text-sm text-gray-400">
                          From:{" "}
                          <span className="text-white font-medium">
                            {activeMessage.name}
                          </span>
                        </p>
                        <p className="text-[10px] md:text-xs text-gray-500 mt-1 flex items-center space-x-1">
                          <Clock size={12} />
                          <span>
                            {new Date(activeMessage.createdAt).toLocaleString()}
                          </span>
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1 md:space-x-3 self-end sm:self-start">
                      <button
                        onClick={() =>
                          handleStatusChange(activeMessage._id, {
                            status:
                              activeMessage.status === "archived"
                                ? "inbox"
                                : "archived",
                          })
                        }
                        className="w-10 h-10 flex items-center justify-center text-gray-400 hover:text-yellow-400 hover:bg-yellow-500/10 rounded-xl transition-all border border-transparent hover:border-yellow-500/20"
                        title="Archive"
                      >
                        <Archive size={18} />
                      </button>
                      <button
                        onClick={() =>
                          handleStatusChange(activeMessage._id, {
                            isRead: !activeMessage.isRead,
                          })
                        }
                        className="w-10 h-10 flex items-center justify-center text-gray-400 hover:text-blue-400 hover:bg-blue-500/10 rounded-xl transition-all border border-transparent hover:border-blue-500/20"
                        title="Mark unread"
                      >
                        <MailOpen size={18} />
                      </button>
                      <button
                        onClick={() =>
                          openConfirm("message", activeMessage._id)
                        }
                        className="w-10 h-10 flex items-center justify-center text-gray-400 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-all border border-transparent hover:border-red-500/20"
                        title="Delete"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>

                  <div className="flex-1 overflow-y-auto p-6 space-y-8 no-scrollbar">
                    <div className="text-gray-300 whitespace-pre-wrap leading-relaxed">
                      {activeMessage.message}
                    </div>

                    {/* Thread History */}
                    {(activeMessage.replies || []).map((reply, i) => (
                      <div
                        key={i}
                        className="ml-12 p-4 bg-primary-600/10 border border-primary-500/20 rounded-2xl rounded-tr-sm"
                      >
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-xs font-bold text-primary-400 uppercase tracking-widest">
                            Admin Reply
                          </span>
                          <span className="text-xs text-gray-500">
                            {new Date(reply.date).toLocaleString()}
                          </span>
                        </div>
                        <p className="text-sm text-gray-300 whitespace-pre-wrap">
                          {reply.message}
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="p-4 border-t border-white/10 shrink-0 bg-[#020617]/50">
                    <form
                      onSubmit={handleReplySubmit}
                      className="flex space-x-4"
                    >
                      <textarea
                        rows="2"
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        required
                        placeholder="Type an internal thread note or reply placeholder..."
                        className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:ring-1 focus:ring-primary-500 outline-none resize-none"
                      />
                      <Button type="submit" className="self-end pb-3 pt-3">
                        Log Note
                      </Button>
                    </form>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-gray-500">
                  <Mail size={48} className="mb-4 opacity-20" />
                  <p>Select a message to read</p>
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="flex-1 bg-[#0f172a] border border-white/5 rounded-2xl overflow-hidden shadow-2xl flex flex-col">
            <div className="p-6 border-b border-white/10 flex justify-between items-center bg-[#020617]/30">
              <div>
                <h3 className="text-lg font-bold text-white">
                  Subscribe Email
                </h3>
                <p className="text-xs text-gray-500 mt-1 uppercase tracking-widest font-black">
                  Newsletter Subscription Database
                </p>
              </div>
              <div className="bg-primary-500/10 text-primary-400 px-4 py-2 rounded-xl border border-primary-500/20">
                <span className="text-xl font-black">
                  {subscriptions.length}
                </span>
                <span className="text-[10px] uppercase font-bold ml-2 tracking-tighter">
                  Total Members
                </span>
              </div>
            </div>

            <div className="flex-1 overflow-auto no-scrollbar">
              <table className="w-full text-left border-collapse">
                <thead className="bg-[#020617]/50 sticky top-0 z-10">
                  <tr>
                    <th className="p-6 text-[10px] font-black text-gray-500 uppercase tracking-widest">
                      Email
                    </th>
                    <th className="p-6 text-[10px] font-black text-gray-500 uppercase tracking-widest">
                      Date
                    </th>
                    <th className="p-6 text-[10px] font-black text-gray-500 uppercase tracking-widest text-right">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.03]">
                  {subscriptions.length === 0 ? (
                    <tr>
                      <td
                        colSpan="3"
                        className="p-12 text-center text-gray-500 text-sm"
                      >
                        No operatives found in the database.
                      </td>
                    </tr>
                  ) : (
                    subscriptions.map((sub) => (
                      <tr
                        key={sub._id}
                        className="hover:bg-white/[0.02] transition-colors group"
                      >
                        <td className="p-6">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 rounded-lg bg-primary-500/10 flex items-center justify-center text-primary-400">
                              <Mail size={14} />
                            </div>
                            <span className="text-sm font-bold text-white">
                              {sub.email}
                            </span>
                          </div>
                        </td>
                        <td className="p-6 text-sm text-gray-400">
                          {new Date(sub.createdAt).toLocaleString()}
                        </td>
                        <td className="p-6 text-right">
                          <button
                            onClick={() => openConfirm("subscription", sub._id)}
                            className="p-2 text-gray-600 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                          >
                            <Trash2 size={18} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      <ConfirmModal
        isOpen={modalConfig.isOpen}
        onClose={() => setModalConfig({ ...modalConfig, isOpen: false })}
        onConfirm={executeConfirm}
        title={
          modalConfig.type === "message"
            ? "Delete Message"
            : "Decommission Operative"
        }
        message={
          modalConfig.type === "message"
            ? "Are you sure you want to permanently delete this intelligence report?"
            : "Are you sure you want to remove this operative from the newsletter database?"
        }
        confirmText="Confirm Delete"
        variant="danger"
      />
    </div>
  );
};

export default InboxManager;
