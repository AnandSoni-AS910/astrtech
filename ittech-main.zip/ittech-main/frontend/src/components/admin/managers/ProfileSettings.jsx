import React, { useState } from 'react';
import { Shield, User, Bell, Palette, Globe, Lock, Eye, EyeOff, LayoutDashboard, Monitor } from 'lucide-react';
import GlassCard from '../DataTable'; // Re-use styling logic or swap it. Wait, I will use direct divs to be safe in unstructured generic settings.
import Button from '../../common/Button';
import { toast } from 'react-toastify';

import useFetch from '../../../hooks/useFetch';
import apiClient from '../../../api/client';
import settingsService from '../../../api/settingsService';
import getImageUrl from '../../../utils/getImageUrl';

const ProfileSettings = ({ onUpdate }) => {
  const [activeTab, setActiveTab] = useState('profile');
  const { data: adminData, refetch: refetchMe } = useFetch('/auth/me/');
  const { data: settingsData, refetch: refetchSettings } = useFetch('/settings/');
  const [saving, setSaving] = useState(false);

  // Local state for admin profile
  const [profileData, setProfileData] = useState({ name: '', email: '', avatar: null });
  const [previewAvatar, setPreviewAvatar] = useState(null);

  // Local state for security
  const [passwordData, setPasswordData] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  // Local state for site settings
  const [siteData, setSiteData] = useState({
    companyName: '', tagline: '', email: '', phone: '', address: '',
    facebook: '', twitter: '', instagram: '', linkedin: '', whatsapp: '',
    company_logo: ''
  });
  const [logoFile, setLogoFile] = useState(null);
  const [previewLogo, setPreviewLogo] = useState(null);

  // Sync profile data
  React.useEffect(() => {
    if (adminData?.data) {
      setProfileData({
        name: adminData.data.name || '',
        email: adminData.data.email || '',
        avatar: null
      });
      setPreviewAvatar(adminData.data.avatar ? getImageUrl(adminData.data.avatar) : null);
    }
  }, [adminData?.data]);

  // Sync site settings data
  React.useEffect(() => {
    if (settingsData?.data) {
      setSiteData(settingsData.data);
      if (settingsData.data.company_logo) {
        setPreviewLogo(getImageUrl(settingsData.data.company_logo));
      }
    }
  }, [settingsData?.data]);

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfileData({ ...profileData, avatar: file });
      setPreviewAvatar(URL.createObjectURL(file));
    }
  };

  const handleProfileSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const formData = new FormData();
      formData.append('name', profileData.name);
      formData.append('email', profileData.email);
      if (profileData.avatar) {
        formData.append('avatar', profileData.avatar);
      }

      await apiClient.put('/auth/updatedetails/', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      
      toast.success('Profile updated successfully');
      refetchMe();
      if (onUpdate) onUpdate();
    } catch {
      toast.error('Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setLogoFile(file);
      setPreviewLogo(URL.createObjectURL(file));
    }
  };

  const handlePasswordSave = async (e) => {
    e.preventDefault();
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      return toast.error('Passwords do not match');
    }
    setSaving(true);
    try {
      await apiClient.put('/auth/updatepassword/', {
        currentPassword: passwordData.currentPassword,
        newPassword: passwordData.newPassword
      });
      toast.success('Password updated successfully');
      setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch {
      toast.error('Password update failed');
    } finally {
      setSaving(false);
    }
  };

  const handleSiteSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const formData = new FormData();
      Object.entries(siteData).forEach(([key, value]) => {
        if (key !== 'company_logo') {
          formData.append(key, value);
        }
      });
      
      if (logoFile) {
        formData.append('logo', logoFile);
      }

      await settingsService.updateSettings(formData);
      toast.success('Site configuration saved');
      refetchSettings();
      // Dispatch custom event for real-time appearance update
      if (activeTab === 'appearance') {
        window.dispatchEvent(new Event('appearance-update'));
      }
    } catch {
      toast.error('Failed to update site settings');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
      
      {/* Settings Navigation */}
      <div className="lg:col-span-1 space-y-2">
        {[
          { id: 'profile', icon: <User size={18} />, label: 'Account & Security' },
          { id: 'notifications', icon: <Bell size={18} />, label: 'Alert Preferences' },
          { id: 'appearance', icon: <Palette size={18} />, label: 'Appearance' },
          { id: 'company', icon: <Globe size={18} />, label: 'Company Details' },
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all border ${
              activeTab === item.id 
                ? 'bg-primary-600 text-white font-bold shadow-lg border-primary-500' 
                : 'text-gray-400 hover:bg-white/5 hover:text-white border-transparent'
            }`}
          >
            {item.icon}
            <span className="text-sm">{item.label}</span>
          </button>
        ))}
      </div>

      {/* Settings Content */}
      <div className="lg:col-span-3">
        <div className="bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-md">
          
          {activeTab === 'profile' && (
            <div className="space-y-12">
              {/* Profile Section */}
              <form onSubmit={handleProfileSave} className="space-y-8">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-bold font-sora text-white mb-1">Profile Details</h3>
                    <p className="text-gray-400 text-sm">Update your personal administrator details and public avatar.</p>
                  </div>
                  
                  <div className="flex items-center space-x-6 border-b border-white/10 pb-8">
                    <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-gray-700 to-gray-500 border-2 border-white/20 flex items-center justify-center overflow-hidden ring-4 ring-primary-500/20 shadow-xl shadow-black/40">
                      {previewAvatar ? (
                        <img src={previewAvatar} alt="Avatar Preview" className="w-full h-full object-cover" />
                      ) : (
                        <User size={40} className="text-gray-300" />
                      )}
                    </div>
                    <div>
                      <label className="cursor-pointer group">
                        <span className="text-sm font-bold text-primary-400 group-hover:text-primary-300 transition-colors block mb-1">
                          Change Profile Image
                        </span>
                        <input 
                          type="file" 
                          className="hidden" 
                          accept="image/*"
                          onChange={handleAvatarChange}
                        />
                      </label>
                      <p className="text-xs text-gray-500">Square JPG, GIF or PNG. 2MB max.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-white mb-2">Display Name</label>
                      <input 
                        type="text" 
                        value={profileData.name}
                        onChange={(e) => setProfileData({...profileData, name: e.target.value})}
                        className="w-full bg-[#0f172a] border border-white/10 rounded-xl py-2.5 px-4 text-white focus:border-primary-500 outline-none transition-all" 
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-white mb-2">Email Address</label>
                      <input 
                        type="email" 
                        value={profileData.email}
                        onChange={(e) => setProfileData({...profileData, email: e.target.value})}
                        className="w-full bg-[#0f172a] border border-white/10 rounded-xl py-2.5 px-4 text-white focus:border-primary-500 outline-none transition-all" 
                      />
                    </div>
                  </div>
                  
                  <div className="pt-2 flex justify-end">
                    <Button type="submit" loading={saving}>Update Profile</Button>
                  </div>
                </div>
              </form>

              {/* Security Section */}
              <form onSubmit={handlePasswordSave} className="space-y-8 pt-8 border-t border-white/10">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-bold font-sora text-white mb-1">Security Configuration</h3>
                    <p className="text-gray-400 text-sm">Update your password to keep your account secure.</p>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm text-gray-400 mb-2">Current Password</label>
                      <div className="relative">
                        <input 
                          type={showCurrent ? "text" : "password"} 
                          required
                          value={passwordData.currentPassword}
                          onChange={(e) => setPasswordData({...passwordData, currentPassword: e.target.value})}
                          className="w-full bg-[#0f172a] border border-white/10 rounded-xl py-2.5 px-4 pr-12 text-white focus:border-primary-500 outline-none transition-all" 
                        />
                        <button 
                          type="button"
                          onClick={() => setShowCurrent(!showCurrent)}
                          className="absolute right-4 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center text-gray-500 hover:text-primary-400 hover:bg-primary-400/10 rounded-lg transition-all"
                        >
                          {showCurrent ? <EyeOff size={18} /> : <Eye size={18} />}
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm text-gray-400 mb-2">New Password</label>
                        <div className="relative">
                          <input 
                            type={showNew ? "text" : "password"} 
                            required
                            value={passwordData.newPassword}
                            onChange={(e) => setPasswordData({...passwordData, newPassword: e.target.value})}
                            className="w-full bg-[#0f172a] border border-white/10 rounded-xl py-2.5 px-4 pr-12 text-white focus:border-primary-500 outline-none transition-all" 
                          />
                          <button 
                            type="button"
                            onClick={() => setShowNew(!showNew)}
                            className="absolute right-4 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center text-gray-500 hover:text-primary-400 hover:bg-primary-400/10 rounded-lg transition-all"
                          >
                            {showNew ? <EyeOff size={18} /> : <Eye size={18} />}
                          </button>
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm text-gray-400 mb-2">Confirm New Password</label>
                        <div className="relative">
                          <input 
                            type={showConfirm ? "text" : "password"} 
                            required
                            value={passwordData.confirmPassword}
                            onChange={(e) => setPasswordData({...passwordData, confirmPassword: e.target.value})}
                            className="w-full bg-[#0f172a] border border-white/10 rounded-xl py-2.5 px-4 pr-12 text-white focus:border-primary-500 outline-none transition-all" 
                          />
                          <button 
                            type="button"
                            onClick={() => setShowConfirm(!showConfirm)}
                            className="absolute right-4 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center text-gray-500 hover:text-primary-400 hover:bg-primary-400/10 rounded-lg transition-all"
                          >
                            {showConfirm ? <EyeOff size={18} /> : <Eye size={18} />}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 flex justify-end">
                    <Button type="submit" loading={saving} variant="secondary">Update Password</Button>
                  </div>
                </div>
              </form>
            </div>
          )}

            {activeTab === 'company' && (
              <form onSubmit={handleSiteSave} className="space-y-6">
                <div>
                  <h3 className="text-xl font-bold font-sora text-white mb-1">Company Details</h3>
                  <p className="text-gray-400 text-sm">This information will be displayed in the website footer and contact page.</p>
                </div>

                <div className="flex items-center space-x-6 border-b border-white/10 pb-8">
                  <div className="w-32 h-16 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center overflow-hidden">
                    {previewLogo ? (
                      <img src={previewLogo} alt="Company Logo" className="max-w-full max-h-full object-contain" />
                    ) : (
                      <Globe size={24} className="text-gray-600" />
                    )}
                  </div>
                  <div>
                    <label className="cursor-pointer group">
                      <span className="text-sm font-bold text-primary-400 group-hover:text-primary-300 transition-colors block mb-1">
                        Change Company Logo
                      </span>
                      <input 
                        type="file" 
                        className="hidden" 
                        accept="image/*"
                        onChange={handleLogoChange}
                      />
                    </label>
                    <p className="text-xs text-gray-500">Transparent PNG recommended. 2MB max.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-white mb-2">Company Name</label>
                    <input 
                      type="text" 
                      value={siteData.companyName}
                      onChange={(e) => setSiteData({...siteData, companyName: e.target.value})}
                      className="w-full bg-[#0f172a] border border-white/10 rounded-xl py-2.5 px-4 text-white focus:border-primary-500 outline-none" 
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-white mb-2">Tagline (Footer Bio)</label>
                    <textarea 
                      rows="3"
                      value={siteData.tagline}
                      onChange={(e) => setSiteData({...siteData, tagline: e.target.value})}
                      className="w-full bg-[#0f172a] border border-white/10 rounded-xl py-2.5 px-4 text-white focus:border-primary-500 outline-none" 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-white mb-2">Support Email</label>
                    <input 
                      type="email" 
                      value={siteData.email}
                      onChange={(e) => setSiteData({...siteData, email: e.target.value})}
                      className="w-full bg-[#0f172a] border border-white/10 rounded-xl py-2.5 px-4 text-white focus:border-primary-500 outline-none" 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-white mb-2">Contact Number</label>
                    <input 
                      type="text" 
                      value={siteData.phone}
                      onChange={(e) => setSiteData({...siteData, phone: e.target.value})}
                      className="w-full bg-[#0f172a] border border-white/10 rounded-xl py-2.5 px-4 text-white focus:border-primary-500 outline-none" 
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-white mb-2">Office Address</label>
                    <input 
                      type="text" 
                      value={siteData.address}
                      onChange={(e) => setSiteData({...siteData, address: e.target.value})}
                      className="w-full bg-[#0f172a] border border-white/10 rounded-xl py-2.5 px-4 text-white focus:border-primary-500 outline-none" 
                    />
                  </div>

                  <div className="md:col-span-2 pt-4 border-t border-white/10">
                    <h4 className="text-white font-semibold mb-4">Social Media Links</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">Facebook URL</label>
                        <input type="text" value={siteData.facebook} onChange={(e) => setSiteData({...siteData, facebook: e.target.value})} className="w-full bg-[#0f172a] border border-white/10 rounded-lg py-2 px-3 text-sm text-white" />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">Twitter (X) URL</label>
                        <input type="text" value={siteData.twitter} onChange={(e) => setSiteData({...siteData, twitter: e.target.value})} className="w-full bg-[#0f172a] border border-white/10 rounded-lg py-2 px-3 text-sm text-white" />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">Instagram URL</label>
                        <input type="text" value={siteData.instagram} onChange={(e) => setSiteData({...siteData, instagram: e.target.value})} className="w-full bg-[#0f172a] border border-white/10 rounded-lg py-2 px-3 text-sm text-white" />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">LinkedIn URL</label>
                        <input type="text" value={siteData.linkedin} onChange={(e) => setSiteData({...siteData, linkedin: e.target.value})} className="w-full bg-[#0f172a] border border-white/10 rounded-lg py-2 px-3 text-sm text-white" />
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="pt-6 border-t border-white/10 flex justify-end">
                  <Button type="submit" loading={saving}>Save Company Settings</Button>
                </div>
              </form>
            )}

            {activeTab === 'notifications' && (
              <form onSubmit={handleSiteSave} className="space-y-8">
                <div>
                  <h3 className="text-xl font-bold font-sora text-white mb-1">Alert Preferences</h3>
                  <p className="text-gray-400 text-sm">Configure how and when you receive system and security notifications.</p>
                </div>

                <div className="grid grid-cols-1 gap-6">
                  {[
                    { key: 'alert_new_lead', label: 'New Lead Alerts', desc: 'Get notified instantly when a potential client submits a contact form.' },
                    { key: 'alert_security', label: 'Security Protocols', desc: 'Receive alerts regarding unusual login attempts or system permission changes.' },
                    { key: 'alert_system', label: 'System Maintenance', desc: 'Stay informed about scheduled downtime and backend synchronization tasks.' },
                    { key: 'alert_weekly_report', label: 'Weekly Analytics Digest', desc: 'A summarized report of your site traffic and performance delivered to your email.' },
                  ].map((alert) => (
                    <div key={alert.key} className="flex items-center justify-between p-6 rounded-2xl bg-white/[0.03] border border-white/5 hover:bg-white/[0.05] transition-all group">
                      <div className="space-y-1">
                        <h4 className="text-white font-bold text-sm tracking-tight">{alert.label}</h4>
                        <p className="text-xs text-gray-500 max-w-md">{alert.desc}</p>
                      </div>
                      <button 
                        type="button"
                        onClick={() => setSiteData({ ...siteData, [alert.key]: siteData[alert.key] === 'true' ? 'false' : 'true' })}
                        className={`w-12 h-6 rounded-full relative transition-all duration-300 ${siteData[alert.key] === 'true' ? 'bg-primary-500 shadow-[0_0_15px_rgba(59,130,246,0.5)]' : 'bg-white/10'}`}
                      >
                        <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all duration-300 ${siteData[alert.key] === 'true' ? 'left-7 shadow-lg' : 'left-1'}`} />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="pt-6 border-t border-white/10 flex justify-end">
                  <Button type="submit" loading={saving} variant="secondary">
                    <Bell size={16} className="mr-2" />
                    Synchronize Alerts
                  </Button>
                </div>
              </form>
            )}

            {activeTab === 'appearance' && (
              <form onSubmit={handleSiteSave} className="space-y-8">
                <div>
                  <h3 className="text-xl font-bold font-sora text-white mb-1">Appearance Settings</h3>
                  <p className="text-gray-400 text-sm">Personalize your administrative workspace aesthetics and interface behavior.</p>
                </div>

                <div className="space-y-10">
                  {/* 1. Theme Selection */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2 text-primary-400">
                      <LayoutDashboard size={16} />
                      <h3 className="text-sm font-bold tracking-widest uppercase">System Theme</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {[
                        { id: 'deep_ocean', label: 'Deep Ocean', color: 'bg-[#020617]' },
                        { id: 'midnight', label: 'Midnight Glass', color: 'bg-[#0f172a]' },
                        { id: 'obsidian', label: 'Obsidian Black', color: 'bg-black' },
                      ].map((theme) => (
                        <button
                          key={theme.id}
                          type="button"
                          onClick={() => setSiteData({ ...siteData, admin_theme: theme.id })}
                          className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center space-y-3 ${
                            siteData.admin_theme === theme.id 
                              ? 'border-primary-500 bg-primary-500/10' 
                              : 'border-white/5 bg-white/5 hover:border-white/10'
                          }`}
                        >
                          <div className={`w-12 h-12 rounded-xl ${theme.color} border border-white/10 shadow-inner`} />
                          <span className="text-xs font-bold tracking-wide text-white">{theme.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 2. Button & Action Color */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2 text-primary-400">
                      <Monitor size={16} />
                      <h3 className="text-sm font-bold tracking-widest uppercase">Primary Action & Button Color</h3>
                    </div>
                    <div className="flex flex-wrap gap-4">
                      {[
                        { id: 'blue', color: 'bg-blue-500', label: 'Tactical Blue' },
                        { id: 'emerald', color: 'bg-emerald-500', label: 'Neural Green' },
                        { id: 'purple', color: 'bg-purple-500', label: 'Royal Void' },
                        { id: 'red', color: 'bg-red-500', label: 'Infra Red' },
                        { id: 'rose', color: 'bg-rose-500', label: 'Strike Rose' },
                        { id: 'amber', color: 'bg-amber-500', label: 'Warning Amber' },
                      ].map((accent) => (
                        <button
                          key={accent.id}
                          type="button"
                          onClick={() => setSiteData({ ...siteData, accent_color: accent.id })}
                          className={`group relative p-1 rounded-full border-2 transition-all ${
                            siteData.accent_color === accent.id 
                              ? 'border-primary-500 scale-110' 
                              : 'border-transparent hover:border-white/20'
                          }`}
                          title={accent.label}
                        >
                          <div className={`w-10 h-10 rounded-full ${accent.color} shadow-lg group-hover:scale-90 transition-transform`} />
                          {siteData.accent_color === accent.id && (
                            <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[10px] font-bold text-primary-400 whitespace-nowrap">
                              {accent.label}
                            </div>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* UI Toggles */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="flex items-center justify-between p-5 rounded-2xl bg-white/[0.02] border border-white/5">
                      <div className="space-y-1">
                        <span className="text-sm font-bold text-white block">Compact Sidebar</span>
                        <p className="text-[10px] text-gray-500">Maximize workspace by minimizing the navigation menu.</p>
                      </div>
                      <button 
                        type="button"
                        onClick={() => setSiteData({ ...siteData, compact_sidebar: siteData.compact_sidebar === 'true' ? 'false' : 'true' })}
                        className={`w-10 h-5 rounded-full relative transition-all ${siteData.compact_sidebar === 'true' ? 'bg-primary-500' : 'bg-white/10'}`}
                      >
                        <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${siteData.compact_sidebar === 'true' ? 'left-6' : 'left-1'}`} />
                      </button>
                    </div>
                    <div className="flex items-center justify-between p-5 rounded-2xl bg-white/[0.02] border border-white/5">
                      <div className="space-y-1">
                        <span className="text-sm font-bold text-white block">Glassmorphism VFX</span>
                        <p className="text-[10px] text-gray-500">Enable advanced backdrop blurs and transparency effects.</p>
                      </div>
                      <button 
                        type="button"
                        onClick={() => setSiteData({ ...siteData, glass_effects: siteData.glass_effects === 'true' ? 'false' : 'true' })}
                        className={`w-10 h-5 rounded-full relative transition-all ${siteData.glass_effects === 'true' ? 'bg-primary-500' : 'bg-white/10'}`}
                      >
                        <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${siteData.glass_effects === 'true' ? 'left-6' : 'left-1'}`} />
                      </button>
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-white/10 flex justify-end">
                  <Button type="submit" loading={saving} variant="primary">
                    <Palette size={16} className="mr-2" />
                    Apply Aesthetics
                  </Button>
                </div>
              </form>
            )}
        </div>
      </div>
    </div>
  );
};

export default ProfileSettings;
