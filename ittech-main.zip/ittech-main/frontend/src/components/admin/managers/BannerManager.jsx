import React, { useState } from 'react';
import { toast } from 'react-toastify';
import useFetch from '../../../hooks/useFetch';
import cmsService from '../../../api/cmsService';
import DataTable from '../DataTable';
import FormModal from '../FormModal';
import ViewModal from '../modals/ViewModal';
import Button from '../../common/Button';
import ConfirmModal from '../../common/ConfirmModal';
import { MonitorPlay } from 'lucide-react';

const BannerManager = () => {
  const { data, loading, refetch } = useFetch('/banners?sort=orderIndex');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [viewingItem, setViewingItem] = useState(null);

  // Modal State
  const [modalConfig, setModalConfig] = useState({ isOpen: false, id: null });

  const [formData, setFormData] = useState({
    title: '',
    subtitle: '',
    ctaText: 'Get Started',
    ctaLink: '/contact',
    isActive: true,
    orderIndex: 0
  });

  const handleView = (item) => {
    setViewingItem(item);
    setIsViewModalOpen(true);
  };

  const handleToggleStatus = async (item) => {
    try {
      const newStatus = !item.isActive;
      await cmsService.updateBanner(item._id, { isActive: newStatus });
      toast.success(`Banner ${newStatus ? 'activated' : 'deactivated'}`);
      refetch();
    } catch {
      toast.error('Failed to update status');
    }
  };

  const columns = [
    { key: 'title', label: 'Headline' },
    { key: 'isActive', label: 'Status', render: (val) => (
      <span className={`px-2.5 py-1 text-xs font-bold rounded-full ${val ? 'bg-emerald-500/20 text-emerald-400' : 'bg-gray-500/20 text-gray-400'}`}>
        {val ? 'Active' : 'Draft'}
      </span>
    )},
    { key: 'orderIndex', label: 'Slide Order' }
  ];

  const handleOpenModal = (item = null) => {
    if (item) {
      setEditingItem(item);
      setFormData({
        title: item.title,
        subtitle: item.subtitle,
        ctaText: item.ctaText,
        ctaLink: item.ctaLink,
        isActive: item.isActive,
        orderIndex: item.orderIndex
      });
    } else {
      setEditingItem(null);
      setFormData({ 
        title: '', subtitle: '', ctaText: 'Get Started', ctaLink: '/contact', isActive: true, orderIndex: 0 
      });
    }
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    try {
      const submitData = new FormData();
      submitData.append('title', formData.title);
      submitData.append('subtitle', formData.subtitle);
      submitData.append('ctaText', formData.ctaText);
      submitData.append('ctaLink', formData.ctaLink);
      submitData.append('isActive', formData.isActive);
      submitData.append('orderIndex', formData.orderIndex);

      if (editingItem) {
        await cmsService.updateBanner(editingItem._id, submitData);
        toast.success('Hero banner updated successfully');
      } else {
        await cmsService.createBanner(submitData);
        toast.success('Hero banner created successfully');
      }

      setIsModalOpen(false);
      refetch();
    } catch {
      toast.error('Operation failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await cmsService.deleteBanner(id);
      toast.success('Banner removed');
      refetch();
    } catch {
      toast.error('Failed to delete banner');
    }
  };

  const openConfirm = (id) => {
    setModalConfig({ isOpen: true, id });
  };

  const executeConfirm = () => {
    if (modalConfig.id) handleDelete(modalConfig.id);
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white font-sora">Homepage Hero Banners</h2>
          <p className="text-gray-400 text-sm">Manage the dynamic headlines on the front page.</p>
        </div>
        <Button 
          onClick={() => handleOpenModal()} 
          className="w-full sm:w-auto"
        >
          <MonitorPlay size={18} />
          <span>Add New Slide</span>
        </Button>
      </div>

      {loading ? (
        <div className="text-center text-gray-500 py-12 animate-pulse">Syncing Content...</div>
      ) : (
        <DataTable 
          columns={columns} 
          data={data?.data || []} 
          onEdit={handleOpenModal}
          onDelete={openConfirm}
          onView={handleView}
          onToggleStatus={handleToggleStatus}
        />
      )}

      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={() => setModalConfig({ ...modalConfig, isOpen: false })}
        onConfirm={executeConfirm}
        title="Decommission Hero Banner"
        message="Are you sure you want to delete this homepage banner? This will break the hero section if it is the only one."
        confirmText="Confirm Deletion"
        variant="danger"
      />

      <ViewModal 
        isOpen={isViewModalOpen} 
        onClose={() => setIsViewModalOpen(false)}
        title="Hero Slide Specification"
        data={viewingItem}
      />

      <FormModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)}
        title={editingItem ? 'Configure Slide' : 'Design New Slide'}
        onSubmit={handleSubmit}
        loading={saving}
      >
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">Main Headline</label>
          <input 
            type="text" 
            required
            value={formData.title}
            onChange={(e) => setFormData({...formData, title: e.target.value})}
            className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white text-lg font-bold"
            placeholder="e.g. Next-Gen Tech For Global Growth"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">Subtext / Description</label>
          <textarea 
            required
            rows="3"
            value={formData.subtitle}
            onChange={(e) => setFormData({...formData, subtitle: e.target.value})}
            className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white"
            placeholder="Brief descriptor under the headline..."
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Call To Action Text</label>
            <input 
              type="text" 
              required
              value={formData.ctaText}
              onChange={(e) => setFormData({...formData, ctaText: e.target.value})}
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 outline-none text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Button Link URL</label>
            <input 
              type="text" 
              required
              value={formData.ctaLink}
              onChange={(e) => setFormData({...formData, ctaLink: e.target.value})}
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 outline-none text-white"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-6 border-b border-white/10">
          <div>
             <label className="block text-sm font-medium text-gray-400 mb-2">Auto-Slide Order (0 is first)</label>
             <input 
              type="number" 
              required
              value={formData.orderIndex}
              onChange={(e) => setFormData({...formData, orderIndex: e.target.value})}
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 outline-none text-white"
            />
          </div>
          <div className="flex items-center space-x-4 pt-8">
            <input 
              type="checkbox" 
              id="isActiveToggle"
              checked={formData.isActive}
              onChange={(e) => setFormData({...formData, isActive: e.target.checked})}
              className="w-5 h-5 accent-primary-500"
            />
            <label htmlFor="isActiveToggle" className="text-white font-medium cursor-pointer">
              Set Slide as Active
            </label>
          </div>
        </div>
      </FormModal>
    </div>
  );
};

export default BannerManager;
