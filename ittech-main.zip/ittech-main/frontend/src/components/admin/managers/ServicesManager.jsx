import React, { useState } from 'react';
import { toast } from 'react-toastify';
import useFetch from '../../../hooks/useFetch';
import cmsService from '../../../api/cmsService';
import DataTable from '../DataTable';
import FormModal from '../FormModal';
import ViewModal from '../modals/ViewModal';
import Button from '../../common/Button';
import ConfirmModal from '../../common/ConfirmModal';
import { Upload } from 'lucide-react';
import getImageUrl from '../../../utils/getImageUrl';

const ServicesManager = () => {
  const { data, loading, refetch } = useFetch('/services?sort=-createdAt');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [viewingItem, setViewingItem] = useState(null);

  // Modal State
  const [modalConfig, setModalConfig] = useState({ isOpen: false, id: null });

  const handleView = (item) => {
    setViewingItem(item);
    setIsViewModalOpen(true);
  };

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    icon: '',
    category: '',
    features: '',
    isActive: true,
    image: null
  });
  const [previewImage, setPreviewImage] = useState(null);

  const handleToggleStatus = async (item) => {
    try {
      const newStatus = !item.isActive;
      await cmsService.updateService(item._id, { isActive: newStatus });
      toast.success(`Service ${newStatus ? 'activated' : 'deactivated'}`);
      refetch();
    } catch {
      toast.error('Failed to update status');
    }
  };

  const columns = [
    { key: 'image', label: 'Image' },
    { key: 'title', label: 'Service Title' },
    { key: 'category', label: 'Category', render: (val) => (
      <span className="px-2 py-0.5 rounded-md bg-white/10 text-primary-400 text-xs font-medium">
        {val || 'General'}
      </span>
    )},
    { key: 'createdAt', label: 'Date Added', render: (val) => new Date(val).toLocaleDateString() }
  ];

  const handleOpenModal = (item = null) => {
    if (item) {
      setEditingItem(item);
      setFormData({
        title: item.title,
        description: item.description,
        category: item.category || '',
        features: item.features ? item.features.join('\n') : '',
        icon: item.icon || 'Code',
        isActive: item.isActive !== false,
        image: null
      });
      setPreviewImage(item.image && item.image !== 'no-photo.jpg' ? getImageUrl(item.image) : null);
    } else {
      setEditingItem(null);
      setFormData({ title: '', description: '', icon: 'Code', category: '', features: '', isActive: true, image: null });
      setPreviewImage(null);
    }
    setIsModalOpen(true);
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, image: file });
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    try {
      const submitData = new FormData();
      submitData.append('title', formData.title);
      submitData.append('description', formData.description);
      submitData.append('category', formData.category);
      submitData.append('icon', formData.icon || 'Code');
      submitData.append('isActive', formData.isActive);
      
      // Handle features
      const featuresArray = formData.features.split('\n').filter(f => f.trim() !== '');
      featuresArray.forEach(f => {
        submitData.append('features', f);
      });
      
      if (formData.image) {
        submitData.append('image', formData.image);
      }

      if (editingItem) {
        await cmsService.updateService(editingItem._id, submitData);
        toast.success('Service updated successfully');
      } else {
        await cmsService.createService(submitData);
        toast.success('Service created successfully');
      }

      setIsModalOpen(false);
      refetch();
    } catch {
      toast.error('Operation failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await cmsService.deleteService(id);
      toast.success('Service deleted');
      refetch();
    } catch {
      toast.error('Failed to delete service');
    }
  };

  const openConfirm = (id) => {
    setModalConfig({ isOpen: true, id });
  };

  const executeConfirm = () => {
    if (modalConfig.id) handleDelete(modalConfig.id);
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white font-sora">Services Management</h2>
          <p className="text-gray-400 text-sm">Manage all technical services and capabilities displayed on the public site.</p>
        </div>
        <Button 
          onClick={() => handleOpenModal()} 
          className="w-full sm:w-auto"
        >
          Add New Service
        </Button>
      </div>

      {loading ? (
        <div className="text-center text-gray-500 py-12">
          <div className="animate-spin w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          Loading services...
        </div>
      ) : (
        <DataTable 
          columns={columns} 
          data={data?.data || []} 
          onEdit={handleOpenModal}
          onDelete={openConfirm}
          onView={handleView}
          onToggleStatus={handleToggleStatus}
        />
      )}

      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={() => setModalConfig({ ...modalConfig, isOpen: false })}
        onConfirm={executeConfirm}
        title="Decommission Service"
        message="Are you sure you want to delete this service? This will remove all related intelligence from the public grid."
        confirmText="Confirm Deletion"
        variant="danger"
      />

      <ViewModal 
        isOpen={isViewModalOpen} 
        onClose={() => setIsViewModalOpen(false)}
        title="Service Details"
        data={viewingItem}
      />

      <FormModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)}
        title={editingItem ? 'Edit Service' : 'Add New Service'}
        onSubmit={handleSubmit}
        loading={saving}
      >
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Service Title</label>
              <input 
                type="text" 
                required
                value={formData.title}
                onChange={(e) => setFormData({...formData, title: e.target.value})}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white font-medium"
                placeholder="e.g. Cloud Infrastructure"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Category</label>
              <input 
                type="text" 
                required
                value={formData.category}
                onChange={(e) => setFormData({...formData, category: e.target.value})}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white"
                placeholder="e.g. Development, Security..."
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Detailed Description</label>
            <textarea 
              required
              rows="3"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white leading-relaxed"
              placeholder="Describe the value proposition..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Key Features (One per line)</label>
            <textarea 
              rows="4"
              value={formData.features}
              onChange={(e) => setFormData({...formData, features: e.target.value})}
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-all outline-none text-white leading-relaxed"
              placeholder="Enterprise Security&#10;Strategic ROI&#10;Accelerated Delivery"
            />
          </div>

          <div className="flex items-center space-x-3 p-4 rounded-2xl bg-white/5 border border-white/10">
            <input 
              type="checkbox" 
              id="isActive"
              checked={formData.isActive}
              onChange={(e) => setFormData({...formData, isActive: e.target.checked})}
              className="w-5 h-5 accent-primary-500 cursor-pointer"
            />
            <label htmlFor="isActive" className="text-sm font-bold text-white cursor-pointer select-none">
              Active & Visible on Website
            </label>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Service Cover Image</label>
            <div className="flex flex-col space-y-4">
              <div className="relative group w-full h-48 bg-white/5 border border-white/10 rounded-2xl overflow-hidden flex items-center justify-center transition-all hover:bg-white/10">
                {previewImage ? (
                  <img src={previewImage} alt="preview" className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                ) : (
                  <div className="text-gray-500 flex flex-col items-center">
                    <Upload size={32} className="mb-2 opacity-50 group-hover:opacity-100 transition-opacity" />
                    <span className="text-xs font-bold uppercase tracking-widest opacity-50">Upload Media</span>
                  </div>
                )}
                <input 
                  type="file" 
                  accept="image/*"
                  onChange={handleImageChange}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
              </div>
              <p className="text-[10px] text-gray-500 italic uppercase tracking-wider text-center">
                Click the area above to select a high-resolution service thumbnail
              </p>
            </div>
          </div>
        </div>
      </FormModal>
    </div>
  );
};

export default ServicesManager;
