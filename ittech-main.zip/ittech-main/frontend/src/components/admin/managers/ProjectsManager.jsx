import React, { useMemo, useState, useEffect } from "react";
import { toast } from "react-toastify";
import useFetch from "../../../hooks/useFetch";
import cmsService from "../../../api/cmsService";
import DataTable from "../DataTable";
import FormModal from "../FormModal";
import ViewModal from "../modals/ViewModal";
import Button from "../../common/Button";
import ConfirmModal from "../../common/ConfirmModal";
import { Upload, Image as ImageIcon } from "lucide-react";
import getImageUrl from "../../../utils/getImageUrl";

const ProjectsManager = () => {
  const { data, loading, refetch } = useFetch("/projects");
  const { data: catData } = useFetch("/projects/categories");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [viewingItem, setViewingItem] = useState(null);

  // Modal State
  const [modalConfig, setModalConfig] = useState({ isOpen: false, id: null });

  const handleView = (item) => {
    // Projects model uses 'images' array, but ViewModal expects 'image' or 'avatar'.
    // We'll normalize this for the modal.
    setViewingItem({
      ...item,
      image: item.images && item.images.length > 0 ? item.images[0] : null,
    });
    setIsViewModalOpen(true);
  };

  const categories = useMemo(() => catData?.data || [], [catData]);

  const [formData, setFormData] = useState({
    title: "",
    category: "",
    client: "",
    industry: "",
    description: "",
    link: "",
    tags: "",
    isActive: true,
    image: null,
  });

  const handleToggleStatus = async (item) => {
    try {
      const newStatus = !item.isActive;
      await cmsService.updateProject(item._id, { isActive: newStatus });
      toast.success(`Project ${newStatus ? "activated" : "deactivated"}`);
      refetch();
    } catch {
      toast.error("Failed to update status");
    }
  };

  // Handle setting default category when catData loads
  useEffect(() => {
    if (categories.length > 0 && !formData.category && !editingItem) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setFormData((prev) => ({ ...prev, category: categories[0] }));
    }
  }, [categories, editingItem, formData.category]);
  const [previewImage, setPreviewImage] = useState(null);

  const columns = [
    {
      key: "images",
      label: "Preview",
      render: (val) => (
        <div className="w-12 h-12 rounded-lg bg-white/5 border border-white/10 overflow-hidden">
          {val && val.length > 0 ? (
            <img
              src={getImageUrl(val[0])}
              alt="Project"
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-gray-600">
              <ImageIcon size={16} />
            </div>
          )}
        </div>
      ),
    },
    { key: "title", label: "Project" },
    { key: "category", label: "Category" },
    { key: "client", label: "Client" },
    {
      key: "createdAt",
      label: "Date",
      render: (val) => new Date(val).toLocaleDateString(),
    },
  ];

  const handleOpenModal = (item = null) => {
    if (item) {
      setEditingItem(item);
      setFormData({
        title: item.title,
        category: item.category || "Web Development",
        client: item.client || "",
        industry: item.industry || "",
        description: item.description,
        link: item.link || "",
        tags: item.tags ? item.tags.join(", ") : "",
        isActive: item.isActive !== false,
        image: null,
      });
      setPreviewImage(
        item.images && item.images.length > 0
          ? getImageUrl(item.images[0])
          : null,
      );
    } else {
      setEditingItem(null);
      setFormData({
        title: "",
        category: "Web Development",
        client: "",
        industry: "",
        description: "",
        link: "",
        tags: "",
        isActive: true,
        image: null,
      });
      setPreviewImage(null);
    }
    setIsModalOpen(true);
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, image: file });
      setPreviewImage(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);

    try {
      const submitData = new FormData();
      Object.keys(formData).forEach((key) => {
        if (formData[key] !== null && key !== "image") {
          submitData.append(key, formData[key]);
        }
      });

      if (formData.image) {
        submitData.append("image", formData.image);
      }

      if (editingItem) {
        await cmsService.updateProject(editingItem._id, submitData);
        toast.success("Project optimized successfully");
      } else {
        await cmsService.createProject(submitData);
        toast.success("New project deployed");
      }

      setIsModalOpen(false);
      refetch();
    } catch {
      toast.error("System operation failed");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await cmsService.deleteProject(id);
      toast.info("Project decommissioned");
      refetch();
    } catch {
      toast.error("Deletion protocol failed");
    }
  };

  const openConfirm = (id) => {
    setModalConfig({ isOpen: true, id });
  };

  const executeConfirm = () => {
    if (modalConfig.id) handleDelete(modalConfig.id);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 mb-8">
        <div>
          <h2 className="text-3xl font-bold text-white font-sora">
            {" "}
            Portfolio
          </h2>
          <p className="text-gray-400 mt-1">
            Strategic case studies and deployment logs.
          </p>
        </div>
        <Button onClick={() => handleOpenModal()} className="w-full sm:w-auto">
          Create Project
        </Button>
      </div>

      <div className="bg-white/5 border border-white/5 rounded-3xl backdrop-blur-xl overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-64 text-gray-500 font-mono tracking-widest animate-pulse">
            SYNCHRONIZING DATA...
          </div>
        ) : (
          <DataTable
            columns={columns}
            data={data?.data || []}
            onEdit={handleOpenModal}
            onDelete={openConfirm}
            onView={handleView}
            onToggleStatus={handleToggleStatus}
          />
        )}
      </div>

      <ConfirmModal
        isOpen={modalConfig.isOpen}
        onClose={() => setModalConfig({ ...modalConfig, isOpen: false })}
        onConfirm={executeConfirm}
        title="Override Project Status"
        message="System override required: Are you sure you want to delete this project? This action cannot be reversed."
        confirmText="Confirm Overwrite"
        variant="danger"
      />

      <ViewModal
        isOpen={isViewModalOpen}
        onClose={() => setIsViewModalOpen(false)}
        title="Project Intelligence Report"
        data={viewingItem}
      />

      <FormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingItem ? "Edit Strategic Project" : "Deploy New Project"}
        onSubmit={handleSubmit}
        loading={saving}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 px-1">
              Project Code/Title
            </label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) =>
                setFormData({ ...formData, title: e.target.value })
              }
              className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-5 focus:border-primary-500 transition-all outline-none text-white text-sm"
              placeholder="e.g., Quantum Edge Platform"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 px-1">
              Sector / Category
            </label>
            <select
              value={formData.category}
              onChange={(e) =>
                setFormData({ ...formData, category: e.target.value })
              }
              className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-5 focus:border-primary-500 transition-all outline-none text-white text-sm appearance-none"
            >
              {categories.map((cat) => (
                <option key={cat} value={cat} className="bg-[#0f172a]">
                  {cat}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 px-1">
              Client Entity
            </label>
            <input
              type="text"
              value={formData.client}
              onChange={(e) =>
                setFormData({ ...formData, client: e.target.value })
              }
              className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-5 focus:border-primary-500 transition-all outline-none text-white text-sm"
              placeholder="Organization Name"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 px-1">
              Live Integration Link
            </label>
            <input
              type="url"
              value={formData.link}
              onChange={(e) =>
                setFormData({ ...formData, link: e.target.value })
              }
              className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-5 focus:border-primary-500 transition-all outline-none text-white text-sm"
              placeholder="https://..."
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 px-1">
            Engagement Intel (Description)
          </label>
          <textarea
            required
            rows="4"
            value={formData.description}
            onChange={(e) =>
              setFormData({ ...formData, description: e.target.value })
            }
            className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-5 focus:border-primary-500 transition-all outline-none text-white text-sm resize-none"
            placeholder="Technical details and objectives..."
          />
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black uppercase tracking-widest text-gray-500 px-1">
            Visual Assets (Primary)
          </label>
          <div className="flex items-center space-x-3 p-4 rounded-2xl bg-white/5 border border-white/10">
            <input
              type="checkbox"
              id="isActive"
              checked={formData.isActive}
              onChange={(e) =>
                setFormData({ ...formData, isActive: e.target.checked })
              }
              className="w-5 h-5 accent-primary-500 cursor-pointer"
            />
            <label
              htmlFor="isActive"
              className="text-sm font-bold text-white cursor-pointer select-none"
            >
              Active & Visible in Portfolio
            </label>
          </div>

          <div className="flex flex-col md:flex-row items-center gap-6 p-6 border-2 border-dashed border-white/5 rounded-2xl bg-white/[0.02]">
            <div className="shrink-0 w-48 h-32 bg-black/40 rounded-xl overflow-hidden flex items-center justify-center border border-white/10">
              {previewImage ? (
                <img
                  src={previewImage}
                  alt="preview"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="flex flex-col items-center">
                  <Upload className="text-white/20 mb-2" size={32} />
                  <span className="text-[8px] font-black uppercase tracking-widest text-white/10">
                    NO SIGNAL
                  </span>
                </div>
              )}
            </div>
            <div className="flex-1 text-center md:text-left space-y-3">
              <p className="text-xs text-gray-400">
                Standard 16:9 ratio assets recommended for premium display
                quality.
              </p>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
                id="project-image-upload"
              />
              <label
                htmlFor="project-image-upload"
                className="inline-block bg-white/10 hover:bg-white/20 text-white text-[10px] font-black uppercase tracking-widest px-6 py-3 rounded-full cursor-pointer transition-all"
              >
                {previewImage
                  ? "Replace Satellite Image"
                  : "Select Deployment Asset"}
              </label>
            </div>
          </div>
        </div>
      </FormModal>
    </div>
  );
};

export default ProjectsManager;
