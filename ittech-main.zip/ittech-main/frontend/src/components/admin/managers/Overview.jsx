import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Briefcase, Projector, MessageSquare, TrendingUp, Users, AlertCircle, RefreshCw } from 'lucide-react';
import GlassCard from '../../common/GlassCard';
import Button from '../../common/Button';
import useFetch from '../../../hooks/useFetch';

const COLORS = ['#3b82f6', '#8b5cf6', '#ec4899', '#10b981', '#f59e0b'];

const Overview = () => {
  const { data: analyticsRow, loading, error, refetch } = useFetch('/analytics');
  
  if (loading) return (
    <div className="animate-pulse space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[1, 2, 3, 4].map(i => <div key={i} className="h-32 bg-white/5 rounded-2xl border border-white/10" />)}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 h-96 bg-white/5 rounded-2xl border border-white/10" />
        <div className="h-96 bg-white/5 rounded-2xl border border-white/10" />
      </div>
    </div>
  );

  if (error) return (
    <div className="flex flex-col items-center justify-center p-12 bg-red-500/5 border border-red-500/10 rounded-[2.5rem] text-center space-y-4">
      <div className="p-4 bg-red-500/10 rounded-full text-red-500">
        <AlertCircle size={40} />
      </div>
      <div>
        <h3 className="text-xl font-bold text-white font-sora">Intelligence Sync Failed</h3>
        <p className="text-gray-400 mt-2 max-w-md mx-auto">
          The tactical dashboard is unable to establish a connection with the central neural core (Backend). 
          Error: <span className="text-red-400/80 font-mono text-xs">{error}</span>
        </p>
      </div>
      <Button 
        onClick={refetch}
        variant="secondary"
        className="px-8"
      >
        <RefreshCw size={18} />
        <span className="font-bold text-sm tracking-widest uppercase">Retry Uplink</span>
      </Button>
    </div>
  );

  const data = analyticsRow?.data || { totals: {}, charts: { projectCategories: [], leadTrends: [] } };
  
  // Transform lead trends for Recharts
  const chartData = (data.charts.leadTrends || []).map(item => ({
    name: `${item._id.month}/${item._id.year}`,
    Leads: item.total
  }));

  // Fallback data if trends are empty
  const finalChartData = chartData.length > 0 ? chartData : [
    { name: 'Jan', Leads: 12 }, { name: 'Feb', Leads: 19 }, { name: 'Mar', Leads: 15 },
    { name: 'Apr', Leads: 25 }, { name: 'May', Leads: 32 }, { name: 'Jun', Leads: 45 }
  ];

  return (
    <div className="space-y-6">
      {/* Top Value Widgets */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Active Projects', value: data.totals.projects || 0, icon: <Projector />, color: 'text-blue-400' },
          { label: 'Total Services', value: data.totals.services || 0, icon: <Briefcase />, color: 'text-purple-400' },
          { label: 'Total Inquiries', value: data.totals.leads || 0, icon: <Users />, color: 'text-emerald-400' },
          { label: 'Unread Messages', value: data.totals.unreadMessages || 0, icon: <MessageSquare />, color: 'text-pink-400' },
        ].map((item, idx) => (
          <GlassCard key={idx} className="p-6 relative overflow-hidden group">
            <div className="flex justify-between items-start mb-4">
              <div className={`p-3 rounded-xl bg-white/5 ${item.color} group-hover:scale-110 transition-transform`}>
                {React.cloneElement(item.icon, { size: 22 })}
              </div>
              {idx === 3 && item.value > 0 && (
                <span className="flex h-3 w-3 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pink-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-pink-500"></span>
                </span>
              )}
            </div>
            <div>
              <p className="text-3xl font-bold font-sora text-white mb-1 tracking-tighter">{item.value}</p>
              <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest">{item.label}</p>
            </div>
            <div className={`absolute -bottom-10 -right-10 w-32 h-32 ${item.color.replace('text-', 'bg-')}/10 rounded-full blur-2xl pointer-events-none`} />
          </GlassCard>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Area Chart */}
        <GlassCard className="p-8 lg:col-span-2 flex flex-col min-h-[500px]">
          <div className="flex justify-between items-center mb-10">
            <div>
              <h3 className="text-2xl font-black font-sora text-white tracking-tight italic">Growth Dynamics</h3>
              <p className="text-xs text-gray-500 mt-1 uppercase tracking-widest font-bold">Tactical Lead Acquisition Stream</p>
            </div>
            <div className="p-3 bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 rounded-2xl flex items-center space-x-2">
              <TrendingUp size={16} />
              <span className="text-xs font-black">+24.8%</span>
            </div>
          </div>
          
          <div className="flex-1 w-full min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={300} debounce={100}>
              <AreaChart data={finalChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorLeads" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff08" vertical={false} />
                <XAxis dataKey="name" stroke="#ffffff10" tick={{ fill: '#4b5563', fontSize: 10, fontWeight: 800 }} tickLine={false} axisLine={false} />
                <YAxis stroke="#ffffff10" tick={{ fill: '#4b5563', fontSize: 10, fontWeight: 800 }} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#ffffff10', borderRadius: '16px', boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)', border: '1px solid rgba(255,255,255,0.1)' }}
                  itemStyle={{ color: '#fff', fontSize: '12px', fontWeight: 'bold' }}
                  cursor={{ stroke: '#3b82f6', strokeWidth: 2 }}
                />
                <Area type="monotone" dataKey="Leads" stroke="#3b82f6" strokeWidth={4} fillOpacity={1} fill="url(#colorLeads)" animationDuration={2000} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>

        {/* Pie Chart / Project Breakdown */}
        <GlassCard className="p-8 flex flex-col min-h-[500px]">
          <div className="mb-10">
            <h3 className="text-2xl font-black font-sora text-white tracking-tight italic">Operations</h3>
            <p className="text-xs text-gray-500 mt-1 uppercase tracking-widest font-bold">Category Distribution</p>
          </div>
          
          <div className="flex-1 w-full flex items-center justify-center min-h-[250px]">
            {(data.charts.projectCategories || []).length > 0 ? (
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={250} debounce={100}>
                <PieChart>
                  <Pie
                    data={data.charts.projectCategories}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={90}
                    paddingAngle={8}
                    dataKey="count"
                    animationBegin={500}
                    animationDuration={1500}
                  >
                    {data.charts.projectCategories.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip wrapperStyle={{ outline: 'none' }} contentStyle={{ backgroundColor: '#0f172a', borderColor: '#ffffff10', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.1)' }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
               <div className="flex flex-col items-center justify-center text-gray-600 space-y-4">
                  <RefreshCw size={32} className="animate-spin-slow opacity-20" />
                  <span className="text-[10px] font-black uppercase tracking-[0.3em]">Awaiting Telemetry</span>
               </div>
            )}
          </div>
          
          <div className="space-y-4 mt-8">
            {(data.charts.projectCategories || []).slice(0, 4).map((entry, index) => (
              <div key={index} className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02] border border-white/5">
                <div className="flex items-center space-x-3">
                  <div className="w-2.5 h-2.5 rounded-full shadow-lg" style={{ backgroundColor: COLORS[index % COLORS.length], boxShadow: `0 0 10px ${COLORS[index % COLORS.length]}80` }} />
                  <span className="text-[10px] font-black text-gray-400 capitalize tracking-widest">{entry._id || 'UNCLASSIFIED'}</span>
                </div>
                <span className="text-xs font-bold text-white">{entry.count}</span>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
};

export default Overview;
