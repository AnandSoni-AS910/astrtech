import React, { useState } from "react";
import { toast } from "react-toastify";
import useFetch from "../../../hooks/useFetch";
import cmsService from "../../../api/cmsService";
import DataTable from "../DataTable";
import FormModal from "../FormModal";
import ViewModal from "../modals/ViewModal";
import Button from "../../common/Button";
import ConfirmModal from "../../common/ConfirmModal";
import { Upload, FileText } from "lucide-react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css"; // Quill CSS

const BlogManager = () => {
  const { data, loading, refetch } = useFetch("/blogs?sort=-createdAt");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [viewingItem, setViewingItem] = useState(null);

  // Modal State
  const [modalConfig, setModalConfig] = useState({ isOpen: false, id: null });

  const handleView = (item) => {
    setViewingItem({
      ...item,
      image: item.coverImage, // Normalize for ViewModal
    });
    setIsViewModalOpen(true);
  };

  const [formData, setFormData] = useState({
    title: "",
    excerpt: "",
    content: "",
    category: "",
    tags: "",
    status: "draft",
    image: null,
  });
  const [previewImage, setPreviewImage] = useState(null);

  const handleToggleStatus = async (item) => {
    try {
      const newStatus = item.status === "published" ? "draft" : "published";
      await cmsService.updateBlog(item._id, { status: newStatus });
      toast.success(
        `Article ${newStatus === "published" ? "published" : "moved to drafts"}`,
      );
      refetch();
    } catch {
      toast.error("Failed to update status");
    }
  };

  const columns = [
    { key: "coverImage", label: "Cover" },
    { key: "title", label: "Article Title" },
    {
      key: "status",
      label: "Status",
      render: (val) => (
        <span
          className={`px-2.5 py-1 text-xs font-bold rounded-full uppercase ${val === "published" ? "bg-emerald-500/20 text-emerald-400" : "bg-gray-500/20 text-gray-400"}`}
        >
          {val}
        </span>
      ),
    },
    {
      key: "createdAt",
      label: "Date Added",
      render: (val) => new Date(val).toLocaleDateString(),
    },
  ];

  const handleOpenModal = (item = null) => {
    if (item) {
      setEditingItem(item);
      setFormData({
        title: item.title,
        excerpt: item.excerpt,
        content: item.content,
        category: item.category,
        tags: item.tags?.join(", ") || "",
        status: item.status,
        image: null,
      });
      setPreviewImage(item.coverImage);
    } else {
      setEditingItem(null);
      setFormData({
        title: "",
        excerpt: "",
        content: "",
        category: "",
        tags: "",
        status: "draft",
        image: null,
      });
      setPreviewImage(null);
    }
    setIsModalOpen(true);
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, image: file });
      setPreviewImage(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);

    try {
      const submitData = new FormData();
      submitData.append("title", formData.title);
      submitData.append("excerpt", formData.excerpt);
      submitData.append("content", formData.content);
      submitData.append("category", formData.category);
      submitData.append("status", formData.status);

      if (formData.tags) {
        const tagArray = formData.tags.split(",").map((tag) => tag.trim());
        tagArray.forEach((tag) => submitData.append("tags[]", tag));
      }

      if (formData.image) {
        submitData.append("image", formData.image);
      }

      if (editingItem) {
        await cmsService.updateBlog(editingItem._id, submitData);
        toast.success("Article updated successfully");
      } else {
        await cmsService.createBlog(submitData);
        toast.success("Article created successfully");
      }

      setIsModalOpen(false);
      refetch();
    } catch {
      toast.error("Operation failed");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await cmsService.deleteBlog(id);
      toast.success("Article removed");
      refetch();
    } catch {
      toast.error("Failed to delete article");
    }
  };

  const openConfirm = (id) => {
    setModalConfig({ isOpen: true, id });
  };

  const executeConfirm = () => {
    if (modalConfig.id) handleDelete(modalConfig.id);
  };

  const quillModules = {
    toolbar: [
      [{ header: [1, 2, 3, false] }],
      ["bold", "italic", "underline", "strike", "blockquote"],
      [{ list: "ordered" }, { list: "bullet" }],
      ["link", "image"],
      ["clean"],
    ],
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white font-sora">
            Blog Articles (CMS)
          </h2>
          <p className="text-gray-400 text-sm">
            Compose and manage rich-text articles.
          </p>
        </div>
        <Button onClick={() => handleOpenModal()} className="w-full sm:w-auto">
          {/* <FileText size={18} /> */}
          <span>Create Blog</span>
        </Button>
      </div>

      {loading ? (
        <div className="text-center text-gray-500 py-12 animate-pulse">
          Syncing Articles...
        </div>
      ) : (
        <DataTable
          columns={columns}
          data={data?.data || []}
          onEdit={handleOpenModal}
          onDelete={openConfirm}
          onView={handleView}
          onToggleStatus={handleToggleStatus}
        />
      )}

      <ConfirmModal
        isOpen={modalConfig.isOpen}
        onClose={() => setModalConfig({ ...modalConfig, isOpen: false })}
        onConfirm={executeConfirm}
        title="Purge Intel Report"
        message="Are you sure you want to delete this article? This action cannot be undone and will remove it from the public grid."
        confirmText="Confirm Purge"
        variant="danger"
      />

      <ViewModal
        isOpen={isViewModalOpen}
        onClose={() => setIsViewModalOpen(false)}
        title="Article Intelligence Preview"
        data={viewingItem}
      />

      <FormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingItem ? "Edit Article" : "Write New Article"}
        onSubmit={handleSubmit}
        loading={saving}
      >
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Article Title
          </label>
          <input
            type="text"
            required
            value={formData.title}
            onChange={(e) =>
              setFormData({ ...formData, title: e.target.value })
            }
            className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 outline-none text-white text-lg font-bold"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Excerpt (Short description)
          </label>
          <textarea
            required
            rows="2"
            value={formData.excerpt}
            onChange={(e) =>
              setFormData({ ...formData, excerpt: e.target.value })
            }
            className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 outline-none text-white"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-6 border-b border-white/10">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Category
            </label>
            <input
              type="text"
              required
              value={formData.category}
              onChange={(e) =>
                setFormData({ ...formData, category: e.target.value })
              }
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 outline-none text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Tags (comma separated)
            </label>
            <input
              type="text"
              value={formData.tags}
              onChange={(e) =>
                setFormData({ ...formData, tags: e.target.value })
              }
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 outline-none text-white"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Article Content
          </label>
          <div className="bg-white text-black rounded-lg overflow-hidden">
            <ReactQuill
              theme="snow"
              value={formData.content}
              onChange={(content) => setFormData({ ...formData, content })}
              modules={quillModules}
              className="h-64 mb-12"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 mt-8 border-t border-white/10">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Cover Image
            </label>
            <div className="flex items-center space-x-4">
              <div className="w-24 h-16 bg-[#020617] border border-white/10 rounded-xl overflow-hidden flex items-center justify-center">
                {previewImage ? (
                  <img
                    src={previewImage}
                    alt="preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Upload size={20} className="text-gray-500" />
                )}
              </div>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="file:text-sm file:font-semibold file:bg-white/10 file:text-white file:border-0 hover:file:bg-white/20 text-gray-400"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Publish Status
            </label>
            <select
              value={formData.status}
              onChange={(e) =>
                setFormData({ ...formData, status: e.target.value })
              }
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:border-primary-500 outline-none text-white appearance-none"
            >
              <option value="draft" className="text-black">
                Draft (Hidden)
              </option>
              <option value="published" className="text-black">
                Published (Live)
              </option>
            </select>
          </div>
        </div>
      </FormModal>
    </div>
  );
};

export default BlogManager;
