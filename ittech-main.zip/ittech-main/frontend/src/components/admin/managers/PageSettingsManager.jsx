import React, { useCallback, useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Save, RefreshCcw, Globe, Briefcase, Projector, Users, Activity } from 'lucide-react';
import { toast } from 'react-toastify';
import cmsService from '../../../api/cmsService';
import Button from '../../common/Button';

const PageSettingsManager = () => {
  const [activePage, setActivePage] = useState('home');
  const [settings, setSettings] = useState({});
  const [loading, setLoading] = useState(true);

  const DEFAULTS = {
    home: {
      home_stat1_label: 'Enterprise Solutions', home_stat1_value: '500+',
      home_stat2_label: 'Global Data Centers', home_stat2_value: '24',
      home_stat3_label: 'Expert Consultants', home_stat3_value: '150+',
      home_stat4_label: 'Secure Transactions', home_stat4_value: '99.9%',
    },
    services: {
      services_hero_title: 'Worldwide Elite Ecosystems',
      services_hero_subtitle: 'Deploying mission-critical technical infrastructure for the world\'s most ambitious global corporations.',
      services_ticker_cities: 'LONDON, NEW YORK, TOKYO, SINGAPORE, MUMBAI, SYDNEY, DUBAI, BERLIN',
      services_list_header: 'Advanced Solutions for Global Challenges'
    },
    about: {
      about_hero_title: 'The Architects of Digital Resilience',
      about_hero_subtitle: 'Empowering global conglomerates with high-end technical superiority and autonomous digital ecosystems since 2018.',
      about_mission_title: 'Innovation Built on Expert Foundations.',
      about_mission_p1: 'Founded at the intersection of high-frequency trading and automotive automation, we recognized a critical gap in enterprise infrastructure: Resilience.',
      about_mission_p2: 'In an era where a 10-millisecond delay costs millions, our mission shifted to building the world\'s most robust digital nervous systems.',
      about_hq_value: 'Global Tactical Node 01 Singapore Financial District',
      about_collab_value: 'Fortune 100 Leaders Gov-Tech Agencies',
      about_uptime_value: '99.999%',
      about_cta_title: 'Ready to Build the Future?',
      about_cta_subtitle: 'Partner with us to engineer the next phase of your digital transformation.'
    },
    portfolio: {
      portfolio_hero_title: 'Global Transformations',
      portfolio_hero_subtitle: 'A proven record of high-impact digital architectures and scalable enterprise deployments.'
    }
  };

  const fetchSettings = useCallback(async () => {
    try {
      setLoading(true);
      const data = await cmsService.getSettings(activePage);
      const s = data.data || {};
      
      // Merge with defaults so we never show empty boxes
      const merged = { ...DEFAULTS[activePage], ...s };
      
      const formattedSettings = {};
      Object.keys(merged).forEach(key => {
        if (key === 'services_ticker_cities' && Array.isArray(merged[key])) {
          formattedSettings[key] = merged[key].join(', ');
        } else {
          formattedSettings[key] = merged[key];
        }
      });
      setSettings(formattedSettings);
    } catch {
      toast.error(`Failed to load ${activePage} settings`);
    } finally {
      setLoading(false);
    }
  }, [activePage]);

  useEffect(() => {
    fetchSettings();
  }, [fetchSettings]);

  const handleSaveGroup = async () => {
    try {
      setLoading(true);
      const updateData = { ...settings, group: activePage };
      
      if (updateData.services_ticker_cities && typeof updateData.services_ticker_cities === 'string') {
        updateData.services_ticker_cities = updateData.services_ticker_cities
          .split(',')
          .map(item => item.trim())
          .filter(item => item !== '');
      }

      await cmsService.updateSetting(updateData);
      toast.success(`${activePage.toUpperCase()} tactical synchronization successful`);
    } catch {
      toast.error('Tactical bulk update failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-bold text-white font-sora tracking-tight">Intelligence Content Hub</h2>
          <p className="text-gray-500 mt-1">Global ecosystem narrative management system.</p>
        </div>
        
        <div className="flex bg-white/5 p-1 rounded-2xl border border-white/10 backdrop-blur-xl shrink-0 overflow-x-auto no-scrollbar">
          {[
            { id: 'home', label: 'Home Stats', icon: <Activity size={14} /> },
            { id: 'services', label: 'Services', icon: <Briefcase size={14} /> },
            { id: 'about', label: 'About', icon: <Users size={14} /> },
            { id: 'portfolio', label: 'Portfolio', icon: <Projector size={14} /> }
          ].map((tab) => (
            <button 
              key={tab.id}
              onClick={() => setActivePage(tab.id)}
              className={`flex items-center space-x-2 px-6 py-2.5 rounded-xl transition-all text-[10px] font-black uppercase tracking-widest whitespace-nowrap border ${activePage === tab.id ? 'bg-primary-600 text-white shadow-lg border-primary-500' : 'text-gray-500 hover:text-white border-transparent'}`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center h-96 space-y-4">
          <RefreshCcw className="animate-spin text-primary-500" size={48} />
          <span className="text-[10px] font-black uppercase tracking-[.4em] text-gray-600">Syncing Archives</span>
        </div>
      ) : (
        <AnimatePresence mode="wait">
          <motion.div 
            key={activePage}
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.02 }}
            className="space-y-8"
          >
            {/* 1. HOME STATS TAB */}
            {activePage === 'home' && (
              <div className="bg-white/5 border border-white/5 rounded-3xl p-8 backdrop-blur-xl space-y-8">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-primary-500/10 flex items-center justify-center text-primary-400">
                    <Activity size={20} />
                  </div>
                  <h3 className="text-xl font-bold text-white font-sora">Homepage Tactical Metrics</h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                  {[1,2,3,4].map(i => (
                    <div key={i} className="space-y-5 p-6 border border-white/5 rounded-3xl bg-white/[0.02] hover:bg-white/[0.04] transition-all">
                      <div className="flex items-center justify-between">
                        <label className="text-[10px] font-black uppercase text-gray-600 tracking-widest">Metric 0{i}</label>
                        <div className="w-2 h-2 rounded-full bg-primary-500/40" />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[8px] font-black uppercase text-primary-500 tracking-widest ml-1">Metric Value (Big Number)</label>
                        <input 
                          type="text"
                          value={settings[`home_stat${i}_value`] || ''}
                          onChange={(e) => setSettings({...settings, [`home_stat${i}_value`]: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl h-12 px-4 text-xs font-bold text-white focus:border-primary-500 outline-none"
                          placeholder="e.g. 500+"
                        />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[8px] font-black uppercase text-gray-500 tracking-widest ml-1">Metric Label (Description Text)</label>
                        <input 
                          type="text"
                          value={settings[`home_stat${i}_label`] || ''}
                          onChange={(e) => setSettings({...settings, [`home_stat${i}_label`]: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl h-12 px-4 text-xs text-white focus:border-primary-500 outline-none"
                          placeholder="e.g. Solutions"
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pt-8 border-t border-white/5 flex justify-end">
                  <Button onClick={handleSaveGroup} className="h-14 px-10 shadow-[0_0_30px_rgba(59,130,246,0.2)]">
                    <Save size={18} className="mr-2" />
                    <span className="text-[11px] font-black uppercase tracking-widest">Synchronize All Metrics</span>
                  </Button>
                </div>
              </div>
            )}

            {/* 2. SERVICES TAB */}
            {activePage === 'services' && (
              <div className="space-y-8">
                <div className="bg-white/5 border border-white/5 rounded-3xl p-8 backdrop-blur-xl space-y-8">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-xl bg-primary-500/10 flex items-center justify-center text-primary-400">
                      <Globe size={20} />
                    </div>
                    <h3 className="text-xl font-bold text-white font-sora">Services Hero Architecture</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Neural Headline</label>
                      <input 
                        type="text"
                        value={settings.services_hero_title || ''}
                        onChange={(e) => setSettings({...settings, services_hero_title: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl h-14 px-6 focus:border-primary-500 outline-none text-white text-sm"
                      />
                    </div>
                    <div className="space-y-4">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Sub-Title / Manifesto</label>
                      <textarea 
                        rows="1"
                        value={settings.services_hero_subtitle || ''}
                        onChange={(e) => setSettings({...settings, services_hero_subtitle: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl p-4 focus:border-primary-500 outline-none text-white text-sm resize-none"
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 border border-white/5 rounded-3xl p-8 backdrop-blur-xl space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Ticker Cities (Comma-separated)</label>
                      <input 
                        type="text"
                        value={settings.services_ticker_cities || ''}
                        onChange={(e) => setSettings({...settings, services_ticker_cities: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl h-14 px-6 focus:border-primary-500 outline-none text-white text-sm"
                      />
                    </div>
                    <div className="space-y-4">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Operation Header</label>
                      <input 
                        type="text"
                        value={settings.services_list_header || ''}
                        onChange={(e) => setSettings({...settings, services_list_header: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl h-14 px-6 focus:border-primary-500 outline-none text-white text-sm"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <Button onClick={handleSaveGroup} className="h-14 px-10">
                    <Save size={18} className="mr-2" />
                    <span className="text-[11px] font-black uppercase tracking-widest">Update Services Intelligence</span>
                  </Button>
                </div>
              </div>
            )}

            {/* 3. ABOUT TAB */}
            {activePage === 'about' && (
              <div className="space-y-8">
                <div className="bg-white/5 border border-white/5 rounded-3xl p-8 backdrop-blur-xl space-y-8">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-xl bg-primary-500/10 flex items-center justify-center text-primary-400">
                      <Globe size={20} />
                    </div>
                    <h3 className="text-xl font-bold text-white font-sora">About Hero Architecture</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Neural Headline</label>
                      <input 
                        type="text"
                        value={settings.about_hero_title || ''}
                        onChange={(e) => setSettings({...settings, about_hero_title: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl h-14 px-6 focus:border-primary-500 outline-none text-white text-sm"
                      />
                    </div>
                    <div className="space-y-4">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Sub-Title / Manifesto</label>
                      <textarea 
                        rows="1"
                        value={settings.about_hero_subtitle || ''}
                        onChange={(e) => setSettings({...settings, about_hero_subtitle: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl p-4 focus:border-primary-500 outline-none text-white text-sm resize-none"
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 border border-white/5 rounded-3xl p-8 backdrop-blur-xl space-y-6">
                  <h4 className="text-sm font-black uppercase tracking-widest text-primary-500 underline decoration-primary-500/30">Mission Deep Intelligence</h4>
                  <div className="space-y-4">
                    <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em]">Mission Title</label>
                    <input 
                      type="text"
                      value={settings.about_mission_title || ''}
                      onChange={(e) => setSettings({...settings, about_mission_title: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl h-14 px-6 focus:border-primary-500 outline-none text-white text-sm"
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em]">Mission P1</label>
                      <textarea 
                        rows="4"
                        value={settings.about_mission_p1 || ''}
                        onChange={(e) => setSettings({...settings, about_mission_p1: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl p-4 focus:border-primary-500 outline-none text-white text-xs resize-none"
                      />
                    </div>
                    <div className="space-y-4">
                      <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em]">Mission P2</label>
                      <textarea 
                        rows="4"
                        value={settings.about_mission_p2 || ''}
                        onChange={(e) => setSettings({...settings, about_mission_p2: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl p-4 focus:border-primary-500 outline-none text-white text-xs resize-none"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="bg-white/5 border border-white/5 rounded-3xl p-8 backdrop-blur-xl space-y-6">
                    <h4 className="text-sm font-black uppercase tracking-widest text-primary-400">Headquarters Value</h4>
                    <input 
                      type="text"
                      value={settings.about_hq_value || ''}
                      onChange={(e) => setSettings({...settings, about_hq_value: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl h-14 px-6 focus:border-primary-500 outline-none text-white text-sm"
                    />
                  </div>
                  <div className="bg-white/5 border border-white/5 rounded-3xl p-8 backdrop-blur-xl space-y-6">
                    <h4 className="text-sm font-black uppercase tracking-widest text-primary-400">Collaborations Value</h4>
                    <input 
                      type="text"
                      value={settings.about_collab_value || ''}
                      onChange={(e) => setSettings({...settings, about_collab_value: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl h-14 px-6 focus:border-primary-500 outline-none text-white text-sm"
                    />
                  </div>
                </div>

                <div className="bg-white/5 border border-white/5 rounded-3xl p-8 backdrop-blur-xl space-y-6">
                  <h4 className="text-sm font-black uppercase tracking-widest text-emerald-500">System Performance</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="space-y-4">
                      <label className="text-[10px] font-black uppercase text-gray-500">Visual Uptime Metric</label>
                      <input 
                        type="text"
                        value={settings.about_uptime_value || ''}
                        onChange={(e) => setSettings({...settings, about_uptime_value: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl h-14 px-6 focus:border-primary-500 outline-none text-white text-sm"
                        placeholder="99.999%"
                      />
                    </div>
                    <div className="space-y-4">
                      <label className="text-[10px] font-black uppercase text-gray-500">CTA Title</label>
                      <input 
                        type="text"
                        value={settings.about_cta_title || ''}
                        onChange={(e) => setSettings({...settings, about_cta_title: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl h-14 px-6 focus:border-primary-500 outline-none text-white text-sm"
                      />
                    </div>
                    <div className="space-y-4">
                      <label className="text-[10px] font-black uppercase text-gray-500">CTA Subtitle</label>
                      <input 
                        type="text"
                        value={settings.about_cta_subtitle || ''}
                        onChange={(e) => setSettings({...settings, about_cta_subtitle: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl h-14 px-6 focus:border-primary-500 outline-none text-white text-sm"
                      />
                    </div>
                  </div>
                </div>

                {/* Global Metrics Synchronization Note */}
                <div className="bg-primary-500/5 border border-primary-500/20 rounded-3xl p-8 backdrop-blur-xl flex items-center space-x-6">
                    <div className="w-16 h-16 rounded-2xl bg-primary-500/10 flex items-center justify-center text-primary-400 shrink-0">
                       <Activity size={32} />
                    </div>
                    <div className="space-y-2">
                       <h4 className="text-lg font-bold text-white font-sora">Global Metrics Synchronization</h4>
                       <p className="text-sm text-gray-400 leading-relaxed max-w-2xl">
                          The tactical metrics (Enterprise Solutions, Data Centers, etc.) are now managed globally to ensure consistency across the entire site. To update these stats for both the Home and About pages, please use the <span className="text-primary-400 font-bold">Home Stats</span> tab at the top.
                       </p>
                    </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <Button onClick={handleSaveGroup} variant="emerald" className="h-14 px-12">
                    <Save size={18} className="mr-2" />
                    <span className="text-[11px] font-black uppercase tracking-widest">Synchronize About Infrastructure</span>
                  </Button>
                </div>
              </div>
            )}

            {/* 4. PORTFOLIO TAB */}
            {activePage === 'portfolio' && (
              <div className="space-y-8">
                <div className="bg-white/5 border border-white/5 rounded-3xl p-8 backdrop-blur-xl space-y-8">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400">
                      <Projector size={20} />
                    </div>
                    <h3 className="text-xl font-bold text-white font-sora">Portfolio Hero Architecture</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Archive Headline</label>
                      <input 
                        type="text"
                        value={settings.portfolio_hero_title || ''}
                        onChange={(e) => setSettings({...settings, portfolio_hero_title: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl h-14 px-6 focus:border-primary-500 outline-none text-white text-sm"
                      />
                    </div>
                    <div className="space-y-4">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">System Log Summary</label>
                      <textarea 
                        rows="3"
                        value={settings.portfolio_hero_subtitle || ''}
                        onChange={(e) => setSettings({...settings, portfolio_hero_subtitle: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-xl p-4 focus:border-primary-500 outline-none text-white text-sm resize-none"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <Button onClick={handleSaveGroup} variant="purple" className="h-14 px-12">
                    <Save size={18} className="mr-2" />
                    <span className="text-[11px] font-black uppercase tracking-widest">Update Portfolio Archives</span>
                  </Button>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  );
};

export default PageSettingsManager;
