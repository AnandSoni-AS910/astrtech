import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Calendar, User, FileText, Tag, Link as LinkIcon, Info } from 'lucide-react';
import getImageUrl from '../../../utils/getImageUrl';

const ViewModal = ({ isOpen, onClose, title, data }) => {
  if (!data) return null;

  // Helper to format values
  const formatValue = (key, value) => {
    if (value === null || value === undefined) return 'N/A';
    if (Array.isArray(value)) return value.join(', ');
    if (key.toLowerCase().includes('date') || key === 'createdAt' || key === 'updatedAt') {
      return new Date(value).toLocaleString();
    }
    return String(value);
  };

  // Skip internal/unnecessary fields
  const excludedFields = ['_id', '__v', 'image', 'password', 'avatar', 'role', 'preferences'];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-6">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-[#020617]/80 backdrop-blur-sm"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-2xl bg-[#0f172a] border border-white/10 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
          >
            {/* Header */}
            <div className="p-6 border-b border-white/5 flex justify-between items-center bg-white/5">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-primary-500/10 flex items-center justify-center text-primary-400 border border-primary-500/20">
                  <Info size={20} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white font-sora">{title || 'Resource Details'}</h3>
                  <p className="text-[10px] font-black uppercase tracking-widest text-gray-500">Global Read Access</p>
                </div>
              </div>
              <button 
                onClick={onClose}
                className="w-10 h-10 flex items-center justify-center rounded-xl bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white transition-all"
              >
                <X size={20} />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-8 space-y-8 no-scrollbar">
              {/* Media Preview if exists */}
              {(data.image || data.avatar) && (
                <div className="relative group rounded-2xl overflow-hidden border border-white/10 aspect-video bg-white/5">
                  <img 
                    src={getImageUrl(data.image || data.avatar)} 
                    alt="Preview" 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0f172a] via-transparent to-transparent opacity-60" />
                </div>
              )}

              {/* Data Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Object.entries(data).map(([key, value]) => {
                  if (excludedFields.includes(key)) return null;
                  
                  return (
                    <div key={key} className="space-y-2 p-4 rounded-2xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] transition-all">
                      <div className="flex items-center space-x-2 text-primary-400">
                         {key.toLowerCase().includes('title') || key.toLowerCase().includes('name') ? <User size={12} /> : 
                          key.toLowerCase().includes('date') ? <Calendar size={12} /> : 
                          key.toLowerCase().includes('desc') ? <FileText size={12} /> : 
                          key.toLowerCase().includes('category') ? <Tag size={12} /> : 
                          key.toLowerCase().includes('url') || key.toLowerCase().includes('link') ? <LinkIcon size={12} /> :
                          <Info size={12} />}
                         <span className="text-[10px] font-black uppercase tracking-widest text-gray-500">{key.replace(/([A-Z])/g, ' $1')}</span>
                      </div>
                      <div className="text-white font-medium break-words leading-relaxed">
                        {formatValue(key, value)}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Specific handling for Long Text (Descriptions/Features) */}
              {data.description && (
                <div className="space-y-4 p-6 rounded-2xl bg-primary-500/5 border border-primary-500/10">
                  <div className="flex items-center space-x-2 text-primary-400">
                    <FileText size={16} />
                    <span className="text-[10px] font-black uppercase tracking-widest">In-Depth Description</span>
                  </div>
                  <p className="text-gray-300 text-sm leading-loose whitespace-pre-wrap">
                    {data.description}
                  </p>
                </div>
              )}

              {data.features && Array.isArray(data.features) && (
                <div className="space-y-4">
                  <div className="flex items-center space-x-2 text-emerald-400">
                    <Tag size={16} />
                    <span className="text-[10px] font-black uppercase tracking-widest">Tactical Features</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {data.features.map((feature, i) => (
                      <div key={i} className="flex items-center space-x-3 p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/10 text-emerald-400 text-xs font-bold">
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                        {feature}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-6 border-t border-white/5 bg-white/5 flex justify-end">
              <button 
                onClick={onClose}
                className="px-8 py-3 rounded-xl bg-white/5 text-white font-bold text-xs uppercase tracking-widest hover:bg-white/10 transition-all border border-white/10"
              >
                Close View
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default ViewModal;
