import { Menu, X, Rocket } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { AnimatePresence, motion as Motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import Button from './Button';
import useFetch from '../../hooks/useFetch';
import getImageUrl from '../../utils/getImageUrl';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  const { data: settingsData } = useFetch("/settings");
  const settings = settingsData?.data || { companyName: "IT Tech" };
  const companyNameParts = (settings.companyName || "IT Tech").split(" ");

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setIsOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Services', path: '/services' },
    { name: 'Portfolio', path: '/portfolio' },
    { name: 'About', path: '/about' },
    { name: 'Blog', path: '/blog' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <nav className={`fixed w-full z-50 transition-all duration-500 border-b ${
      isScrolled 
        ? 'bg-[#020617]/80 backdrop-blur-xl py-3 lg:py-4 shadow-2xl border-white/5' 
        : 'bg-transparent py-5 lg:py-7 border-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-3 group">
            <div className="w-11 h-11 bg-gradient-to-tr from-primary-600 to-secondary-500 rounded-2xl flex items-center justify-center shadow-lg shadow-primary-500/20 group-hover:rotate-12 transition-transform duration-500 overflow-hidden">
              {settings.company_logo ? (
                <img 
                  src={getImageUrl(settings.company_logo)} 
                  alt={settings.companyName} 
                  className="w-full h-full object-contain p-1.5"
                />
              ) : (
                <Rocket className="text-white w-6 h-6" />
              )}
            </div>
            <span className="text-lg sm:text-2xl font-bold font-sora tracking-tight max-w-[min(65vw,16rem)] truncate">
              {companyNameParts[0]}{" "}
              <span className="text-primary-500">
                {companyNameParts.slice(1).join(" ")}
              </span>
            </span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden lg:flex items-center space-x-6 xl:space-x-10">
            {navLinks.map((link) => (
              <Link 
                key={link.path} 
                to={link.path} 
                className={`text-sm font-bold tracking-wide transition-all relative py-2 group ${
                  location.pathname === link.path ? 'text-white' : 'text-gray-400 hover:text-white'
                }`}
              >
                {link.name}
                {location.pathname === link.path && (
                  <Motion.div 
                    layoutId="navActive"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-500 rounded-full"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
                {/* Hover Underline */}
                <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary-500/50 group-hover:w-full transition-all duration-300 rounded-full" />
              </Link>
            ))}
            <Link 
              to="/contact" 
            >
              <Button size="sm" className="px-7 py-2.5 shadow-xl shadow-primary-500/20">
                Get a Quote
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden">
            <button 
              onClick={() => setIsOpen(!isOpen)} 
              className="p-2 text-gray-300 hover:text-white transition-colors"
              aria-label="Toggle Menu"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      <AnimatePresence>
        {isOpen && (
          <Motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-[#020617]/95 backdrop-blur-2xl border-t border-white/5 overflow-hidden"
          >
            <div className="px-6 py-8 space-y-6 flex flex-col">
              {navLinks.map((link) => (
                <Link 
                  key={link.path} 
                  to={link.path} 
                  className={`text-xl font-bold font-sora hover:text-primary-400 ${
                    location.pathname === link.path ? 'text-primary-500' : 'text-gray-300'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
              <Link to="/contact">
                <Button variant="primary" className="w-full py-4 text-lg shadow-xl shadow-primary-600/20">
                  Get a Quote
                </Button>
              </Link>
            </div>
          </Motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
