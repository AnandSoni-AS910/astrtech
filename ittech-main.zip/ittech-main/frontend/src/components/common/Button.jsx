import React from 'react';
import { motion as Motion } from 'framer-motion';

const Button = ({ children, onClick, type = 'button', variant = 'primary', className = '', loading = false, ...props }) => {
  const variants = {
    primary: 'bg-primary-600 hover:bg-primary-500 text-white shadow-lg shadow-primary-900/30',
    secondary: 'bg-white/10 hover:bg-white/20 text-white backdrop-blur-sm border border-white/10',
    outline: 'border-2 border-primary-500/50 hover:bg-primary-500 text-white hover:border-primary-500',
    ghost: 'hover:bg-white/5 text-gray-400 hover:text-white',
    white: 'bg-white text-primary-700 hover:bg-slate-50 shadow-2xl shadow-white/10 hover:text-primary-800',
    emerald: 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-900/30',
    purple: 'bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-900/30',
    red: 'bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-900/30',
  };

  return (
    <Motion.button
      whileHover={loading ? {} : { scale: 1.02, y: -2 }}
      whileTap={loading ? {} : { scale: 0.98 }}
      type={type}
      onClick={onClick}
      disabled={loading}
      className={`h-12 px-8 rounded-2xl font-bold text-sm tracking-wide transition-all duration-300 disabled:opacity-50 disabled:cursor-wait relative flex items-center justify-center space-x-3 group overflow-hidden whitespace-nowrap flex-nowrap focus:ring-4 focus:ring-primary-500/20 outline-none ${variants[variant]} ${className}`}
      {...props}
    >
      {/* Gloss effect */}
      <div className="absolute inset-0 bg-gradient-to-tr from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
      
      {loading ? (
        <div className="flex items-center justify-center space-x-2">
          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          <span className="opacity-70 font-medium">Processing...</span>
        </div>
      ) : (
        <span className="relative z-10 flex items-center justify-center space-x-2">{children}</span>
      )}
    </Motion.button>
  );
};

export default Button;
