import { Helmet } from "react-helmet-async";
import useFetch from "../../hooks/useFetch";
import getImageUrl from "../../utils/getImageUrl";

const SEO = ({
  title,
  description,
  keywords,
  image,
  url,
  type = "website",
}) => {
  const { data: settingsData } = useFetch("/settings");
  const settings = settingsData?.data || {};

  const siteTitle = settings.companyName
    ? `${settings.companyName} | High-End Tech`
    : "ITTech | The Architects of Digital Resilience";
  const fullTitle = title
    ? `${title} | ${settings.companyName || "ITTech"}`
    : siteTitle;
  const defaultDescription =
    settings.tagline ||
    "Empowering global conglomerates with high-end technical superiority and autonomous digital ecosystems since 2018.";
  const metaDescription = description || defaultDescription;
  const siteUrl = window.location.origin;
  const metaUrl = url ? `${siteUrl}${url}` : window.location.href;
  const metaImage =
    image ||
    (settings.company_logo
      ? getImageUrl(settings.company_logo)
      : `${siteUrl}/og-image.jpg`);
  const metaKeywords =
    keywords ||
    "IT Solutions, Cybersecurity, Cloud Infrastructure, Enterprise IT Services, Digital Transformation, IT Support in Jodhpur, IT Tech India, IT Consultancy Rajasthan";
  const favicon = settings.company_logo
    ? `${getImageUrl(settings.company_logo)}?v=${settings.updatedAt ? new Date(settings.updatedAt).getTime() : "1"}`
    : "/favicon.svg";

  return (
    <Helmet>
      {/* Standard Metadata */}
      <title>{fullTitle}</title>
      <meta name="description" content={metaDescription} />
      <meta name="keywords" content={metaKeywords} />
      <link rel="canonical" href={metaUrl} />
      <link rel="icon" href={favicon} key="favicon-icon" />
      <link rel="shortcut icon" href={favicon} key="favicon-shortcut" />
      <link rel="apple-touch-icon" href={favicon} key="favicon-apple" />

      {/* Open Graph / Facebook */}
      <meta property="og:type" content={type} />
      <meta property="og:url" content={metaUrl} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={metaDescription} />
      <meta property="og:image" content={metaImage} />

      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:url" content={metaUrl} />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={metaDescription} />
      <meta name="twitter:image" content={metaImage} />

      {/* Robots */}
      <meta name="robots" content="index, follow" />
      <meta name="googlebot" content="index, follow" />

      {/* Structured Data (JSON-LD) */}
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          "name": "IT TECH",
          "url": siteUrl,
          "logo": favicon,
          "contactPoint": {
            "@type": "ContactPoint",
            "telephone": "+91-9799526124",
            "contactType": "customer service",
            "areaServed": "IN",
            "availableLanguage": "en"
          },
          "sameAs": [
            settings.facebook || "",
            settings.twitter || "",
            settings.linkedin || "",
            settings.instagram || ""
          ].filter(Boolean)
        })}
      </script>

      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "LocalBusiness",
          "name": "IT TECH",
          "image": metaImage,
          "@id": siteUrl,
          "url": siteUrl,
          "telephone": "9799526124",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "New Power House Circle",
            "addressLocality": "Jodhpur",
            "addressRegion": "Rajasthan",
            "postalCode": "342001",
            "addressCountry": "IN"
          },
          "geo": {
            "@type": "GeoCoordinates",
            "latitude": 26.2389,
            "longitude": 73.0243
          },
          "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
              "Monday",
              "Tuesday",
              "Wednesday",
              "Thursday",
              "Friday",
              "Saturday"
            ],
            "opens": "09:00",
            "closes": "18:00"
          }
        })}
      </script>

      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          "name": "IT TECH",
          "url": siteUrl,
          "potentialAction": {
            "@type": "SearchAction",
            "target": `${siteUrl}/blog?q={search_term_string}`,
            "query-input": "required name=search_term_string"
          }
        })}
      </script>

      {/* Breadcrumb Schema */}
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          "itemListElement": [
            {
              "@type": "ListItem",
              "position": 1,
              "name": "Home",
              "item": siteUrl
            },
            ...(url && url !== "/" ? [{
              "@type": "ListItem",
              "position": 2,
              "name": title || "Current Page",
              "item": `${siteUrl}${url}`
            }] : [])
          ]
        })}
      </script>
    </Helmet>
  );
};

export default SEO;
