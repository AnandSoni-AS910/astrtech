import {
  Rocket,
  Mail,
  MapPin,
  Phone,
  Globe,
  Send,
  Briefcase,
  Camera,
  ArrowRight,
} from "lucide-react";
import { Link } from "react-router-dom";
import useFetch from "../../hooks/useFetch";
import getImageUrl from "../../utils/getImageUrl";

const Footer = () => {
  const { data: settingsData } = useFetch("/settings");
  const { data: servicesData } = useFetch("/services?limit=4");

  const s = settingsData?.data || {};
  const services = servicesData?.data || [];

  const settings = {
    companyName: s.companyName || "IT Tech",
    tagline:
      s.tagline ||
      "Empowering businesses with cutting-edge technology solutions.",
    email: s.email || "contact@ittech.com",
    phone: s.phone || "9799526124",
    address: s.address || "New Power House Cricle,Jodhpur",
    facebook: s.facebook || "#",
    twitter: s.twitter || "#",
    instagram: s.instagram || "#",
    linkedin: s.linkedin || "#",
  };

  const socialLinks = [
    { icon: <Globe size={18} />, url: settings.facebook, label: "Facebook" },
    { icon: <Send size={18} />, url: settings.twitter, label: "Twitter" },
    {
      icon: <Briefcase size={18} />,
      url: settings.linkedin,
      label: "LinkedIn",
    },
    { icon: <Camera size={18} />, url: settings.instagram, label: "Instagram" },
  ].filter((link) => link.url && link.url !== "#");

  return (
    <footer className="relative pt-24 pb-12 bg-[#020617] border-t border-white/5 overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-primary-600/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-16 mb-20">
          {/* Brand Vector */}
          <div className="space-y-8">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-tr from-primary-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-primary-500/20 overflow-hidden">
                {s.company_logo ? (
                  <img 
                    src={getImageUrl(s.company_logo)} 
                    alt={settings.companyName} 
                    className="w-full h-full object-contain p-2"
                  />
                ) : (
                  <Rocket className="text-white w-6 h-6" />
                )}
              </div>
              <span className="text-fluid-body-lg font-black font-sora tracking-tighter break-words">
                {settings.companyName.split(" ")[0]}
                <span className="text-primary-500">
                  {settings.companyName.includes(" ")
                    ? " " + settings.companyName.split(" ").slice(1).join(" ")
                    : ""}
                </span>
              </span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed max-w-xs font-medium break-words">
              {settings.tagline}
            </p>
            <div className="flex space-x-3">
              {socialLinks.map((link, idx) => (
                <a
                  key={idx}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-11 h-11 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:bg-primary-600 hover:border-primary-500 transition-all duration-300"
                  aria-label={link.label}
                >
                  {link.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Neural Services (Dynamic) */}
          <div>
            <h4 className="text-sm font-black uppercase tracking-[0.2em] text-white/40 mb-8 font-sora">
              Our Services
            </h4>
            <ul className="space-y-4">
              {services.length > 0
                ? services.map((service) => (
                    <li key={service._id}>
                      <Link
                        to="/services"
                        className="text-gray-400 hover:text-primary-400 transition-colors text-sm font-bold flex items-center group break-words"
                      >
                        <ArrowRight
                          size={14}
                          className="mr-0 opacity-0 group-hover:mr-2 group-hover:opacity-100 transition-all"
                        />
                        {service.title}
                      </Link>
                    </li>
                  ))
                : [
                    "Web Development",
                    "Mobile Apps",
                    "Cloud Architecture",
                    "Cybersecurity",
                  ].map((item, i) => (
                    <li key={i} className="text-gray-500 text-sm font-medium">
                      {item}
                    </li>
                  ))}
            </ul>
          </div>

          {/* Rapid Links */}
          <div>
            <h4 className="text-sm font-black uppercase tracking-[0.2em] text-white/40 mb-8 font-sora">
              Rapid Links
            </h4>
            <ul className="space-y-4 text-sm font-bold text-gray-400">
              <li>
                <Link
                  to="/about"
                  className="hover:text-primary-400 transition-colors"
                >
                  About Us
                </Link>
              </li>
              <li>
                <Link
                  to="/portfolio"
                  className="hover:text-primary-400 transition-colors"
                >
                  Case Studies
                </Link>
              </li>
              <li>
                <Link
                  to="/blog"
                  className="hover:text-primary-400 transition-colors"
                >
                  Latest Insights
                </Link>
              </li>
              <li>
                <Link
                  to="/contact"
                  className="hover:text-primary-400 transition-colors"
                >
                  Contact Sales
                </Link>
              </li>
            </ul>
          </div>

          {/* Tactical Contact */}
          <div>
            <h4 className="text-sm font-black uppercase tracking-[0.2em] text-white/40 mb-8 font-sora">
              Get In Touch
            </h4>
            <ul className="space-y-6">
              <li className="flex items-start space-x-4 group">
                <div className="w-10 h-10 rounded-xl bg-primary-500/10 flex items-center justify-center text-primary-400 group-hover:bg-primary-500 group-hover:text-white transition-all shrink-0">
                  <MapPin size={18} />
                </div>
                <div className="space-y-1 min-w-0">
                  <span className="block text-[10px] font-black uppercase tracking-widest text-white/30">
                    Headquarters
                  </span>
                  <span className="text-sm font-bold text-gray-300 leading-snug break-words">
                    {settings.address}
                  </span>
                </div>
              </li>
              <li className="flex items-start space-x-4 group">
                <div className="w-10 h-10 rounded-xl bg-primary-500/10 flex items-center justify-center text-primary-400 group-hover:bg-primary-500 group-hover:text-white transition-all shrink-0">
                  <Phone size={18} />
                </div>
                <div className="space-y-1 min-w-0">
                  <span className="block text-[10px] font-black uppercase tracking-widest text-white/30">
                    Phone Support
                  </span>
                  <span className="text-sm font-bold text-gray-300 break-words">
                    {settings.phone}
                  </span>
                </div>
              </li>
              <li className="flex items-start space-x-4 group">
                <div className="w-10 h-10 rounded-xl bg-primary-500/10 flex items-center justify-center text-primary-400 group-hover:bg-primary-500 group-hover:text-white transition-all shrink-0">
                  <Mail size={18} />
                </div>
                <div className="space-y-1 min-w-0">
                  <span className="block text-[10px] font-black uppercase tracking-widest text-white/30">
                    Email Address
                  </span>
                  <span className="text-sm font-bold text-gray-300 break-words">
                    {settings.email}
                  </span>
                </div>
              </li>
            </ul>
          </div>
        </div>

        {/* Global Footer Bottom */}
        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-[10px] font-black uppercase tracking-[0.3em] text-white/20">
            &copy; {new Date().getFullYear()} {settings.companyName}. ALL RIGHTS RESERVED
          </p>
          <div className="flex flex-wrap justify-center md:justify-end gap-x-8 gap-y-2 text-[10px] font-black uppercase tracking-widest text-white/30">
            <Link to="/privacy-policy" className="hover:text-primary-500 transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms-of-service" className="hover:text-primary-500 transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
