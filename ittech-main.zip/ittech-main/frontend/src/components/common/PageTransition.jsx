import React from 'react';
import { motion as Motion } from 'framer-motion';

const PageTransition = ({ children }) => {
  return (
    <Motion.div
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 1.02 }}
      transition={{ 
        duration: 0.6, 
        ease: [0.22, 1, 0.36, 1] // Custom quintic ease for "Apple-like" feel
      }}
      className="w-full h-full"
    >
      {children}
    </Motion.div>
  );
};

export default PageTransition;
