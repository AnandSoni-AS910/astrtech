import React from 'react';
import { motion as Motion } from 'framer-motion';

const GlassCard = ({ children, className = '', delay = 0, hover = true }) => {
  const cardVariants = {
    hidden: { opacity: 0, y: 30, scale: 0.98 },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: {
        duration: 0.8,
        delay,
        ease: [0.22, 1, 0.36, 1]
      }
    }
  };

  return (
    <Motion.div
      variants={cardVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-50px" }}
      whileHover={hover ? { 
        y: -10, 
        scale: 1.01,
        transition: { duration: 0.4, ease: "easeOut" }
      } : {}}
      className={`glass-card p-6 rounded-[2rem] transition-shadow duration-500 hover:shadow-2xl hover:shadow-primary-500/10 ${className}`}
    >
      {children}
    </Motion.div>
  );
};

export default GlassCard;
