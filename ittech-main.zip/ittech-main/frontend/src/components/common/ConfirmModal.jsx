import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, X } from 'lucide-react';
import Button from './Button';

const ConfirmModal = ({ 
  isOpen, 
  onClose, 
  onConfirm, 
  title = "Tactical Confirmation", 
  message = "Are you sure you want to proceed with this protocol?",
  confirmText = "Execute",
  cancelText = "Abort",
  variant = "danger" // danger, warning, primary
}) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 overflow-hidden">
        {/* Backdrop */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        />

        {/* Modal Content */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative w-full max-w-md bg-[#0f172a]/90 backdrop-blur-xl border border-white/10 rounded-[2.5rem] shadow-2xl overflow-hidden"
        >
          {/* Header Accent */}
          <div className={`h-2 w-full ${
            variant === 'danger' ? 'bg-red-500' : 
            variant === 'warning' ? 'bg-amber-500' : 'bg-primary-500'
          }`} />

          <div className="p-8">
            <div className="flex justify-between items-start mb-6">
              <div className={`p-4 rounded-2xl ${
                variant === 'danger' ? 'bg-red-500/10 text-red-500' : 
                variant === 'warning' ? 'bg-amber-500/10 text-amber-500' : 'bg-primary-500/10 text-primary-500'
              }`}>
                <AlertTriangle size={32} />
              </div>
              <button 
                onClick={onClose}
                className="p-2 text-gray-500 hover:text-white transition-colors"
              >
                <X size={24} />
              </button>
            </div>

            <div className="space-y-2 mb-8">
              <h3 className="text-2xl font-black font-sora text-white tracking-tight italic">
                {title}
              </h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                {message}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={onClose}
                className="flex-1 py-4 px-6 rounded-2xl bg-white/5 border border-white/10 text-gray-400 font-black text-[10px] uppercase tracking-[0.2em] hover:bg-white/10 hover:text-white transition-all"
              >
                {cancelText}
              </button>
              <Button
                onClick={() => {
                  onConfirm();
                  onClose();
                }}
                className={`flex-1 py-4 px-6 !rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] shadow-lg ${
                  variant === 'danger' ? 'bg-red-500 hover:bg-red-600 shadow-red-500/20' : 
                  variant === 'warning' ? 'bg-amber-500 hover:bg-amber-600 shadow-amber-500/20' : 'bg-primary-500 hover:bg-primary-600 shadow-primary-500/20'
                }`}
              >
                {confirmText}
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default ConfirmModal;
