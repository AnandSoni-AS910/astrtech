import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
} from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// Public Components
import Navbar from "./components/common/Navbar";
import Footer from "./components/common/Footer";
import ScrollToTop from "./components/common/ScrollToTop";
import PageTransition from "./components/common/PageTransition";

import { AnimatePresence } from "framer-motion";
import { Suspense, lazy } from "react";

// Public Pages (Lazy Loaded)
const Home = lazy(() => import("./pages/client/Home"));
const About = lazy(() => import("./pages/client/About"));
const Services = lazy(() => import("./pages/client/Services"));
const Portfolio = lazy(() => import("./pages/client/Portfolio"));
const Contact = lazy(() => import("./pages/client/Contact"));
const Blogs = lazy(() => import("./pages/client/Blogs"));
const PrivacyPolicy = lazy(() => import("./pages/client/PrivacyPolicy"));
const TermsOfService = lazy(() => import("./pages/client/TermsOfService"));
const NotFound = lazy(() => import("./pages/client/NotFound"));

// Admin Pages (Lazy Loaded)
const Login = lazy(() => import("./pages/admin/Login"));
const Dashboard = lazy(() => import("./pages/admin/Dashboard"));

// Loading Placeholder
const PageLoader = () => (
  <div className="min-h-screen bg-[#020617] flex items-center justify-center">
    <div className="w-12 h-12 border-4 border-primary-500/20 border-t-primary-500 rounded-full animate-spin" />
  </div>
);

const AppContent = () => {
  const location = useLocation();
  const isAdminRoute = location.pathname.startsWith("/admin") || location.pathname === "/login";

  // Appearance Engine
  React.useEffect(() => {
    const applyTheme = async () => {
      try {
        const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
        // Add cache buster to ensure we get fresh settings after an update
        const response = await fetch(`${apiUrl}/settings?t=${Date.now()}`);
        const { data } = await response.json();
        
        if (data) {
          const root = document.documentElement;
          
          // 1. Apply Theme Background
          const themes = {
            deep_ocean: '#020617',
            midnight: '#0f172a',
            obsidian: '#000000'
          };
          root.style.setProperty('--background', themes[data.admin_theme] || '#020617');

          // 2. Apply Accent Color (Full 10-shade Palette for professional consistency)
          const accents = {
            blue: {
              50: '239 246 255', 100: '219 234 254', 200: '191 219 254', 300: '147 197 253', 
              400: '96 165 250', 500: '59 130 246', 600: '37 99 235', 700: '29 78 216', 
              800: '30 64 175', 900: '30 58 138', 950: '23 37 84'
            },
            purple: {
              50: '245 243 255', 100: '237 233 254', 200: '221 214 254', 300: '196 181 253', 
              400: '167 139 250', 500: '139 92 246', 600: '124 58 237', 700: '109 40 217', 
              800: '91 33 182', 900: '76 29 149', 950: '46 16 101'
            },
            emerald: {
              50: '236 253 245', 100: '209 250 229', 200: '167 243 208', 300: '110 231 183', 
              400: '52 211 153', 500: '16 185 129', 600: '5 150 105', 700: '4 120 87', 
              800: '6 95 70', 900: '6 78 59', 950: '2 44 34'
            },
            rose: {
              50: '255 241 242', 100: '255 228 230', 200: '254 205 211', 300: '253 164 175', 
              400: '251 113 133', 500: '244 63 94', 600: '225 29 72', 700: '190 18 60', 
              800: '159 18 57', 900: '136 19 55', 950: '76 5 25'
            },
            red: {
              50: '254 242 242', 100: '254 226 226', 200: '254 202 202', 300: '252 165 165', 
              400: '248 113 113', 500: '239 68 68', 600: '220 38 38', 700: '185 28 28', 
              800: '153 27 27', 900: '127 29 29', 950: '69 10 10'
            },
            amber: {
              50: '255 251 235', 100: '254 243 199', 200: '253 238 152', 300: '252 211 77', 
              400: '251 191 36', 500: '245 158 11', 600: '217 119 6', 700: '180 83 9', 
              800: '146 64 14', 900: '120 53 15', 950: '69 26 3'
            }
          };

          const palette = accents[data.accent_color] || accents.purple;
          
          // Inject all 10 shades into the root
          Object.entries(palette).forEach(([shade, rgb]) => {
            root.style.setProperty(`--primary-${shade}`, rgb);
          });

          // 3. Apply Glass Effects
          const isGlass = data.glass_effects === 'true';
          root.style.setProperty('--glass-blur', isGlass ? '16px' : '0px');
          root.style.setProperty('--glass-opacity', isGlass ? '0.03' : '0.12');
        }
      } catch (err) {
        console.error("Appearance Engine Failure:", err);
      }
    };

    applyTheme();

    // Listen for manual updates
    window.addEventListener('appearance-update', applyTheme);
    return () => window.removeEventListener('appearance-update', applyTheme);
  }, [location.pathname]); // Re-sync on route change to be safe

  return (
    <div className="min-h-screen bg-[var(--background)] text-white selection:bg-primary-500/30 overflow-x-hidden transition-colors duration-500">
      <ScrollToTop />
      {!isAdminRoute && <Navbar />}
      <main>
        <AnimatePresence mode="wait">
          <Suspense fallback={<PageLoader />}>
            <Routes location={location} key={location.pathname}>
              {/* Public Routes */}
              <Route
                path="/"
                element={
                  <PageTransition>
                    <Home />
                  </PageTransition>
                }
              />
              <Route
                path="/about"
                element={
                  <PageTransition>
                    <About />
                  </PageTransition>
                }
              />
              <Route
                path="/services"
                element={
                  <PageTransition>
                    <Services />
                  </PageTransition>
                }
              />
              <Route
                path="/portfolio"
                element={
                  <PageTransition>
                    <Portfolio />
                  </PageTransition>
                }
              />
              <Route
                path="/blog"
                element={
                  <PageTransition>
                    <Blogs />
                  </PageTransition>
                }
              />
              <Route
                path="/contact"
                element={
                  <PageTransition>
                    <Contact />
                  </PageTransition>
                }
              />
              <Route
                path="/privacy-policy"
                element={
                  <PageTransition>
                    <PrivacyPolicy />
                  </PageTransition>
                }
              />
              <Route
                path="/terms-of-service"
                element={
                  <PageTransition>
                    <TermsOfService />
                  </PageTransition>
                }
              />
              <Route
                path="*"
                element={
                  <PageTransition>
                    <NotFound />
                  </PageTransition>
                }
              />

              {/* Admin Routes */}
              <Route
                path="/login"
                element={
                  <PageTransition>
                    <Login />
                  </PageTransition>
                }
              />
              <Route
                path="/admin"
                element={
                  <PageTransition>
                    <Dashboard />
                  </PageTransition>
                }
              />
            </Routes>
          </Suspense>
        </AnimatePresence>
      </main>
      {!isAdminRoute && <Footer />}
      <ToastContainer
        theme="dark"
        position="top-right"
        style={{ top: "80px" }}
        toastStyle={{
          background: "rgba(15, 23, 42, 0.9)",
          backdropFilter: "blur(12px)",
          border: "1px solid rgba(255, 255, 255, 0.1)",
          borderRadius: "16px",
          boxShadow: "0 20px 40px -15px rgba(0, 0, 0, 0.5)",
        }}
      />
    </div>
  );
};

import { HelmetProvider } from "react-helmet-async";

const App = () => {
  return (
    <HelmetProvider>
      <Router>
        <AppContent />
      </Router>
    </HelmetProvider>
  );
};

export default App;
