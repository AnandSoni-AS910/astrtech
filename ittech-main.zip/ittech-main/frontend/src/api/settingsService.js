import apiClient from "./client";

export const settingsService = {
  getSettings: async () => {
    const { data } = await apiClient.get("/settings");
    return data;
  },
  updateSettings: async (settingsData) => {
    const isFormData = settingsData instanceof FormData;
    const { data } = await apiClient.post("/settings", settingsData, {
      headers: isFormData ? { 'Content-Type': 'multipart/form-data' } : {}
    });
    return data;
  },
};

export default settingsService;
