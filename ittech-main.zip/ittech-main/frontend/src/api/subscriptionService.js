import apiClient from './client';

const subscriptionService = {
  // Public endpoint – creates a subscription entry
  // Accepts an object { email } or just the email string; we will send { email }
  subscribe: async (email) => {
    // Ensure payload is an object with email field
    const payload = typeof email === 'string' ? { email } : email;
    const { data } = await apiClient.post('/subscriptions', payload);
    return data;
  },
  // Admin fetch – used in admin panel
  getAll: async () => {
    const { data } = await apiClient.get('/subscriptions');
    return data;
  }
};

export default subscriptionService;
