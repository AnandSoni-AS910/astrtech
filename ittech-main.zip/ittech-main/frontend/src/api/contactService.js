import apiClient from './client';

export const contactService = {
  submitInquiry: async (formData) => {
    const { data } = await apiClient.post('/contact', formData);
    return data;
  },
  getInquiries: async () => {
    const { data } = await apiClient.get('/contact/inbox');
    return data;
  },
  updateStatus: async (id, status) => {
    const { data } = await apiClient.put(`/contact/${id}`, { status });
    return data;
  }
};

export default contactService;
