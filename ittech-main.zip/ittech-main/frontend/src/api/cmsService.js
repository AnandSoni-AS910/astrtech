import apiClient from './client';

export const cmsService = {
  // Services
  getServices: async (params) => {
    const { data } = await apiClient.get('/services', { params });
    return data;
  },
  createService: async (serviceData) => {
    const { data } = await apiClient.post('/services', serviceData);
    return data;
  },
  updateService: async (id, serviceData) => {
    const { data } = await apiClient.put(`/services/${id}`, serviceData);
    return data;
  },
  deleteService: async (id) => {
    const { data } = await apiClient.delete(`/services/${id}`);
    return data;
  },

  // Settings
  getSettings: async (group) => {
    const { data } = await apiClient.get('/settings', { params: { group } });
    return data;
  },
  updateSetting: async (settingData) => {
    const { data } = await apiClient.post('/settings', settingData);
    return data;
  },

  // Projects
  getProjects: async (params) => {
    const { data } = await apiClient.get('/projects', { params });
    return data;
  },
  createProject: async (projectData) => {
    const { data } = await apiClient.post('/projects', projectData);
    return data;
  },
  updateProject: async (id, projectData) => {
    const { data } = await apiClient.put(`/projects/${id}`, projectData);
    return data;
  },
  deleteProject: async (id) => {
    const { data } = await apiClient.delete(`/projects/${id}`);
    return data;
  },

  // Banners
  getBanners: async () => {
    const { data } = await apiClient.get('/banners');
    return data;
  },
  createBanner: async (bannerData) => {
    const { data } = await apiClient.post('/banners', bannerData);
    return data;
  },
  updateBanner: async (id, bannerData) => {
    const { data } = await apiClient.put(`/banners/${id}`, bannerData);
    return data;
  },
  deleteBanner: async (id) => {
    const { data } = await apiClient.delete(`/banners/${id}`);
    return data;
  },

  // Testimonials
  getTestimonials: async () => {
    const { data } = await apiClient.get('/testimonials');
    return data;
  },
  createTestimonial: async (testimonialData) => {
    const { data } = await apiClient.post('/testimonials', testimonialData);
    return data;
  },
  updateTestimonial: async (id, testimonialData) => {
    const { data } = await apiClient.put(`/testimonials/${id}`, testimonialData);
    return data;
  },
  deleteTestimonial: async (id) => {
    const { data } = await apiClient.delete(`/testimonials/${id}`);
    return data;
  },

  // Blogs
  getBlogs: async (params) => {
    const { data } = await apiClient.get('/blogs', { params });
    return data;
  },
  createBlog: async (blogData) => {
    const { data } = await apiClient.post('/blogs', blogData);
    return data;
  },
  updateBlog: async (id, blogData) => {
    const { data } = await apiClient.put(`/blogs/${id}`, blogData);
    return data;
  },
  deleteBlog: async (id) => {
    const { data } = await apiClient.delete(`/blogs/${id}`);
    return data;
  },

  // Inbox / Contacts
  getInbox: async (params) => {
    const { data } = await apiClient.get('/contact', { params });
    return data;
  },
  updateMessage: async (id, messageData) => {
    const { data } = await apiClient.put(`/contact/${id}`, messageData);
    return data;
  },
  deleteMessage: async (id) => {
    const { data } = await apiClient.delete(`/contact/${id}`);
    return data;
  },

  // Analytics
  getAnalytics: async () => {
    const { data } = await apiClient.get('/analytics');
    return data;
  },
};

export default cmsService;
