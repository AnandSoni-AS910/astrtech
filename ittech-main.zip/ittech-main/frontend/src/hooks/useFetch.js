import { useCallback, useEffect, useMemo, useState } from "react";
import apiClient from "../api/client";

const responseCache = new Map();
const inFlightRequests = new Map();

const buildCacheKey = (url, optionsKey, token) =>
  `${url}::${token || "anon"}::${optionsKey}`;

const useFetch = (url, options = {}) => {
  const optionsKey = JSON.stringify(options ?? {});
  const requestOptions = useMemo(() => options, [optionsKey]);
  const initialState = useMemo(() => {
    const token =
      typeof window !== "undefined" ? localStorage.getItem("token") || "" : "";
    const cacheKey = buildCacheKey(url, optionsKey, token);
    return responseCache.has(cacheKey)
      ? { data: responseCache.get(cacheKey), loading: false, error: null }
      : { data: null, loading: true, error: null };
  }, [url, optionsKey]);

  const [data, setData] = useState(initialState.data);
  const [loading, setLoading] = useState(initialState.loading);
  const [error, setError] = useState(initialState.error);

  const fetchData = useCallback(
    async (force = false) => {
      const token =
        typeof window !== "undefined" ? localStorage.getItem("token") || "" : "";
      const cacheKey = buildCacheKey(url, optionsKey, token);

      if (!force && responseCache.has(cacheKey)) {
        const cached = responseCache.get(cacheKey);
        setData(cached);
        setError(null);
        setLoading(false);
        return cached;
      }

      if (!force && inFlightRequests.has(cacheKey)) {
        setLoading(true);
        try {
          const cachedResponse = await inFlightRequests.get(cacheKey);
          setData(cachedResponse);
          setError(null);
          return cachedResponse;
        } catch (err) {
          const message =
            err.response?.data?.error || err.message || "An error occurred";
          setError(message);
          throw err;
        } finally {
          setLoading(false);
        }
      }

      setLoading(true);
      setError(null);

      const requestPromise = apiClient
        .get(url, requestOptions)
        .then((response) => response.data);

      inFlightRequests.set(cacheKey, requestPromise);

      try {
        const responseData = await requestPromise;
        responseCache.set(cacheKey, responseData);
        setData(responseData);
        return responseData;
      } catch (err) {
        const message =
          err.response?.data?.error || err.message || "An error occurred";
        setError(message);
        throw err;
      } finally {
        inFlightRequests.delete(cacheKey);
        setLoading(false);
      }
    },
    [url, optionsKey, requestOptions],
  );

  useEffect(() => {
    let isActive = true;

    const load = async () => {
      try {
        if (!isActive) return;
        await fetchData(false);
      } catch {
        // Error state is already stored locally for the caller.
      }
    };

    load();

    return () => {
      isActive = false;
    };
  }, [fetchData]);

  const refetch = useCallback(() => fetchData(true), [fetchData]);

  return { data, loading, error, refetch };
};

export default useFetch;
