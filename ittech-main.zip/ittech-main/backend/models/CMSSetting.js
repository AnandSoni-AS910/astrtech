const mongoose = require('mongoose');

const CMSSettingSchema = new mongoose.Schema({
  key: {
    type: String,
    required: true,
    unique: true
  },
  value: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  },
  group: {
    type: String, // 'services', 'home', 'general', etc.
    default: 'general'
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('CMSSetting', CMSSettingSchema);
