const mongoose = require('mongoose');

const SiteSettingsSchema = new mongoose.Schema({
  companyName: {
    type: String,
    required: [true, 'Please add a company name'],
    default: 'IT Tech'
  },
  tagline: {
    type: String,
    default: 'Empowering businesses with cutting-edge technology solutions.'
  },
  email: {
    type: String,
    required: [true, 'Please add a contact email'],
    default: 'contact@ittech.com'
  },
  phone: {
    type: String,
    default: '+1 (234) 567-890'
  },
  address: {
    type: String,
    default: '123 Tech Avenue, Silicon Valley, CA 94043'
  },
  facebook: {
    type: String,
    default: '#'
  },
  instagram: {
    type: String,
    default: '#'
  },
  twitter: {
    type: String,
    default: '#'
  },
  linkedin: {
    type: String,
    default: '#'
  },
  whatsapp: {
    type: String,
    default: '#'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Since we only want one document for settings, we use a static method or a fixed ID
SiteSettingsSchema.statics.getSettings = async function() {
  let settings = await this.findOne();
  if (!settings) {
    settings = await this.create({});
  }
  return settings;
};

module.exports = mongoose.model('SiteSettings', SiteSettingsSchema);
