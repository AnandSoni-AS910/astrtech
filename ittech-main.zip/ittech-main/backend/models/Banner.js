const mongoose = require('mongoose');

const BannerSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Please add a headline'],
    trim: true,
  },
  subtitle: {
    type: String,
    required: [true, 'Please add a subtitle or subtext'],
  },
  mediaUrl: {
    type: String,
    required: false
  },
  ctaText: {
    type: String,
    default: 'Get Started'
  },
  ctaLink: {
    type: String,
    default: '/contact'
  },
  isActive: {
    type: Boolean,
    default: false // Only one should ideally be active at an instant, or we loop through active ones
  },
  orderIndex: {
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Banner', BannerSchema);
