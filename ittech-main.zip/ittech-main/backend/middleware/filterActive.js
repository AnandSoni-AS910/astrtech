/**
 * Middleware to filter only active/published items for public routes
 */
const filterActive = (req, res, next) => {
  // If request has authorization header, it might be an admin, allow them to see everything
  // unless they specifically asked for a status
  if (req.headers.authorization || req.query.isActive !== undefined || req.query.status !== undefined) {
    return next();
  }
  
  // For blogs, we use status='published'
  if (req.originalUrl.includes('/blogs')) {
    if (req.query.status === undefined) {
      req.query.status = 'published';
    }
  } else {
    // For services, projects, testimonials, banners, use isActive=true
    req.query.isActive = true;
  }
  
  next();
};

module.exports = filterActive;
