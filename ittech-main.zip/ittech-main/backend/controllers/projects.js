const Project = require('../models/Project');

// @desc    Get all project categories (enum values)
// @route   GET /api/projects/categories
// @access  Public
exports.getProjectCategories = async (req, res, next) => {
  try {
    const categories = Project.schema.path('category').enumValues;
    res.status(200).json({ success: true, data: categories });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all projects
// @route   GET /api/projects
// @access  Public
exports.getProjects = async (req, res, next) => {
  try {
    const projects = await Project.find().sort('-createdAt');
    res.status(200).json({ success: true, count: projects.length, data: projects });
  } catch (error) {
    next(error);
  }
};

exports.createProject = async (req, res, next) => {
  try {
    const { title, category, description } = req.body;
    
    if (!title || !category || !description) {
      return res.status(400).json({ success: false, error: 'Title, category, and description are required' });
    }

    if (req.file) {
      req.body.images = [req.file.path];
    } else {
      req.body.images = ['no-photo.jpg'];
    }
    
    // Process tags
    if (req.body.tags) {
      req.body.tags = String(req.body.tags).split(',').map(tag => tag.trim()).filter(Boolean);
    }

    const project = await Project.create(req.body);
    res.status(201).json({ success: true, data: project });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(val => val.message);
      return res.status(400).json({ success: false, error: messages });
    }
    next(error);
  }
};

// @desc    Update project
// @route   PUT /api/projects/:id
// @access  Private
exports.updateProject = async (req, res, next) => {
  try {
    let project = await Project.findById(req.params.id);

    if (!project) {
      return res.status(404).json({ success: false, error: 'Project not found' });
    }

    if (req.file) {
      req.body.images = [req.file.path];
    } else {
      delete req.body.images;
    }

    if (req.body.tags) {
      req.body.tags = String(req.body.tags).split(',').map(tag => tag.trim()).filter(Boolean);
    }

    project = await Project.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.status(200).json({ success: true, data: project });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(val => val.message);
      return res.status(400).json({ success: false, error: messages });
    }
    next(error);
  }
};

// @desc    Delete project
// @route   DELETE /api/projects/:id
// @access  Private
exports.deleteProject = async (req, res, next) => {
  try {
    const project = await Project.findById(req.params.id);

    if (!project) {
      return res.status(404).json({ success: false, error: 'Project not found' });
    }

    await project.deleteOne();
    res.status(200).json({ success: true, data: {} });
  } catch (error) {
    next(error);
  }
};
