const CMSSetting = require('../models/CMSSetting');

// @desc    Get all settings or filter by group
// @route   GET /api/settings
// @access  Public
exports.getSettings = async (req, res, next) => {
  try {
    const filter = req.query.group ? { group: req.query.group } : {};
    const settings = await CMSSetting.find(filter);
    
    // Reduce array to key-value object for convenience
    const settingsMap = settings.reduce((acc, current) => {
      acc[current.key] = current.value;
      return acc;
    }, {});

    res.status(200).json({ success: true, data: settingsMap });
  } catch (error) {
    next(error);
  }
};

// @desc    Create or Update setting
// @route   POST /api/settings
// @access  Private
exports.updateSetting = async (req, res, next) => {
  try {
    const { key, value, group } = req.body;

    // Handle logo upload if present
    if (req.file) {
      await CMSSetting.findOneAndUpdate(
        { key: 'company_logo' },
        { 
          value: req.file.path, 
          group: group || 'general', 
          updatedAt: Date.now() 
        },
        { new: true, upsert: true }
      );
    }

    // Handle bulk update if no specific key is provided but an object is sent
    if (!key && req.body && typeof req.body === 'object' && !Array.isArray(req.body)) {
      const updatePromises = Object.entries(req.body).map(async ([k, v]) => {
        // Skip metadata fields and reserved keys
        if (k === 'group' || k === 'updatedAt' || k === 'key' || k === 'value') return null;
        
        // If logo was handled above, we might want to skip it if it's in req.body as well
        // but usually the frontend won't send the file path in JSON if it's uploading a file
        
        try {
          return await CMSSetting.findOneAndUpdate(
            { key: k },
            { 
              value: v, 
              group: group || 'general', 
              updatedAt: Date.now() 
            },
            { new: true, upsert: true, runValidators: true }
          );
        } catch (err) {
          console.error(`Bulk update failed for key ${k}:`, err.message);
          return null;
        }
      });

      await Promise.all(updatePromises);
      return res.status(200).json({ success: true, message: 'Tactical bulk update synchronized' });
    }
    
    if (!key && !req.file) {
      return res.status(400).json({ success: false, error: 'Setting key or logo is required for update' });
    }

    let setting;
    if (key) {
      setting = await CMSSetting.findOneAndUpdate(
        { key },
        { value, group: group || 'general', updatedAt: Date.now() },
        { new: true, upsert: true }
      );
    }

    res.status(200).json({ success: true, data: setting });
  } catch (error) {
    next(error);
  }
};
