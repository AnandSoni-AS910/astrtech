const Subscription = require('../models/Subscription');

// @desc    Get all newsletter subscriptions
// @route   GET /api/subscriptions
// @access  Private (admin)
exports.getSubscriptions = async (req, res, next) => {
  try {
    const subs = await Subscription.find().sort({ createdAt: -1 });
    res.status(200).json({ success: true, count: subs.length, data: subs });
  } catch (error) {
    next(error);
  }
};

// @desc    Add a new subscription
// @route   POST /api/subscriptions
// @access  Public
exports.addSubscription = async (req, res, next) => {
  try {
    const sub = await Subscription.create(req.body);
    
    // Create notification for new subscription
    try {
      const Notification = require('../models/Notification');
      await Notification.create({
        title: 'New Newsletter Operative',
        message: `${sub.email} has joined the Daily Intel Briefing list.`,
        type: 'info',
        link: '/admin/inbox' // Link to the inbox where subs are managed
      });
    } catch (err) {
      console.error('Failed to create notification:', err.message);
    }

    res.status(201).json({ success: true, data: sub });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete a subscription
// @route   DELETE /api/subscriptions/:id
// @access  Private (admin)
exports.deleteSubscription = async (req, res, next) => {
  try {
    const sub = await Subscription.findById(req.params.id);

    if (!sub) {
      return res.status(404).json({ success: false, error: 'Subscription not found' });
    }

    await sub.deleteOne();

    res.status(200).json({ success: true, data: {} });
  } catch (error) {
    next(error);
  }
};
