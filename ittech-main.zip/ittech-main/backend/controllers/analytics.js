const Project = require('../models/Project');
const Service = require('../models/Service');
const Contact = require('../models/Contact');
const Blog = require('../models/Blog');

// @desc    Get dashboard analytics dashboard data
// @route   GET /api/analytics
// @access  Private/Admin
exports.getDashboardStats = async (req, res, next) => {
  try {
    const totalProjects = await Project.countDocuments();
    const totalServices = await Service.countDocuments();
    const totalLeads = await Contact.countDocuments();
    const totalBlogs = await Blog.countDocuments();
    
    const unreadMessages = await Contact.countDocuments({ isRead: false });

    // Aggregate Projects by Category for pie charts
    const projectCategories = await Project.aggregate([
      { $group: { _id: '$category', count: { $sum: 1 } } }
    ]);

    // Aggregate Leads per month (last 6 months)
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
    
    const leadTrends = await Contact.aggregate([
      { $match: { createdAt: { $gte: sixMonthsAgo } } },
      { 
        $group: { 
          _id: { month: { $month: '$createdAt' }, year: { $year: '$createdAt' } },
          total: { $sum: 1 } 
        } 
      },
      { $sort: { '_id.year': 1, '_id.month': 1 } }
    ]);

    res.status(200).json({
      success: true,
      data: {
        totals: {
          projects: totalProjects,
          services: totalServices,
          leads: totalLeads,
          blogs: totalBlogs,
          unreadMessages
        },
        charts: {
          projectCategories,
          leadTrends
        }
      }
    });
  } catch (error) {
    next(error);
  }
};
