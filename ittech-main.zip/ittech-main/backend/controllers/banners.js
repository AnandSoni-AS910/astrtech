const Banner = require('../models/Banner');

exports.getBanners = async (req, res, next) => {
  try {
    const banners = await Banner.find().sort('orderIndex');
    res.status(200).json({ success: true, count: banners.length, data: banners });
  } catch (error) { next(error); }
};

exports.createBanner = async (req, res, next) => {
  try {
    if (req.file) req.body.mediaUrl = req.file.path;
    const banner = await Banner.create(req.body);
    res.status(201).json({ success: true, data: banner });
  } catch (error) { next(error); }
};

exports.updateBanner = async (req, res, next) => {
  try {
    let banner = await Banner.findById(req.params.id);
    if (!banner) return res.status(404).json({ success: false, error: 'Not found' });
    if (req.file) req.body.mediaUrl = req.file.path;
    banner = await Banner.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    res.status(200).json({ success: true, data: banner });
  } catch (error) { next(error); }
};

exports.deleteBanner = async (req, res, next) => {
  try {
    const banner = await Banner.findById(req.params.id);
    if (!banner) return res.status(404).json({ success: false, error: 'Not found' });
    await banner.deleteOne();
    res.status(200).json({ success: true, data: {} });
  } catch (error) { next(error); }
};
