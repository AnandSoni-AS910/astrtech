const express = require('express');
const {
  getServices,
  getService,
  createService,
  updateService,
  deleteService
} = require('../controllers/services');
const { protect } = require('../middleware/auth');
const filterActive = require('../middleware/filterActive');
const upload = require('../middleware/upload');

const router = express.Router();

router.route('/')
  .get(filterActive, getServices)
  .post(protect, upload.single('image'), createService);

router.route('/:id')
  .get(getService)
  .put(protect, upload.single('image'), updateService)
  .delete(protect, deleteService);

module.exports = router;
