const express = require('express');
const {
  getTestimonials,
  createTestimonial,
  updateTestimonial,
  deleteTestimonial
} = require('../controllers/testimonials');

const { protect } = require('../middleware/auth');
const filterActive = require('../middleware/filterActive');
const upload = require('../middleware/upload');

const router = express.Router();

router
  .route('/')
  .get(filterActive, getTestimonials)
  .post(protect, upload.single('image'), createTestimonial);

router
  .route('/:id')
  .put(protect, upload.single('image'), updateTestimonial)
  .delete(protect, deleteTestimonial);

module.exports = router;
