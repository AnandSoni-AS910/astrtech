const express = require('express');
const {
  getProjects,
  getProjectCategories,
  createProject,
  updateProject,
  deleteProject
} = require('../controllers/projects');
const { protect } = require('../middleware/auth');
const filterActive = require('../middleware/filterActive');
const upload = require('../middleware/upload');

const router = express.Router();

router.route('/categories')
  .get(getProjectCategories);

router.route('/')
  .get(filterActive, getProjects)
  .post(protect, upload.single('image'), createProject);

router.route('/:id')
  .put(protect, upload.single('image'), updateProject)
  .delete(protect, deleteProject);

module.exports = router;
