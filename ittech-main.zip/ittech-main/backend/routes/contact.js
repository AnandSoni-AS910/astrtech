const express = require('express');
const {
  getMessages,
  sendMessage,
  updateMessageStatus,
  deleteMessage
} = require('../controllers/contact');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.route('/')
  .get(protect, getMessages)
  .post(sendMessage);

router.route('/:id')
  .put(protect, updateMessageStatus)
  .delete(protect, deleteMessage);

module.exports = router;
