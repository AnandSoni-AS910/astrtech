const express = require('express');
const { getSettings, updateSetting } = require('../controllers/settings');
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');

const router = express.Router();

router.route('/')
  .get(getSettings)
  .post(protect, upload.single('logo'), updateSetting);

module.exports = router;
