const express = require('express');
const { getSubscriptions, addSubscription, deleteSubscription } = require('../controllers/subscription');
const { protect } = require('../middleware/auth');

const router = express.Router();

// Public route to add subscription
router.post('/', addSubscription);

// Protected routes (admin)
router.use(protect);
router.route('/')
  .get(getSubscriptions);

router.delete('/:id', deleteSubscription);

module.exports = router;
