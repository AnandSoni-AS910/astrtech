const express = require('express');
const { login, getMe, updateDetails, updatePassword } = require('../controllers/auth');
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');

const router = express.Router();

router.post('/login', login);
router.get('/me', protect, getMe);

router.route('/updatedetails')
  .put(protect, upload.single('avatar'), updateDetails);

router.route('/updatepassword')
  .put(protect, updatePassword);

// Fallbacks for trailing slashes
router.route('/updatedetails/')
  .put(protect, upload.single('avatar'), updateDetails);

router.route('/updatepassword/')
  .put(protect, updatePassword);

module.exports = router;
