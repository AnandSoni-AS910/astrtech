const express = require('express');
const {
  getNotifications,
  markAsRead,
  markAllRead,
  deleteNotification,
  clearAllNotifications
} = require('../controllers/notifications');

const router = express.Router();

const { protect } = require('../middleware/auth');

// All routes are protected
router.use(protect);

router.route('/')
  .get(getNotifications)
  .delete(clearAllNotifications);

router.put('/read-all', markAllRead);
router.route('/:id')
  .put(markAsRead)
  .delete(deleteNotification);

router.put('/:id/read', markAsRead);

module.exports = router;
