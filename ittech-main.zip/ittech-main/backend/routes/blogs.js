const express = require('express');
const {
  getBlogs,
  createBlog,
  updateBlog,
  deleteBlog
} = require('../controllers/blogs');
const { protect } = require('../middleware/auth');
const filterActive = require('../middleware/filterActive');
const upload = require('../middleware/upload');

const router = express.Router();

router.route('/')
  .get(filterActive, getBlogs)
  .post(protect, upload.single('image'), createBlog);

router.route('/:id')
  .put(protect, upload.single('image'), updateBlog)
  .delete(protect, deleteBlog);

module.exports = router;
