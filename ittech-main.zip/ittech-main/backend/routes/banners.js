const express = require('express');
const { getBanners, createBanner, updateBanner, deleteBanner } = require('../controllers/banners');
const { protect } = require('../middleware/auth');
const filterActive = require('../middleware/filterActive');
const upload = require('../middleware/upload');

const router = express.Router();

router.route('/')
  .get(filterActive, getBanners)
  .post(protect, upload.single('image'), createBanner);

router.route('/:id')
  .put(protect, upload.single('image'), updateBanner)
  .delete(protect, deleteBanner);

module.exports = router;
