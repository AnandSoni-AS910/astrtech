const express = require('express');
const { getDashboardStats } = require('../controllers/analytics');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.get('/', protect, getDashboardStats);

module.exports = router;
