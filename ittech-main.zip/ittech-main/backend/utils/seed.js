require('dotenv').config();
const mongoose = require('mongoose');

// Import All Models
const Admin = require('../models/Admin');
const Service = require('../models/Service');
const Project = require('../models/Project');
const Testimonial = require('../models/Testimonial');
const Contact = require('../models/Contact');
const Blog = require('../models/Blog');
const Banner = require('../models/Banner');
const Notification = require('../models/Notification');

const admins = [
  {
    name: 'Main Admin',
    email: 'admin@ittech.com',
    password: 'password123',
    role: 'superadmin',
    preferences: { theme: 'dark', emailAlerts: true }
  }
];

const banners = [
  {
    title: 'Future-Ready Tech Solutions',
    subtitle: 'We build scalable, high-performance software for visionary global brands.',
    mediaUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1920&q=80',
    ctaText: 'Explore Services',
    ctaLink: '/services',
    isActive: true,
    orderIndex: 0
  },
  {
    title: 'Secure Cloud Architecture',
    subtitle: 'Global-scale infrastructure designed for maximum security and zero downtime.',
    mediaUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1920&q=80',
    ctaText: 'Free Audit',
    ctaLink: '/contact',
    isActive: true,
    orderIndex: 1
  }
];

const services = [
  {
    title: 'Custom Software',
    description: 'Bespoke software solutions tailored to your unique business processes.',
    icon: 'Code',
    category: 'Development',
    orderIndex: 1,
    isActive: true,
    seoMeta: { title: 'Custom Software Development', keywords: ['software', 'react', 'node'] }
  },
  {
    title: 'Cloud Architecture',
    description: 'Scalable and secure cloud infrastructure design and management.',
    icon: 'Cpu',
    category: 'Cloud',
    orderIndex: 2,
    isActive: true,
    seoMeta: { title: 'Cloud Infrastructure Solutions', keywords: ['cloud', 'aws', 'azure'] }
  },
  {
    title: 'Cyber Security',
    description: 'Comprehensive security audits and implementation of defensive systems.',
    icon: 'Shield',
    category: 'Security',
    orderIndex: 3,
    isActive: true,
    seoMeta: { title: 'Enterprise Cyber Security', keywords: ['security', 'pentesting', 'iso'] }
  }
];

const projects = [
  {
    title: 'Fintech Hub',
    description: 'A revolutionary banking platform for digital nomads.',
    images: ['https://images.unsplash.com/photo-1551288049-bbbda536ad80?auto=format&fit=crop&w=800&q=80'],
    client: 'Global Finance',
    industry: 'Finance',
    year: '2025',
    tags: ['React', 'Node.js', 'AWS'],
    featured: true
  },
  {
    title: 'HealthTrack AI',
    description: 'AI-driven health monitoring system for elderly care.',
    images: ['https://images.unsplash.com/photo-1576091160550-2173599211d0?auto=format&fit=crop&w=800&q=80'],
    client: 'MediCare Inc',
    industry: 'Healthcare',
    year: '2024',
    tags: ['Python', 'React Native', 'Firebase'],
    featured: true
  }
];

const testimonials = [
  {
    name: 'Sarah Johnson',
    role: 'CTO',
    company: 'NextGen Systems',
    text: 'IT Tech transformed our legacy architecture into a high-speed microservices environment within record time.',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150&q=80',
    rating: 5,
    status: 'approved',
    isActive: true
  },
  {
    name: 'David Chen',
    role: 'Operations Director',
    company: 'BlueWave Logistics',
    text: 'The cloud security audit they performed was the most thorough we have ever experienced.',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&h=150&q=80',
    rating: 5,
    status: 'approved',
    isActive: true
  }
];

const blogs = [
  {
    title: 'The Future of Serverless Architecture',
    slug: 'future-of-serverless',
    excerpt: 'How FaaS is changing the way we think about scalability and cost optimization.',
    content: '<p>Serverless architecture is not just a buzzword...</p>',
    author: 'IT Tech Team',
    category: 'Engineering',
    tags: ['Serverless', 'Cloud', 'Architecture'],
    status: 'published',
    coverImage: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80'
  },
  {
    title: 'Zero Trust Security in 2026',
    slug: 'zero-trust-2026',
    excerpt: 'Why identity-based security is the only way forward for distributed enterprises.',
    content: '<p>Trust nothing, verify everything...</p>',
    author: 'Security Analyst',
    category: 'Security',
    tags: ['Zero Trust', 'IAM', 'Enterprise'],
    status: 'published',
    coverImage: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80'
  }
];

const contactMessages = [
  {
    name: 'George Miller',
    email: 'george@enterprise.com',
    subject: 'Architecture Quote',
    message: 'We are looking to migrate our monolith to Kubernetes. Can you help?',
    isRead: false,
    status: 'inbox'
  }
];

const notifications = [
  {
    title: 'New Lead',
    message: 'George Miller sent a new inquiry regarding Architecture Quote.',
    type: 'lead',
    isRead: false,
    link: '/admin'
  },
  {
    title: 'System Update',
    message: 'Platform upgraded to Enterprise SaaS Tier successfully.',
    type: 'success',
    isRead: true
  }
];

const seedData = async () => {
  try {
    if (!process.env.MONGO_URI) {
      throw new Error('MONGO_URI is not defined in .env');
    }
    
    await mongoose.connect(process.env.MONGO_URI);
    console.log('Connected to MongoDB for Enterprise Seeding...');

    // Clear existing data
    console.log('Purging existing records...');
    await Admin.deleteMany();
    await Service.deleteMany();
    await Project.deleteMany();
    await Banner.deleteMany();
    await Testimonial.deleteMany();
    await Contact.deleteMany();
    await Blog.deleteMany();
    await Notification.deleteMany();

    // Insert Data
    console.log('Inserting SaaS-level data points...');
    
    await Admin.create(admins);
    await Banner.create(banners);
    await Service.create(services);
    await Project.create(projects);
    await Testimonial.create(testimonials);
    await Contact.create(contactMessages);
    await Blog.create(blogs);
    await Notification.create(notifications);

    console.log('✅ Enterprise Platform Seeded Successfully!');
    process.exit();
  } catch (error) {
    console.error(`❌ Seeding Failed: ${error.message}`);
    process.exit(1);
  }
};

seedData();
