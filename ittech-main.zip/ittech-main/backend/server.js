require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const connectDB = require('./config/db');
const { errorHandler } = require('./middleware/error');

// Connect to Database
connectDB();

const app = express();

// Middleware
app.use(helmet({
  crossOriginResourcePolicy: false, // Allow images to be loaded cross-origin (needed for uploads)
}));
app.use(cors({
  origin: '*', // Allow all origins for dev simplicity, or specify 'http://localhost:5174'
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(morgan('dev'));

// Static Folders
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes
app.get('/', (req, res) => {
  res.json({ message: 'Welcome to IT Tech API' });
});

// Auth Routes placeholder
app.use('/api/auth', require('./routes/auth'));
// Service Routes placeholder
app.use('/api/services', require('./routes/services'));
app.use('/api/settings', require('./routes/settings'));
// Project Routes placeholder
app.use('/api/projects', require('./routes/projects'));
// Testimonial Routes
app.use('/api/testimonials', require('./routes/testimonials'));
// Analytical SaaS Routes
app.use('/api/subscriptions', require('./routes/subscription'));
// Banners Route
app.use('/api/banners', require('./routes/banners'));
// Blog Routes placeholder
app.use('/api/blogs', require('./routes/blogs'));
// Contact Routes placeholder
app.use('/api/contact', require('./routes/contact'));
// Global Site Settings Routes
app.use('/api/settings', require('./routes/settings'));
app.use('/api/analytics', require('./routes/analytics'));
app.use('/api/notifications', require('./routes/notifications'));

// Error Handler
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`);
});
