const fs = require('fs');
const worldData = JSON.parse(fs.readFileSync('d:/work/Company/frontend/src/assets/world.json', 'utf8'));

const countPoints = (increment) => {
  let count = 0;
  const processPolygon = (polygon) => {
    polygon.forEach(ring => {
      for (let i = 0; i < ring.length; i += increment) {
        count++;
      }
    });
  };

  worldData.features.forEach(feature => {
    if (!feature.geometry) return;
    const type = feature.geometry.type;
    const coordinates = feature.geometry.coordinates;
    if (type === 'Polygon') {
      processPolygon(coordinates);
    } else if (type === 'MultiPolygon') {
      coordinates.forEach(polygon => processPolygon(polygon));
    }
  });
  return count;
};

console.log("Points with i += 2:", countPoints(2));
console.log("Points with i += 4:", countPoints(4));
console.log("Points with i += 6:", countPoints(6));
console.log("Points with i += 8:", countPoints(8));
